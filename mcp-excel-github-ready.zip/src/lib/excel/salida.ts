/**
 * Escritura de resultados: .xlsx con formato basico o .csv seguro para Excel.
 */
import { writeFile } from "node:fs/promises";
import ExcelJS from "exceljs";
import type { ArchivoSalida } from "./rutas.js";

export type ValorSalida = string | number | boolean | null;

export interface OpcionesSalida {
  destino: ArchivoSalida;
  encabezados: string[];
  filas: ValorSalida[][];
  nombreHoja: string;
  delimitador?: "," | ";";
  bom?: boolean;
  protegerFormulas?: boolean;
}

export interface ResultadoSalida {
  ruta: string;
  formato: "xlsx" | "csv";
  bytes: number;
  filas: number;
  columnas: number;
  avisos: string[];
}

function nombreHojaValido(nombre: string): string {
  let n = nombre.replace(/[\[\]:*?/\\]/g, " ").replace(/\s+/g, " ").trim();
  if (n === "") n = "Datos";
  if (n.length > 31) n = n.slice(0, 31).trim();
  return n;
}

function anchoColumna(valores: ValorSalida[]): number {
  let max = 8;
  for (const v of valores) {
    if (v === null) continue;
    const largo = String(v).length;
    if (largo > max) max = largo;
    if (max >= 60) return 60;
  }
  return Math.min(60, Math.max(8, max + 2));
}

async function escribirXlsx(opciones: OpcionesSalida): Promise<ResultadoSalida> {
  const wb = new ExcelJS.Workbook();
  wb.creator = "MCP Excel";
  wb.created = new Date();
  const ws = wb.addWorksheet(nombreHojaValido(opciones.nombreHoja));

  ws.addRow(opciones.encabezados);
  for (const fila of opciones.filas) ws.addRow(fila);

  const encabezado = ws.getRow(1);
  encabezado.font = { bold: true, color: { argb: "FFFFFFFF" } };
  encabezado.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1F4E78" } };
  encabezado.alignment = { vertical: "middle" };
  ws.views = [{ state: "frozen", ySplit: 1 }];

  if (opciones.encabezados.length > 0) {
    ws.autoFilter = {
      from: { row: 1, column: 1 },
      to: { row: Math.max(1, opciones.filas.length + 1), column: opciones.encabezados.length },
    };
  }

  for (let c = 0; c < opciones.encabezados.length; c++) {
    const col = ws.getColumn(c + 1);
    const muestra = [opciones.encabezados[c] ?? "", ...opciones.filas.slice(0, 200).map((f) => f[c] ?? null)];
    col.width = anchoColumna(muestra);
  }

  await wb.xlsx.writeFile(opciones.destino.ruta);
  const fs = await import("node:fs/promises");
  const info = await fs.stat(opciones.destino.ruta);

  return {
    ruta: opciones.destino.ruta,
    formato: "xlsx",
    bytes: info.size,
    filas: opciones.filas.length,
    columnas: opciones.encabezados.length,
    avisos: [],
  };
}

function valorCsv(v: ValorSalida, proteger: boolean): string {
  if (v === null || v === undefined) return "";
  if (typeof v === "number") return Number.isFinite(v) ? String(v) : "";
  if (typeof v === "boolean") return v ? "VERDADERO" : "FALSO";
  let s = String(v).replace(/\u0000/g, "");
  if (proteger && /^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return s;
}

function escaparCsv(s: string, delimitador: string): string {
  if (s.includes('"') || s.includes(delimitador) || /[\r\n]/.test(s)) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

async function escribirCsv(opciones: OpcionesSalida): Promise<ResultadoSalida> {
  const delimitador = opciones.delimitador ?? ",";
  const proteger = opciones.protegerFormulas !== false;
  const lineas: string[] = [];
  lineas.push(opciones.encabezados.map((h) => escaparCsv(valorCsv(h, false), delimitador)).join(delimitador));
  for (const fila of opciones.filas) {
    lineas.push(fila.map((v) => escaparCsv(valorCsv(v, proteger), delimitador)).join(delimitador));
  }
  const texto = `${opciones.bom === false ? "" : "\ufeff"}${lineas.join("\r\n")}\r\n`;
  await writeFile(opciones.destino.ruta, texto, "utf8");
  const fs = await import("node:fs/promises");
  const info = await fs.stat(opciones.destino.ruta);

  return {
    ruta: opciones.destino.ruta,
    formato: "csv",
    bytes: info.size,
    filas: opciones.filas.length,
    columnas: opciones.encabezados.length,
    avisos: proteger
      ? ["En CSV, los textos que empiezan con =, +, - o @ se guardaron con apostrofo inicial para evitar formulas al abrirlo."]
      : [],
  };
}

export async function escribirTabla(opciones: OpcionesSalida): Promise<ResultadoSalida> {
  if (opciones.destino.extension === ".csv") return escribirCsv(opciones);
  return escribirXlsx(opciones);
}
