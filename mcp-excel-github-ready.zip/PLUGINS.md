# PLUGINS.md — Ecosistema de complementos de Excel

Este documento clasifica los complementos y utilidades que rodean a Excel y decide **qué se integra**, **qué se recomienda** y **qué no se hace por motivos legales o de seguridad**.

Regla de oro: solo se inspecciona la **interfaz pública** de lo instalado (registro de Windows, nombres de archivo, documentación oficial y API/scripting público). **No se lee, descompila, parchea ni ejecuta código propietario**, y no se saltan licencias, activaciones ni límites de prueba.

## 1. Cómo se detecta lo instalado

`excel_plugins_estado` consulta, en modo solo lectura:

- `HKCU\Software\Microsoft\Office\Excel\Addins`
- `HKLM\SOFTWARE\Microsoft\Office\Excel\Addins`
- `HKLM\SOFTWARE\WOW6432Node\Microsoft\Office\Excel\Addins`
- Las carpetas `XLSTART` (solo nombres de archivo, máximo 100 por carpeta)
- El estado de Excel (`Excel.Application.16`, ruta del ejecutable, versión)

Interpretación de `LoadBehavior`:

| Valor | Significado | Estado que reporta el MCP |
|---|---|---|
| 3 | Conectado y cargado al inicio | `detectado_habilitado` |
| 2 | Conectado pero desactivado por la persona | `detectado_deshabilitado` |
| 0 / 8 / 9 | Desconectado | `detectado_deshabilitado` |
| — | Incluido con Excel, sin evidencia en el registro | `incluido_sin_evidencia` |

En este equipo se detectaron dos complementos: `MicrosoftDataStreamerforExcel` (HKCU, sin `LoadBehavior`) y `PowerPivotExcelClientAddIn.NativeEntry.1` (HKCU, `LoadBehavior=2`, es decir, instalado pero desactivado). La detección **no abre Excel** y **no lee los archivos de los complementos**.

## 2. Categoría A — Incluido o gratuito: se integra

| Complemento | Qué aporta | Licencia | Cómo lo aprovecha el MCP |
|---|---|---|---|
| Analysis ToolPak (Herramientas para análisis) | Estadística descriptiva, regresión, histogramas, ANOVA | Incluido con Excel | `excel_estadisticas_columna` implementa la estadística descriptiva sin depender de él; si está activo, se respetan sus resultados guardados |
| Solver | Optimización con restricciones | Incluido con Excel | Se detecta; la optimización no se automatiza (requiere interfaz o macros) |
| Power Query | ETL con lenguaje M | Incluido en Excel 2016+ y Microsoft 365 | Se detecta el entorno; no se ejecuta M. El MCP lee el resultado ya cargado en la hoja |
| Power Pivot | Modelo de datos, DAX, tablas dinámicas | Incluido en Microsoft 365 y algunas ediciones | Se detecta el complemento COM; se leen los valores calculados, no se crean medidas |
| Inquire | Auditoría de libros y fórmulas | Incluido en Microsoft 365 | Se detecta; no se invoca |
| Office Scripts | Automatización TypeScript en Excel | Incluido con Microsoft 365 (requiere cuenta/tenant) | No se ejecuta desde el MCP: depende de la nube y de permisos de la organización |
| Data Streamer | Datos en vivo y IoT | Incluido en Microsoft 365 | Se detecta por registro; no se automatiza |

Implementación de categoría A en este MCP:

- `excel_plugins_estado` (detección no invasiva, categorías y evidencias).
- `excel_inspeccionar_libro` (evidencia estructural de Power Query, Power Pivot y conexiones sin leer su código).
- `excel_estadisticas_columna` (cubre la función principal del Analysis ToolPak sin instalarlo).
- `excel_generar_reporte` (reporte HTML de calidad y estadística, sin depender del Analysis ToolPak).
- `excel_visual_recalcular_guardar` (permite que Excel, no ExcelJS, calcule las fórmulas).

## 3. Categoría B — De pago: solo recomendación

No se descargan, no se emulan, no se piratean. Si la persona **ya los tiene instalados**, se pueden usar sus comandos desde Excel y el MCP puede leer los resultados guardados. El MCP los detecta por nombre en el registro cuando es posible.

| Complemento | Qué desbloquea | Licencia | Enlace |
|---|---|---|---|
| Kutools for Excel | Cientos de utilidades: conversión por lotes, combinación de libros, limpieza avanzada | Pago por equipo | https://www.extendoffice.com/product/kutools-for-excel.html |
| Ablebits Ultimate Suite | Limpieza, comparación de tablas, duplicados, división de texto, fechas | Suscripción o licencia | https://www.ablebits.com/excel-suite/index.php |
| XLTools | Productividad, datos, fechas y limpieza | Suscripción | https://xltools.net/ |
| @RISK | Simulación Monte Carlo y análisis de riesgo | Licencia comercial | https://www.palisade.com/risk/ |
| ModelRisk | Monte Carlo, riesgo y ajuste de distribuciones | Licencia comercial | https://www.vosesoftware.com/products/modelrisk/ |

Recomendación honesta: para el objetivo de este proyecto (leer, estadística descriptiva y limpieza básica) **no hace falta comprar nada**. Kutools o Ablebits solo se justifican si la persona ya trabaja con limpiezas masivas muy específicas.

## 4. Categoría C — Capacidad propia (implementación original)

Se implementó la **funcionalidad**, no el producto: código propio en TypeScript, a partir de documentación pública y del formato OOXML. Sin copiar interfaz, textos, iconos ni recursos de terceros.

| # | Capacidad | Estado | Qué resuelve | Esfuerzo | Riesgo |
|---|---|---|---|---|---|
| C1 | Estadística descriptiva completa | **Implementado** | Media, mediana, moda, cuartiles (tipo 7), IQR, atípicos 1,5×IQR, varianza y desviación muestral, asimetría, curtosis, IC 95 % con t de Student | Medio | Bajo: matemática determinista y probada |
| C2 | Perfilado de calidad de columna | **Implementado** | Tipos, vacíos, únicos, top valores, números como texto, espacios invisibles, mayúsculas mezcladas, correos/URLs/teléfonos, casi duplicados | Medio | Bajo: solo lectura |
| C3 | Filtrado y limpieza con simulación | **Implementado** | Condiciones de texto/número AND/OR, duplicados por clave, filas vacías, recorte/colapso de espacios y exportación a archivo nuevo | Medio | Medio: escribe archivos, mitigado con `simular=true` por defecto, `confirmar=true` y prohibición de sobrescribir la entrada |
| C4 | Recalcular fórmulas sin COM | **Implementado (visual)** | F9 + Ctrl+S en la ventana de Excel para generar resultados cacheados | Bajo | Medio: depende de la interfaz y de diálogos |
| C5 | Agrupar categorías casi duplicadas | Propuesta | Sugerir un mapa `Valparaiso`/`Valparaíso`/`VALPARAISO` → forma canónica antes de limpiar | Medio | Medio: requiere confirmación humana |
| C6 | Comparar dos versiones de una tabla | **Implementado** | Filas nuevas, eliminadas y cambiadas por clave o posición, columnas exclusivas y tolerancia numérica | Alto | Bajo: solo lectura |
| C7 | Evaluar fórmulas sin Excel | Propuesta | Motor propio o LibreOffice headless | Muy alto | Alto: discrepancias con Excel |
| C8 | Exportar a PDF | Propuesta | Requiere COM o dependencia externa | Medio | Medio |
| C9 | Inspeccionar la estructura OOXML | **Implementado** | Tablas, nombres definidos, conexiones, Power Query, dinámicas, enlaces, macros, protección y objetos, sin ejecutar nada | Medio | Bajo: solo lectura y sin secretos |
| C10 | Reporte HTML de calidad | **Implementado** | Resumen, perfil por columna, valores frecuentes, estadística, histogramas SVG y muestra | Medio | Bajo: archivo nuevo, sin scripts |
| C11 | Ordenar filas por columnas | **Implementado** | Orden ascendente/descendente por una o varias claves, exportación a archivo nuevo | Bajo | Bajo: solo valores |
| C12 | Agrupar y agregar tabla | **Implementado** | Resúmenes por grupo (conteo, suma, promedio, mínimo, máximo, distintos) | Medio | Bajo: solo valores |
| C13 | Buscar y reemplazar texto | **Implementado** | Reemplazo literal seguro en celdas de texto | Bajo | Bajo: solo valores |

Se implementaron **tres** capacidades propias nuevas en esta pasada (C6, C9 y C10), además de la secuencia visual C4. C1, C2 y C3 ya formaban parte del motor y se mantuvieron sin cambiar su comportamiento. Las demás quedan como propuesta.

## 5. Categoría D — No procede

| Idea | Por qué no |
|---|---|
| Ejecutar macros/VBA del libro | El libro puede traer código malicioso; ejecutarlo con los permisos de la persona es un riesgo inaceptable |
| Escribir módulos VBA en `.xlsm` | Cambia el comportamiento del libro y puede invalidar firmas; fuera del alcance |
| Descompilar o parchear complementos de pago | Prohibido por las reglas del proyecto y por la ley |
| Saltarse activaciones, licencias o límites de prueba | Prohibido |
| Usar claves, cracks o generadores de licencias | Prohibido |
| Emular Kutools/Ablebits y presentarlo como tal | Copia de producto ajeno; además de ilegal, engañoso |
| Descargar complementos de origen dudoso | Riesgo de malware y de incumplimiento de licencias |
| Automatizar la interfaz de un complemento de pago sin licencia | Uso no autorizado del producto |

## 6. Requiere revisión

- **Power Automate + Office Scripts**: permitido por Microsoft 365, pero depende del contrato de la organización y de los permisos del tenant. No se implementa hasta que la persona confirme que su licencia lo incluye.
- **Complementos WebView2 de terceros** (por ejemplo, control de complementos vía CDP): la técnica es pública, pero requiere revisar los términos del complemento concreto y la superficie de seguridad que abre. **REQUIERE REVISIÓN**; no implementado.

## 7. Atribuciones

- ExcelJS — MIT — https://github.com/exceljs/exceljs
- JSZip — MIT o GPL-3.0-or-later — https://github.com/Stuk/jszip
- Model Context Protocol SDK — MIT — https://github.com/modelcontextprotocol/typescript-sdk
- Referentes de diseño: haris-musa/excel-mcp-server (MIT), negokaz/excel-mcp-server (MIT), dosev-ai/mcp-office (MIT), Anthropic Agent Skills `xlsx` (Apache-2.0). Solo se tomaron ideas de diseño y nombres de flujos; el código de este repositorio es propio.
