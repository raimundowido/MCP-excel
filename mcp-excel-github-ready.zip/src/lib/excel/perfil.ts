/**
 * Perfil de calidad de una columna: tipos, vacios, duplicados, formatos sospechosos y
 * valores casi duplicados (mismo texto con otra caja, acentos o espacios).
 */
import { calcularEstadisticas, type Estadisticas } from "./estadisticas.js";
import { valorDeFila, type ColumnaLeida, type HojaLeida } from "./libro.js";
import {
  aNumero,
  claveValor,
  limpiarTexto,
  normalizarTexto,
  pareceEmail,
  pareceTelefono,
  pareceUrl,
  type CeldaNormalizada,
  type TipoCelda,
} from "./valor.js";

export interface GrupoCasiDuplicado {
  clave: string;
  variantes: { valor: string; frecuencia: number }[];
}

export interface PerfilColumna {
  columna: { nombre: string; letra: string; indice: number };
  filas: number;
  vacios: number;
  noVacios: number;
  porcentajeVacios: number;
  tipos: Record<TipoCelda, number>;
  formulas: number;
  formulasSinResultado: number;
  unicos: number;
  duplicadosExtra: number;
  topValores: { valor: string; frecuencia: number; porcentaje: number }[];
  numerico: {
    convertibles: number;
    noConvertibles: number;
    guardadosComoTexto: number;
    negativos: number;
    ceros: number;
    conDecimales: number;
    estadisticas: Estadisticas | null;
  };
  texto: {
    celdas: number;
    longitudMinima: number;
    longitudMaxima: number;
    longitudMedia: number;
    conEspaciosExtremos: number;
    conEspaciosDobles: number;
    conSaltosDeLinea: number;
    conCaracteresRaros: number;
    soloMayusculas: number;
    soloMinusculas: number;
    mixtas: number;
    conAcentos: number;
    parecenEmail: number;
    parecenUrl: number;
    parecenTelefono: number;
  };
  fechas: { cantidad: number; minima: string | null; maxima: string | null };
  casiDuplicados: GrupoCasiDuplicado[];
  avisos: string[];
  sugerencias: string[];
}

function celdaVacia(): CeldaNormalizada {
  return { tipo: "vacio", valor: null, texto: "", formula: null, formulaSinResultado: false, formato: null };
}

export function perfilarColumna(hoja: HojaLeida, columna: ColumnaLeida, maxTop = 10): PerfilColumna {
  const tipos: Record<TipoCelda, number> = { vacio: 0, numero: 0, texto: 0, fecha: 0, booleano: 0, error: 0 };
  let vacios = 0;
  let formulas = 0;
  let formulasSinResultado = 0;
  let negativos = 0;
  let ceros = 0;
  let conDecimales = 0;
  let guardadosComoTexto = 0;
  let noConvertibles = 0;
  const numeros: number[] = [];
  const fechas: string[] = [];
  const claves = new Map<string, { valor: string; frecuencia: number }>();
  const superficies = new Map<string, Map<string, number>>();

  let celdasTexto = 0;
  let longitudTotal = 0;
  let longitudMinima = Number.POSITIVE_INFINITY;
  let longitudMaxima = 0;
  let conEspaciosExtremos = 0;
  let conEspaciosDobles = 0;
  let conSaltosDeLinea = 0;
  let conCaracteresRaros = 0;
  let soloMayusculas = 0;
  let soloMinusculas = 0;
  let mixtas = 0;
  let conAcentos = 0;
  let emails = 0;
  let urls = 0;
  let telefonos = 0;

  for (const fila of hoja.filas) {
    const c = valorDeFila(fila, columna) ?? celdaVacia();
    tipos[c.tipo]++;
    if (c.formula) formulas++;
    if (c.formulaSinResultado) formulasSinResultado++;

    const texto = c.texto ?? "";
    if (c.tipo === "vacio" || texto.trim() === "") {
      vacios++;
      continue;
    }

    const clave = claveValor(c);
    const prev = claves.get(clave);
    if (prev) prev.frecuencia++;
    else claves.set(clave, { valor: c.tipo === "numero" ? String(c.valor) : texto, frecuencia: 1 });

    if (c.tipo === "texto") {
      const superficie = texto;
      const normal = normalizarTexto(superficie);
      if (normal !== "") {
        let m = superficies.get(normal);
        if (!m) {
          m = new Map();
          superficies.set(normal, m);
        }
        m.set(superficie, (m.get(superficie) ?? 0) + 1);
      }
    }

    const n = c.tipo === "numero" ? (c.valor as number) : c.tipo === "texto" ? aNumero(texto) : null;
    if (n !== null) {
      numeros.push(n);
      if (n < 0) negativos++;
      if (n === 0) ceros++;
      if (!Number.isInteger(n)) conDecimales++;
      if (c.tipo === "texto") guardadosComoTexto++;
    } else if (c.tipo === "texto" || c.tipo === "booleano" || c.tipo === "error") {
      noConvertibles++;
    }

    if (c.tipo === "fecha") fechas.push(texto);

    if (c.tipo === "texto") {
      celdasTexto++;
      const largo = [...texto].length;
      longitudTotal += largo;
      longitudMinima = Math.min(longitudMinima, largo);
      longitudMaxima = Math.max(longitudMaxima, largo);
      if (texto !== texto.trim() || /^[\s\u00a0]|[\s\u00a0]$/.test(texto)) conEspaciosExtremos++;
      if (/[ \t]{2,}/.test(texto)) conEspaciosDobles++;
      if (/[\r\n]/.test(texto)) conSaltosDeLinea++;
      if (/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f\u200b-\u200d\ufeff\u00a0]/.test(texto)) conCaracteresRaros++;
      const letras = texto.replace(/[^A-Za-zÁÉÍÓÚÜÑáéíóúüñ]/g, "");
      if (letras.length > 0) {
        if (letras === letras.toLocaleUpperCase("es")) soloMayusculas++;
        else if (letras === letras.toLocaleLowerCase("es")) soloMinusculas++;
        else mixtas++;
      }
      if (/[áéíóúüñÁÉÍÓÚÜÑ]/.test(texto)) conAcentos++;
      if (pareceEmail(texto.trim())) emails++;
      if (pareceUrl(texto.trim())) urls++;
      if (pareceTelefono(texto.trim())) telefonos++;
    }
  }

  const noVacios = hoja.filas.length - vacios;
  const topValores = [...claves.values()]
    .sort((a, b) => b.frecuencia - a.frecuencia || a.valor.localeCompare(b.valor, "es"))
    .slice(0, Math.max(1, Math.min(50, maxTop)))
    .map((x) => ({
      valor: x.valor.length > 120 ? `${x.valor.slice(0, 117)}...` : x.valor,
      frecuencia: x.frecuencia,
      porcentaje: noVacios > 0 ? Math.round((x.frecuencia / noVacios) * 10000) / 100 : 0,
    }));

  const casiDuplicados: GrupoCasiDuplicado[] = [];
  for (const [normal, variantes] of superficies) {
    const distintas = [...variantes.entries()].filter(([v]) => limpiarTexto(v, { colapsarEspacios: true }) !== "");
    if (distintas.length > 1) {
      casiDuplicados.push({
        clave: normal,
        variantes: distintas
          .sort((a, b) => b[1] - a[1])
          .slice(0, 8)
          .map(([valor, frecuencia]) => ({ valor, frecuencia })),
      });
      if (casiDuplicados.length >= 5) break;
    }
  }

  const numericoConvertibles = numeros.length;
  const estadisticas = numericoConvertibles > 0 ? calcularEstadisticas(numeros, 10) : null;
  const fechasOrdenadas = [...fechas].sort();

  const avisos: string[] = [];
  const sugerencias: string[] = [];
  const porcentajeVacios = hoja.filas.length > 0 ? Math.round((vacios / hoja.filas.length) * 10000) / 100 : 0;

  if (vacios > 0) avisos.push(`${vacios} celdas vacias (${porcentajeVacios}% de las filas).`);
  if (porcentajeVacios >= 30) sugerencias.push("Valora descartar o completar las filas con vacios antes de analizar la columna.");
  if (guardadosComoTexto > 0) {
    avisos.push(`${guardadosComoTexto} numeros estan guardados como texto.`);
    sugerencias.push("Convierte esos valores a numero en Excel o revisa el formato de la columna.");
  }
  if (conEspaciosExtremos > 0 || conEspaciosDobles > 0) {
    avisos.push(`${conEspaciosExtremos} celdas tienen espacios en los extremos y ${conEspaciosDobles} tienen espacios dobles.`);
    sugerencias.push("Usa excel_limpiar_datos con recortar_espacios=true y colapsar_espacios=true para normalizar la columna.");
  }
  if (conSaltosDeLinea > 0) avisos.push(`${conSaltosDeLinea} celdas contienen saltos de linea.`);
  if (conCaracteresRaros > 0) {
    avisos.push(`${conCaracteresRaros} celdas contienen caracteres invisibles o de control.`);
    sugerencias.push("Revisa esas celdas: pueden venir de copiar y pegar desde otra aplicacion.");
  }
  if (casiDuplicados.length > 0) {
    avisos.push(`Hay ${casiDuplicados.length} grupos de valores casi duplicados (difieren en mayusculas, acentos o espacios).`);
    sugerencias.push("Unifica esos valores antes de agrupar o contar categorias.");
  }
  const tiposPresentes = Object.entries(tipos).filter(([t, n]) => t !== "vacio" && n > 0).map(([t]) => t);
  if (tiposPresentes.length > 1) avisos.push(`La columna mezcla tipos de dato: ${tiposPresentes.join(", ")}.`);
  if (formulasSinResultado > 0) {
    avisos.push(`${formulasSinResultado} formulas no tienen resultado cacheado y se leyeron como vacias.`);
    sugerencias.push("Abre y guarda el libro en Excel, o usa excel_visual_recalcular_guardar, para calcular las formulas.");
  }
  if (tipos.error > 0) avisos.push(`Hay ${tipos.error} celdas con error de Excel (por ejemplo #N/D, #DIV/0!).`);
  if (noVacios > 1 && claves.size < noVacios) {
    avisos.push(`Hay ${noVacios - claves.size} valores repetidos ademas del primero de cada grupo.`);
    sugerencias.push("Si la columna deberia ser un identificador unico, usa excel_limpiar_datos con quitar_duplicados=true.");
  }
  if (emails > 0 || urls > 0 || telefonos > 0) {
    avisos.push(`Se detectaron ${emails} correos, ${urls} URLs y ${telefonos} telefonos (deteccion aproximada).`);
  }

  return {
    columna: { nombre: columna.nombre, letra: columna.letra, indice: columna.indice },
    filas: hoja.filas.length,
    vacios,
    noVacios,
    porcentajeVacios,
    tipos,
    formulas,
    formulasSinResultado,
    unicos: claves.size,
    duplicadosExtra: Math.max(0, noVacios - claves.size),
    topValores,
    numerico: {
      convertibles: numericoConvertibles,
      noConvertibles,
      guardadosComoTexto,
      negativos,
      ceros,
      conDecimales,
      estadisticas,
    },
    texto: {
      celdas: celdasTexto,
      longitudMinima: celdasTexto > 0 ? longitudMinima : 0,
      longitudMaxima,
      longitudMedia: celdasTexto > 0 ? Math.round((longitudTotal / celdasTexto) * 100) / 100 : 0,
      conEspaciosExtremos,
      conEspaciosDobles,
      conSaltosDeLinea,
      conCaracteresRaros,
      soloMayusculas,
      soloMinusculas,
      mixtas,
      conAcentos,
      parecenEmail: emails,
      parecenUrl: urls,
      parecenTelefono: telefonos,
    },
    fechas: {
      cantidad: fechas.length,
      minima: fechasOrdenadas[0] ?? null,
      maxima: fechasOrdenadas[fechasOrdenadas.length - 1] ?? null,
    },
    casiDuplicados,
    avisos,
    sugerencias,
  };
}
