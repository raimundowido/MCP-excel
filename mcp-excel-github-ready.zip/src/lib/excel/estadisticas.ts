/**
 * Estadistica descriptiva calculada en JavaScript (sin depender de Excel ni de formulas).
 *
 * Metodos:
 *  - Varianza y desviacion estandar MUESTRALES (n-1), que es lo que suele esperar un analisis.
 *  - Cuartiles por interpolacion lineal (metodo 7 de Hyndman-Fan, el de Excel.INC y R tipo 7).
 *  - Atipicos con la regla 1,5 x IQR.
 *  - Intervalo de confianza 95% de la media con t de Student para n<31.
 */
import { ErrorExcel } from "./errores.js";

export interface ModaValor {
  valor: number;
  frecuencia: number;
}

export interface Estadisticas {
  n: number;
  suma: number;
  media: number;
  mediana: number;
  moda: ModaValor[];
  frecuenciaMaxima: number;
  minimo: number;
  maximo: number;
  rango: number;
  varianzaMuestral: number;
  desviacionEstandarMuestral: number;
  varianzaPoblacional: number;
  desviacionEstandarPoblacional: number;
  coeficienteVariacion: number | null;
  errorEstandarMedia: number;
  ic95Media: { inferior: number; superior: number; t: number } | null;
  q1: number;
  q3: number;
  iqr: number;
  limiteInferiorAtipico: number;
  limiteSuperiorAtipico: number;
  atipicos: number[];
  asimetria: number | null;
  curtosisExceso: number | null;
}

function redondear(x: number, decimales = 8): number {
  if (!Number.isFinite(x)) return 0;
  const f = 10 ** decimales;
  return Math.round((x + Number.EPSILON) * f) / f;
}

function cuantil(ordenados: number[], p: number): number {
  const n = ordenados.length;
  if (n === 0) return 0;
  if (n === 1) return ordenados[0]!;
  const h = (n - 1) * p;
  const lo = Math.floor(h);
  const hi = Math.ceil(h);
  const v = ordenados[lo]! + (h - lo) * (ordenados[hi]! - ordenados[lo]!);
  return v;
}

const T95: Record<number, number> = {
  1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571, 6: 2.447, 7: 2.365, 8: 2.306, 9: 2.262, 10: 2.228,
  11: 2.201, 12: 2.179, 13: 2.16, 14: 2.145, 15: 2.131, 16: 2.12, 17: 2.11, 18: 2.101, 19: 2.093, 20: 2.086,
  21: 2.08, 22: 2.074, 23: 2.069, 24: 2.064, 25: 2.06, 26: 2.056, 27: 2.052, 28: 2.048, 29: 2.045, 30: 2.042,
};

export function calcularEstadisticas(numeros: number[], maxAtipicos = 20): Estadisticas {
  const n = numeros.length;
  if (n === 0) {
    throw new ErrorExcel(
      "No hay valores numericos para calcular estadisticas.",
      "Comprueba que la columna elegida contenga numeros o texto convertible a numero (sin letras ni unidades).",
    );
  }
  const ordenados = [...numeros].sort((a, b) => a - b);
  const suma = numeros.reduce((a, b) => a + b, 0);
  const media = suma / n;

  const desviaciones2 = numeros.reduce((a, x) => a + (x - media) ** 2, 0);
  const varianzaMuestral = n > 1 ? desviaciones2 / (n - 1) : 0;
  const varianzaPoblacional = desviaciones2 / n;
  const s = Math.sqrt(varianzaMuestral);
  const sigma = Math.sqrt(varianzaPoblacional);

  const q1 = cuantil(ordenados, 0.25);
  const q3 = cuantil(ordenados, 0.75);
  const iqr = q3 - q1;
  const limiteInferiorAtipico = q1 - 1.5 * iqr;
  const limiteSuperiorAtipico = q3 + 1.5 * iqr;
  const atipicos = numeros.filter((x) => x < limiteInferiorAtipico || x > limiteSuperiorAtipico).slice(0, Math.max(0, maxAtipicos));

  const conteo = new Map<number, number>();
  for (const x of numeros) conteo.set(x, (conteo.get(x) ?? 0) + 1);
  const frecuenciaMaxima = Math.max(...conteo.values());
  const moda: ModaValor[] = [...conteo.entries()]
    .filter(([, f]) => f === frecuenciaMaxima && f > 1)
    .sort((a, b) => a[0] - b[0])
    .slice(0, 5)
    .map(([valor, frecuencia]) => ({ valor, frecuencia }));

  let asimetria: number | null = null;
  if (n >= 3 && s > 0) {
    const m3 = numeros.reduce((a, x) => a + ((x - media) / s) ** 3, 0);
    asimetria = (n / ((n - 1) * (n - 2))) * m3;
  }

  let curtosisExceso: number | null = null;
  if (n >= 4 && s > 0) {
    const m4 = numeros.reduce((a, x) => a + ((x - media) / s) ** 4, 0);
    curtosisExceso =
      (n * (n + 1)) / ((n - 1) * (n - 2) * (n - 3)) * m4 -
      (3 * (n - 1) ** 2) / ((n - 2) * (n - 3));
  }

  const errorEstandarMedia = n > 0 ? s / Math.sqrt(n) : 0;
  let ic95Media: Estadisticas["ic95Media"] = null;
  if (n > 1) {
    const t = n - 1 <= 30 ? T95[n - 1]! : 1.96;
    ic95Media = {
      inferior: media - t * errorEstandarMedia,
      superior: media + t * errorEstandarMedia,
      t,
    };
  }

  return {
    n,
    suma: redondear(suma),
    media: redondear(media),
    mediana: redondear(cuantil(ordenados, 0.5)),
    moda: moda.map((m) => ({ valor: redondear(m.valor), frecuencia: m.frecuencia })),
    frecuenciaMaxima,
    minimo: redondear(ordenados[0]!),
    maximo: redondear(ordenados[n - 1]!),
    rango: redondear(ordenados[n - 1]! - ordenados[0]!),
    varianzaMuestral: redondear(varianzaMuestral),
    desviacionEstandarMuestral: redondear(s),
    varianzaPoblacional: redondear(varianzaPoblacional),
    desviacionEstandarPoblacional: redondear(sigma),
    coeficienteVariacion: media !== 0 ? redondear(s / Math.abs(media)) : null,
    errorEstandarMedia: redondear(errorEstandarMedia),
    ic95Media: ic95Media
      ? { inferior: redondear(ic95Media.inferior), superior: redondear(ic95Media.superior), t: ic95Media.t }
      : null,
    q1: redondear(q1),
    q3: redondear(q3),
    iqr: redondear(iqr),
    limiteInferiorAtipico: redondear(limiteInferiorAtipico),
    limiteSuperiorAtipico: redondear(limiteSuperiorAtipico),
    atipicos: atipicos.map((x) => redondear(x)),
    asimetria: asimetria === null ? null : redondear(asimetria),
    curtosisExceso: curtosisExceso === null ? null : redondear(curtosisExceso),
  };
}
