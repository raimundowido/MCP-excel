/**
 * Comparacion de dos versiones de una tabla (por clave o por posicion).
 *
 * Pensada para revisar cambios entre dos archivos exportados, no para sincronizarlos:
 * no escribe nada y no interpreta reglas de negocio. Los valores se comparan con la
 * misma normalizacion que usa el resto del motor (numeros, fechas ISO, texto).
 */
import { ErrorExcel } from "./errores.js";
import {
  resolverColumna,
  valorDeFila,
  type ColumnaLeida,
  type FilaLeida,
  type HojaLeida,
} from "./libro.js";
import { limpiarTexto, normalizarTexto, type CeldaNormalizada } from "./valor.js";

export interface OpcionesComparar {
  /** Columnas que identifican una fila. Vacio = alineacion posicional. */
  claves: string[];
  maxEjemplos: number;
  ignorarEspacios: boolean;
  ignorarMayusculas: boolean;
  /** Diferencia maxima entre dos numeros para considerarlos iguales. */
  tolerancia: number;
}

export interface CambioCelda {
  columna: string;
  antes: string;
  despues: string;
}

export interface FilaCambiada {
  clave: Record<string, string>;
  filaA: number;
  filaB: number;
  cambios: CambioCelda[];
}

export interface FilaNueva {
  clave: Record<string, string>;
  fila: number;
  valores: Record<string, string>;
}

export interface ResultadoComparacion {
  modo: "clave" | "posicional";
  claves: string[];
  filas: {
    a: number;
    b: number;
    comparadas: number;
    nuevas: number;
    eliminadas: number;
    cambiadas: number;
    sinCambios: number;
    sinClaveA: number;
    sinClaveB: number;
    clavesDuplicadasA: number;
    clavesDuplicadasB: number;
  };
  columnas: {
    comunes: string[];
    soloA: string[];
    soloB: string[];
    mapeadas: { a: string; b: string }[];
  };
  nuevas: FilaNueva[];
  eliminadas: FilaNueva[];
  cambiadas: FilaCambiada[];
  avisos: string[];
}

interface ParColumnas {
  a: ColumnaLeida;
  b: ColumnaLeida;
  nombre: string;
}

interface EntradaFila {
  fila: FilaLeida;
  clave: string;
  claveVisible: Record<string, string>;
  valores: Map<string, CeldaNormalizada>;
}

function buscarColumna(hoja: HojaLeida, nombre: string): ColumnaLeida | null {
  const objetivo = normalizarTexto(nombre);
  return hoja.columnas.find((c) => normalizarTexto(c.nombre) === objetivo) ?? null;
}

function textoComparable(c: CeldaNormalizada, opciones: OpcionesComparar): string {
  if (c.tipo === "vacio" || c.formulaSinResultado) return "";
  if (c.tipo === "numero") return `n:${String(c.valor)}`;
  let t = c.texto;
  if (opciones.ignorarEspacios) t = limpiarTexto(t, { colapsarEspacios: true, quitarSaltos: true });
  if (t === "") return "";
  if (opciones.ignorarMayusculas) t = t.toLocaleLowerCase("es");
  return `${c.tipo}:${t}`;
}

function textoVisible(c: CeldaNormalizada): string {
  if (c.tipo === "vacio" || c.formulaSinResultado) return "";
  return c.texto;
}

function iguales(
  a: CeldaNormalizada,
  b: CeldaNormalizada,
  opciones: OpcionesComparar,
): boolean {
  if (a.tipo === "numero" && b.tipo === "numero") {
    const na = a.valor as number;
    const nb = b.valor as number;
    return Math.abs(na - nb) <= Math.abs(opciones.tolerancia);
  }
  return textoComparable(a, opciones) === textoComparable(b, opciones);
}

function construirEntradas(
  hoja: HojaLeida,
  claves: ColumnaLeida[],
  pares: ParColumnas[],
  opciones: OpcionesComparar,
  etiqueta: "A" | "B",
  avisos: string[],
): { entradas: EntradaFila[]; duplicadas: number; sinClave: number } {
  const entradas: EntradaFila[] = [];
  const vistas = new Set<string>();
  let duplicadas = 0;
  let sinClave = 0;

  for (const fila of hoja.filas) {
    const valores = new Map<string, CeldaNormalizada>();
    for (const par of pares) {
      const col = etiqueta === "A" ? par.a : par.b;
      valores.set(par.nombre, valorDeFila(fila, col));
    }

    const claveVisible: Record<string, string> = {};
    const partesClave: string[] = [];
    for (const col of claves) {
      const celda = valorDeFila(fila, col);
      const visible = textoVisible(celda);
      claveVisible[col.nombre] = visible;
      partesClave.push(textoComparable(celda, opciones));
    }
    const clave = claves.length === 0 ? `#${entradas.length + 1}` : JSON.stringify(partesClave);
    if (claves.length > 0 && partesClave.every((p) => p === "")) {
      sinClave++;
      continue;
    }
    if (claves.length > 0 && vistas.has(clave)) {
      duplicadas++;
      continue;
    }
    vistas.add(clave);
    entradas.push({ fila, clave, claveVisible, valores });
  }

  if (duplicadas > 0) {
    avisos.push(
      `En el archivo ${etiqueta} hay ${duplicadas} fila(s) con una clave repetida; se compara solo la primera de cada clave.`,
    );
  }
  if (sinClave > 0) {
    avisos.push(`En el archivo ${etiqueta} hay ${sinClave} fila(s) con todas las claves vacias; no se comparan.`);
  }
  return { entradas, duplicadas, sinClave };
}

function ejemploClave(entrada: EntradaFila, claves: string[]): Record<string, string> {
  const o: Record<string, string> = {};
  for (const c of claves) o[c] = entrada.claveVisible[c] ?? "";
  return o;
}

function valoresVisibles(entrada: EntradaFila, pares: ParColumnas[]): Record<string, string> {
  const o: Record<string, string> = {};
  for (const par of pares) o[par.nombre] = textoVisible(entrada.valores.get(par.nombre)!);
  return o;
}

export function compararHojas(
  a: HojaLeida,
  b: HojaLeida,
  opciones: OpcionesComparar,
): ResultadoComparacion {
  const avisos: string[] = [];
  const maxEjemplos = Math.max(1, Math.min(100, opciones.maxEjemplos));

  const mapaB = new Map(hojaColumnas(b).map((c) => [normalizarTexto(c.nombre), c]));
  const comunes: ParColumnas[] = [];
  const soloA: string[] = [];
  for (const ca of a.columnas) {
    const cb = mapaB.get(normalizarTexto(ca.nombre));
    if (cb) {
      comunes.push({ a: ca, b: cb, nombre: ca.nombre });
      mapaB.delete(normalizarTexto(ca.nombre));
    } else {
      soloA.push(ca.nombre);
    }
  }
  const soloB = [...mapaB.values()].map((c) => c.nombre);

  if (comunes.length === 0) {
    throw new ErrorExcel(
      "Los dos archivos no tienen columnas en comun (comparando sin mayusculas ni tildes).",
      "Comprueba que elegiste la hoja y el rango correctos en ambos archivos.",
    );
  }
  if (soloA.length > 0) avisos.push(`Columnas solo en el archivo A: ${soloA.join(", ")}.`);
  if (soloB.length > 0) avisos.push(`Columnas solo en el archivo B: ${soloB.join(", ")}.`);
  if (a.truncadoFilas || b.truncadoFilas) {
    avisos.push("Alguno de los archivos se leyo parcialmente por el limite de filas; la comparacion es incompleta.");
  }

  let clavesA: ColumnaLeida[] = [];
  let clavesB: ColumnaLeida[] = [];
  let modo: "clave" | "posicional" = "posicional";
  if (opciones.claves.length > 0) {
    modo = "clave";
    clavesA = opciones.claves.map((n) => resolverColumna(a, n));
    clavesB = clavesA.map((ca) => {
      const cb = buscarColumna(b, ca.nombre);
      if (!cb) {
        throw new ErrorExcel(
          `La columna clave "${ca.nombre}" existe en A pero no en B.`,
          `Columnas de B: ${b.columnas.map((c) => c.nombre).join(", ")}.`,
        );
      }
      return cb;
    });
  } else {
    avisos.push(
      "Sin columnas_clave se comparan las filas por posicion. Si el archivo B agrego o quito filas en medio, los cambios apareceran como diferencias en cascada.",
    );
  }

  const { entradas: entradasA, duplicadas: duplicadasA, sinClave: sinClaveA } = construirEntradas(
    a,
    clavesA,
    comunes,
    opciones,
    "A",
    avisos,
  );
  const { entradas: entradasB, duplicadas: duplicadasB, sinClave: sinClaveB } = construirEntradas(
    b,
    clavesB,
    comunes,
    opciones,
    "B",
    avisos,
  );

  // En modo posicional la clave es el indice, no el contenido.
  if (modo === "posicional") {
    // Ya se asigno "#n" al construir las entradas.
  }

  const mapaA = new Map(entradasA.map((e) => [e.clave, e]));
  const mapaBTodo = new Map(entradasB.map((e) => [e.clave, e]));

  const nuevas: FilaNueva[] = [];
  const eliminadas: FilaNueva[] = [];
  const cambiadas: FilaCambiada[] = [];
  let sinCambios = 0;
  let comparadas = 0;
  let totalCambiadas = 0;

  for (const ea of entradasA) {
    const eb = mapaBTodo.get(ea.clave);
    if (!eb) {
      if (eliminadas.length < maxEjemplos) {
        eliminadas.push({
          clave: modo === "clave" ? ejemploClave(ea, opciones.claves) : { "#": ea.clave.slice(1) },
          fila: ea.fila.numero,
          valores: valoresVisibles(ea, comunes),
        });
      }
      continue;
    }
    comparadas++;
    const cambios: CambioCelda[] = [];
    for (const par of comunes) {
      const ca = ea.valores.get(par.nombre)!;
      const cb = eb.valores.get(par.nombre)!;
      if (!iguales(ca, cb, opciones)) {
        cambios.push({ columna: par.nombre, antes: textoVisible(ca), despues: textoVisible(cb) });
      }
    }
    if (cambios.length === 0) sinCambios++;
    else {
      totalCambiadas++;
      if (cambiadas.length < maxEjemplos) {
        cambiadas.push({
          clave: modo === "clave" ? ejemploClave(ea, opciones.claves) : { "#": ea.clave.slice(1) },
          filaA: ea.fila.numero,
          filaB: eb.fila.numero,
          cambios,
        });
      }
    }
  }

  for (const eb of entradasB) {
    if (!mapaA.has(eb.clave)) {
      if (nuevas.length < maxEjemplos) {
        nuevas.push({
          clave: modo === "clave" ? ejemploClave(eb, opciones.claves) : { "#": eb.clave.slice(1) },
          fila: eb.fila.numero,
          valores: valoresVisibles(eb, comunes),
        });
      }
    }
  }

  return {
    modo,
    claves: modo === "clave" ? clavesA.map((c) => c.nombre) : [],
    filas: {
      a: entradasA.length,
      b: entradasB.length,
      comparadas,
      nuevas: entradasB.filter((e) => !mapaA.has(e.clave)).length,
      eliminadas: entradasA.filter((e) => !mapaBTodo.has(e.clave)).length,
      cambiadas: totalCambiadas,
      sinCambios,
      sinClaveA,
      sinClaveB,
      clavesDuplicadasA: duplicadasA,
      clavesDuplicadasB: duplicadasB,
    },
    columnas: {
      comunes: comunes.map((p) => p.nombre),
      soloA,
      soloB,
      mapeadas: comunes.map((p) => ({ a: p.a.nombre, b: p.b.nombre })),
    },
    nuevas,
    eliminadas,
    cambiadas,
    avisos,
  };
}

function hojaColumnas(h: HojaLeida): ColumnaLeida[] {
  return h.columnas;
}
