#!/usr/bin/env node
/**
 * Pruebas de las herramientas de Excel sobre archivos reales temporales.
 *
 * Genera libros .xlsx y .csv de ejemplo, arranca el MCP como lo haria opencode
 * y comprueba lectura, estadisticas, perfil, filtros, limpieza (simulada y escrita),
 * errores controlados y las herramientas visuales de alto nivel con backend simulado.
 */
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import ExcelJS from "exceljs";
import { existsSync } from "node:fs";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";

let fallos = 0;
function ok(mensaje) {
  console.log(`OK: ${mensaje}`);
}
function fallo(mensaje) {
  fallos++;
  console.error(`FALLO: ${mensaje}`);
}
function afirmar(condicion, mensaje) {
  if (condicion) ok(mensaje);
  else fallo(mensaje);
}

const carpeta = await mkdtemp(path.join(os.tmpdir(), "mcp-excel-test-"));
const archivoXlsx = path.join(carpeta, "ventas.xlsx");
const archivoCsv = path.join(carpeta, "clientes.csv");
const archivoSalida = path.join(carpeta, "ventas_limpio.xlsx");
const archivoV2 = path.join(carpeta, "ventas_v2.xlsx");
const archivoTabla = path.join(carpeta, "tabla.xlsx");
const archivoReporte = path.join(carpeta, "reporte_ventas.html");

async function crearFixtures() {
  const wb = new ExcelJS.Workbook();
  wb.creator = "prueba-mcp-excel";
  const ws = wb.addWorksheet("Ventas");
  ws.addRow(["ID", "Ciudad", "Monto", "Correo"]);
  ws.addRow([1, "Santiago", 1000, "ana@ejemplo.cl"]);
  ws.addRow([2, "Santiago", 2000, "bruno@ejemplo.cl"]);
  ws.addRow([3, "Valparaiso", 3000, " carla@ejemplo.cl "]);
  ws.addRow([4, "Valparaiso", 4000, "diego@ejemplo.cl"]);
  ws.addRow([5, "Concepcion ", 5000, "elena@ejemplo.cl"]);
  ws.addRow([6, "La Serena", "1.500", "felipe@ejemplo.cl"]);
  ws.addRow([7, "", 7000, "gloria@ejemplo.cl"]);
  ws.addRow([1, "Santiago", 1000, "ana@ejemplo.cl"]); // duplicado exacto de la fila 2
  ws.addRow([" ", " ", " ", " "]); // fila sin datos utiles (solo espacios)
  await wb.xlsx.writeFile(archivoXlsx);

  const csv = "\uFEFFNombre;Monto;Ciudad\nAna;100;Santiago\nLuis;200;Valparaiso\n";
  await writeFile(archivoCsv, csv, "utf8");

  // Segunda version: ID 1 igual; 2 cambia monto; 4 desaparece; 5 cambia de texto; 8 es nueva.
  const wb2 = new ExcelJS.Workbook();
  const ws2 = wb2.addWorksheet("Ventas");
  ws2.addRow(["ID", "Ciudad", "Monto", "Correo"]);
  ws2.addRow([1, "Santiago", 1000, "ana@ejemplo.cl"]);
  ws2.addRow([2, "Santiago", 2500, "bruno@ejemplo.cl"]);
  ws2.addRow([3, "Valparaiso", 3000, "carla@ejemplo.cl"]);
  ws2.addRow([5, "Concepción", 5000, "elena@ejemplo.cl"]);
  ws2.addRow([6, "La Serena", "1.500", "felipe@ejemplo.cl"]);
  ws2.addRow([7, "", 7000, "gloria@ejemplo.cl"]);
  ws2.addRow([8, "Temuco", 8000, "hugo@ejemplo.cl"]);
  await wb2.xlsx.writeFile(archivoV2);

  // Libro con una tabla real, para la inspeccion estructural.
  const wbT = new ExcelJS.Workbook();
  const wsT = wbT.addWorksheet("Datos");
  wsT.addTable({
    name: "TablaClientes",
    ref: "A1",
    headerRow: true,
    totalsRow: false,
    columns: [{ name: "ID" }, { name: "Nombre" }],
    rows: [
      [1, "Ana"],
      [2, "Luis"],
    ],
  });
  await wbT.xlsx.writeFile(archivoTabla);
}

function textoDe(resultado) {
  const partes = (resultado.content ?? []).filter((c) => c.type === "text").map((c) => c.text);
  return partes.join("\n");
}

function datosDe(resultado) {
  const t = textoDe(resultado);
  try {
    return JSON.parse(t);
  } catch {
    throw new Error(`La respuesta no es JSON: ${t.slice(0, 300)}`);
  }
}

const transport = new StdioClientTransport({
  command: "node",
  args: ["dist/index.js"],
  env: { ...process.env, VISUAL_BACKEND: "simulado" },
  stderr: "pipe",
});
const client = new Client({ name: "test-excel", version: "1.0.0" });

async function llamar(nombre, args) {
  return client.callTool({ name: nombre, arguments: args });
}

try {
  await crearFixtures();
  await client.connect(transport);

  const { tools } = await client.listTools();
  const nombres = tools.map((t) => t.name);
  const esperadas = [
    "excel_estado",
    "excel_listar_hojas",
    "excel_leer_tabla",
    "excel_estadisticas_columna",
    "excel_perfilar_columna",
    "excel_filtrar_filas",
    "excel_limpiar_datos",
    "excel_plugins_estado",
    "excel_inspeccionar_libro",
    "excel_comparar_archivos",
    "excel_generar_reporte",
    "excel_visual_abrir_archivo",
    "excel_visual_recalcular_guardar",
    "excel_visual_ir_a_celda",
    "excel_ordenar_filas",
    "excel_agrupar_tabla",
    "excel_buscar_reemplazar",
  ];
  afirmar(esperadas.every((n) => nombres.includes(n)), `estan registradas las ${esperadas.length} herramientas de Excel`);

  // ------------------------- lectura -------------------------
  const listado = datosDe(await llamar("excel_listar_hojas", { archivo: archivoXlsx }));
  afirmar(listado.hojas?.some((h) => h.nombre === "Ventas"), "excel_listar_hojas encuentra la hoja Ventas");
  afirmar(listado.hojas?.[0]?.filas >= 10, "excel_listar_hojas informa las filas usadas");

  const tabla = datosDe(await llamar("excel_leer_tabla", { archivo: archivoXlsx, max_filas: 50 }));
  afirmar(tabla.hoja === "Ventas", "excel_leer_tabla usa la primera hoja visible");
  afirmar(tabla.columnas?.map((c) => c.nombre).join(",") === "ID,Ciudad,Monto,Correo", "excel_leer_tabla detecta los encabezados");
  afirmar(tabla.filas?.length >= 8, "excel_leer_tabla devuelve las filas de datos");
  afirmar(tabla.filas?.[0]?.Ciudad === "Santiago", "excel_leer_tabla devuelve objetos por columna");

  const csvLeido = datosDe(await llamar("excel_leer_tabla", { archivo: archivoCsv }));
  afirmar(csvLeido.columnas?.length === 3, "lee un CSV con BOM y delimitador ';'");
  afirmar(csvLeido.filas?.[0]?.["Nombre"] === "Ana", "lee los valores del CSV");

  // ------------------------- estadisticas -------------------------
  const est = datosDe(
    await llamar("excel_estadisticas_columna", { archivo: archivoXlsx, columna: "Monto", max_atipicos: 5 }),
  );
  afirmar(est.estadisticas?.n >= 7, `estadisticas usa los numeros validos (n=${est.estadisticas?.n})`);
  afirmar(typeof est.estadisticas?.media === "number", "estadisticas devuelve la media");
  afirmar(est.estadisticas?.mediana === 2500, "estadisticas calcula la mediana correcta (2500)");
  afirmar(est.textoNumerico >= 1, "estadisticas detecta '1.500' guardado como texto");
  afirmar(typeof est.interpretacion === "string" && est.interpretacion.length > 20, "estadisticas incluye interpretacion");

  const estCsv = datosDe(
    await llamar("excel_estadisticas_columna", { archivo: archivoCsv, columna: "Monto" }),
  );
  afirmar(estCsv.estadisticas?.media === 150, "estadisticas funciona sobre CSV (media 150)");

  // ------------------------- perfil -------------------------
  const perfil = datosDe(
    await llamar("excel_perfilar_columna", { archivo: archivoXlsx, columna: "Correo" }),
  );
  afirmar(perfil.perfil?.noVacios >= 8, "el perfil cuenta valores no vacios");
  afirmar(perfil.perfil?.tipos?.texto >= 8, "el perfil distingue celdas de texto");
  afirmar(
    (perfil.perfil?.avisos ?? []).some((a) => /espacios|correo|@/i.test(a)),
    "el perfil avisa de espacios o correos",
  );

  // ------------------------- filtros -------------------------
  const filtro = datosDe(
    await llamar("excel_filtrar_filas", {
      archivo: archivoXlsx,
      condiciones: [{ columna: "Ciudad", operador: "texto_contiene", valor: "santiago" }],
      max_filas: 20,
    }),
  );
  afirmar(filtro.filasCoincidentes === 3, `filtrar texto sin mayusculas encuentra 3 filas (vio ${filtro.filasCoincidentes})`);
  afirmar(filtro.ejemplosExcluidos?.length > 0, "filtrar devuelve ejemplos excluidos");

  const filtroNum = datosDe(
    await llamar("excel_filtrar_filas", {
      archivo: archivoXlsx,
      condiciones: [{ columna: "Monto", operador: "numero_mayor_igual", valor: 4000 }],
      modo: "todas",
      max_filas: 20,
    }),
  );
  afirmar(filtroNum.filasCoincidentes === 3, `filtrar numero_mayor_igual 4000 encuentra 3 (vio ${filtroNum.filasCoincidentes})`);

  const filtroMalo = await llamar("excel_filtrar_filas", {
    archivo: archivoXlsx,
    condiciones: [{ columna: "NoExiste", operador: "texto_igual", valor: "x" }],
  });
  afirmar(filtroMalo.isError === true, "una columna inexistente devuelve error controlado");

  // ------------------------- limpieza simulada -------------------------
  const simulada = datosDe(
    await llamar("excel_limpiar_datos", {
      archivo: archivoXlsx,
      salida: archivoSalida,
      quitar_duplicados: true,
      descartar_filas_vacias: true,
      simular: true,
    }),
  );
  afirmar(simulada.simulado === true && simulada.escrito === false, "la limpieza simulada no escribe");
  afirmar(simulada.reporte?.eliminadasVacias >= 1, "la limpieza detecta la fila vacia");
  afirmar(simulada.reporte?.filasSalida === 7, `la limpieza deja 7 filas (vio ${simulada.reporte?.filasSalida})`);
  afirmar(!existsSync(archivoSalida), "el archivo de salida no existe tras simular");

  const sinConfirmar = await llamar("excel_limpiar_datos", {
    archivo: archivoXlsx,
    salida: archivoSalida,
    simular: false,
  });
  afirmar(sinConfirmar.isError === true, "escribir sin confirmar=true devuelve error");

  const mismaEntrada = await llamar("excel_limpiar_datos", {
    archivo: archivoXlsx,
    salida: archivoXlsx,
    simular: true,
  });
  afirmar(mismaEntrada.isError === true, "rechaza usar el archivo de entrada como salida");

  // ------------------------- limpieza escrita -------------------------
  const escrita = datosDe(
    await llamar("excel_limpiar_datos", {
      archivo: archivoXlsx,
      salida: archivoSalida,
      quitar_duplicados: true,
      descartar_filas_vacias: true,
      recortar_espacios: true,
      simular: false,
      confirmar: true,
    }),
  );
  afirmar(escrita.escrito === true && escrita.simulado === false, "la limpieza confirmada escribe el archivo");
  afirmar(existsSync(archivoSalida), "el archivo .xlsx de salida existe");
  afirmar(escrita.bytes > 0, "la escritura informa bytes");

  const releido = datosDe(await llamar("excel_leer_tabla", { archivo: archivoSalida, max_filas: 50 }));
  afirmar(releido.filas?.length === 7, `el archivo limpiado tiene 7 filas (vio ${releido.filas?.length})`);
  afirmar(
    releido.filas?.filter((f) => f.ID === 1).length === 1,
    "el archivo limpiado no tiene el duplicado",
  );
  afirmar(
    releido.filas?.some((f) => f.Ciudad === "Concepcion"),
    "el archivo limpiado recorto el espacio final de 'Concepcion'",
  );

  // ------------------------- errores de ruta -------------------------
  const inexistente = await llamar("excel_listar_hojas", { archivo: path.join(carpeta, "no-existe.xlsx") });
  afirmar(inexistente.isError === true, "un archivo inexistente devuelve error controlado");
  afirmar(/no encuentro/i.test(textoDe(inexistente)), "el error explica que no encuentra el archivo");

  // ------------------------- estado -------------------------
  const estado = datosDe(await llamar("excel_estado", {}));
  afirmar(typeof estado.motorArchivos === "object" && estado.motorArchivos !== null, "excel_estado informa el motor de archivos");
  afirmar(typeof estado.avisos?.length === "number", "excel_estado devuelve avisos");

  // ------------------------- inspeccion estructural -------------------------
  const inspeccion = datosDe(await llamar("excel_inspeccionar_libro", { archivo: archivoTabla }));
  afirmar(inspeccion.resumen?.hojas === 1, "la inspeccion cuenta las hojas");
  afirmar(inspeccion.hojas?.[0]?.nombre === "Datos", "la inspeccion lista el nombre de la hoja");
  afirmar(inspeccion.tablas?.[0]?.nombre === "TablaClientes", "la inspeccion detecta la tabla del libro");
  afirmar(inspeccion.tablas?.[0]?.hoja === "Datos", "la inspeccion asocia la tabla con su hoja");
  afirmar(inspeccion.contenedor?.partes > 3, "la inspeccion informa las partes del contenedor OOXML");
  afirmar(typeof inspeccion.propiedades === "object", "la inspeccion devuelve propiedades del documento");
  afirmar(inspeccion.resumen?.macros === false, "la inspeccion no inventa macros en un .xlsx normal");

  const inspeccionCsv = await llamar("excel_inspeccionar_libro", { archivo: archivoCsv });
  afirmar(inspeccionCsv.isError === true, "la inspeccion estructural rechaza un CSV con error controlado");

  // ------------------------- comparacion -------------------------
  const comparacion = datosDe(
    await llamar("excel_comparar_archivos", {
      archivo_a: archivoXlsx,
      archivo_b: archivoV2,
      columnas_clave: ["ID"],
      max_ejemplos: 10,
    }),
  );
  afirmar(comparacion.modo === "clave", "la comparacion usa la columna clave indicada");
  afirmar(comparacion.columnas?.comunes?.length === 4, "la comparacion detecta las 4 columnas comunes");
  afirmar(comparacion.filas?.nuevas === 1, `la comparacion detecta 1 fila nueva (vio ${comparacion.filas?.nuevas})`);
  afirmar(
    comparacion.filas?.eliminadas === 1,
    `la comparacion detecta 1 fila eliminada (vio ${comparacion.filas?.eliminadas})`,
  );
  afirmar(
    comparacion.filas?.cambiadas === 2,
    `la comparacion detecta 2 filas cambiadas (vio ${comparacion.filas?.cambiadas})`,
  );
  afirmar(
    comparacion.cambiadas?.some((c) =>
      c.cambios.some((x) => x.columna === "Monto" && x.antes === "2000" && x.despues === "2500"),
    ),
    "la comparacion muestra el cambio de monto con valores antes/despues",
  );
  afirmar(
    comparacion.avisos?.some((a) => /clave repetida/i.test(a)),
    "la comparacion avisa de la clave ID duplicada en el archivo A",
  );

  const comparacionMala = await llamar("excel_comparar_archivos", {
    archivo_a: archivoXlsx,
    archivo_b: archivoV2,
    columnas_clave: ["NoExiste"],
  });
  afirmar(comparacionMala.isError === true, "una columna clave inexistente devuelve error controlado");

  // ------------------------- reporte HTML -------------------------
  const reporte = datosDe(
    await llamar("excel_generar_reporte", {
      archivo: archivoXlsx,
      salida: archivoReporte,
      max_muestra: 5,
      max_valores: 5,
    }),
  );
  afirmar(existsSync(archivoReporte), "el reporte HTML se escribe en disco");
  afirmar(reporte.bytes > 1000, "el reporte informa un tamano razonable");
  const html = await readFile(archivoReporte, "utf8");
  afirmar(html.startsWith("<!doctype html>"), "el reporte es un documento HTML completo");
  afirmar(html.includes("Reporte de Ventas"), "el reporte incluye el nombre de la hoja");
  afirmar(/Content-Security-Policy/.test(html), "el reporte incluye una CSP sin red");
  afirmar(!/<script\b/i.test(html), "el reporte no contiene scripts");
  afirmar(html.includes("Calidad por columna"), "el reporte incluye la seccion de calidad");

  const reporteRepetido = await llamar("excel_generar_reporte", {
    archivo: archivoXlsx,
    salida: archivoReporte,
  });
  afirmar(reporteRepetido.isError === true, "el reporte no sobrescribe sin confirmacion");

  const reporteSobrescrito = await llamar("excel_generar_reporte", {
    archivo: archivoXlsx,
    salida: archivoReporte,
    sobrescribir: true,
    confirmar: true,
  });
  afirmar(reporteSobrescrito.isError !== true, "el reporte se puede sobrescribir con confirmar=true");

  // ------------------------- ordenar filas -------------------------
  const ordenadoSim = datosDe(
    await llamar("excel_ordenar_filas", {
      archivo: archivoXlsx,
      orden: [{ columna: "Monto", direccion: "desc" }],
      simular: true,
    }),
  );
  afirmar(ordenadoSim.simulado === true && ordenadoSim.escrito === false, "ordenar simulado no escribe");
  afirmar(ordenadoSim.orden?.[0]?.columna === "Monto", "ordenar informa la clave de orden");
  afirmar(Array.isArray(ordenadoSim.vistaPrevia) && ordenadoSim.vistaPrevia.length > 0, "ordenar devuelve vista previa");

  const archivoOrdenado = path.join(carpeta, "ventas_ordenado.xlsx");
  const ordenadoEsc = datosDe(
    await llamar("excel_ordenar_filas", {
      archivo: archivoXlsx,
      salida: archivoOrdenado,
      orden: [{ columna: "Monto", direccion: "desc" }],
      simular: false,
      confirmar: true,
    }),
  );
  afirmar(ordenadoEsc.escrito === true, "ordenar confirmado escribe el archivo");
  const releidoOrd = datosDe(await llamar("excel_leer_tabla", { archivo: archivoOrdenado, max_filas: 50 }));
  afirmar(releidoOrd.filas?.length >= 7, "el archivo ordenado conserva las filas");
  const montos = (releidoOrd.filas ?? []).map((f) => f.Monto).filter((v) => typeof v === "number");
  afirmar(
    montos.length >= 2 && montos[0] >= montos[montos.length - 1],
    "el archivo ordenado esta en orden descendente por Monto",
  );

  // ------------------------- agrupar tabla -------------------------
  const agrupadoSim = datosDe(
    await llamar("excel_agrupar_tabla", {
      archivo: archivoXlsx,
      agrupar_por: ["Ciudad"],
      agregaciones: [{ columna: "Monto", funcion: "suma" }],
      simular: true,
    }),
  );
  afirmar(agrupadoSim.simulado === true, "agrupar simulado no escribe");
  afirmar(Array.isArray(agrupadoSim.encabezados) && agrupadoSim.encabezados.includes("Ciudad"), "agrupar devuelve encabezados");
  afirmar((agrupadoSim.grupos ?? 0) >= 3, `agrupar detecta grupos por ciudad (vio ${agrupadoSim.grupos})`);

  const archivoAgrupado = path.join(carpeta, "ventas_agrupado.xlsx");
  const agrupadoEsc = datosDe(
    await llamar("excel_agrupar_tabla", {
      archivo: archivoXlsx,
      salida: archivoAgrupado,
      agrupar_por: ["Ciudad"],
      agregaciones: [{ columna: "Monto", funcion: "conteo" }],
      simular: false,
      confirmar: true,
    }),
  );
  afirmar(agrupadoEsc.escrito === true, "agrupar confirmado escribe el archivo");

  // ------------------------- buscar y reemplazar -------------------------
  const reempSim = datosDe(
    await llamar("excel_buscar_reemplazar", {
      archivo: archivoXlsx,
      buscar: "santiago",
      reemplazar: "Santiago Centro",
      simular: true,
    }),
  );
  afirmar(reempSim.simulado === true, "buscar/reemplazar simulado no escribe");
  afirmar((reempSim.reemplazos ?? 0) >= 1, `buscar/reemplazar detecta ocurrencias (vio ${reempSim.reemplazos})`);

  const archivoReemp = path.join(carpeta, "ventas_reemplazado.xlsx");
  const reempEsc = datosDe(
    await llamar("excel_buscar_reemplazar", {
      archivo: archivoXlsx,
      buscar: "santiago",
      reemplazar: "Santiago Centro",
      salida: archivoReemp,
      simular: false,
      confirmar: true,
    }),
  );
  afirmar(reempEsc.escrito === true, "buscar/reemplazar confirmado escribe el archivo");
  const releidoReemp = datosDe(await llamar("excel_leer_tabla", { archivo: archivoReemp, max_filas: 50 }));
  afirmar(
    (releidoReemp.filas ?? []).some((f) => String(f.Ciudad ?? "").includes("Santiago Centro")),
    "el archivo reemplazado contiene el nuevo texto",
  );

  const reempMalo = await llamar("excel_buscar_reemplazar", {
    archivo: archivoXlsx,
    buscar: "no-existe-xyz",
    reemplazar: "x",
    simular: false,
    confirmar: true,
  });
  afirmar(reempMalo.isError === true, "buscar/reemplazar sin ocurrencias no escribe y devuelve error");

  // ------------------------- visual (backend simulado) -------------------------
  const ir = await llamar("excel_visual_ir_a_celda", { referencia: "B2" });
  afirmar(ir.isError !== true, "excel_visual_ir_a_celda se ejecuta con backend simulado");
  afirmar((ir.content ?? []).some((c) => c.type === "image"), "la herramienta visual devuelve una captura");

  const recalcular = await llamar("excel_visual_recalcular_guardar", { confirmar: true });
  afirmar(recalcular.isError !== true, "excel_visual_recalcular_guardar se ejecuta con confirmar=true");
  afirmar(
    /F9 y Ctrl\+S/.test(textoDe(recalcular)),
    "la herramienta visual confirma que envio F9 y Ctrl+S",
  );

  const abrir = await llamar("excel_visual_abrir_archivo", { archivo: archivoXlsx, espera_ms: 500 });
  afirmar(abrir.isError !== true, "excel_visual_abrir_archivo se ejecuta con backend simulado");
  afirmar((abrir.content ?? []).some((c) => c.type === "image"), "abrir archivo devuelve captura de verificacion");

  const abrirMal = await llamar("excel_visual_abrir_archivo", { archivo: path.join(carpeta, "fantasma.xlsx") });
  afirmar(abrirMal.isError === true, "abrir un archivo inexistente falla antes de tocar el teclado");

  await client.close();
} catch (e) {
  fallo(e instanceof Error ? e.message : String(e));
} finally {
  await client.close().catch(() => {});
  await rm(carpeta, { recursive: true, force: true }).catch(() => {});
}

if (fallos > 0) {
  console.error(`\n${fallos} prueba(s) fallaron.`);
  process.exit(1);
}
console.log("\nPruebas de Excel superadas.");
