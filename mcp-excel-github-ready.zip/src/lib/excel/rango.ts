/**
 * Utilidades de direcciones A1 de Excel.
 *
 * Solo se aceptan referencias locales (sin nombre de hoja ni libro externo) para que
 * no se puedan construir formulas ni referencias a otros archivos.
 */
import { ErrorExcel } from "./errores.js";

export const MAX_FILA = 1_048_576;
export const MAX_COLUMNA = 16_384;

export interface RangoA1 {
  filaInicio: number;
  colInicio: number;
  filaFin: number;
  colFin: number;
}

const RE_RANGO = /^\$?([A-Za-z]{1,3})\$?([1-9]\d{0,6})(?::\$?([A-Za-z]{1,3})\$?([1-9]\d{0,6}))?$/;

export function letraAColumna(letra: string): number {
  const limpia = letra.trim().toUpperCase();
  if (!/^[A-Z]{1,3}$/.test(limpia)) {
    throw new ErrorExcel(`La letra de columna "${letra}" no es valida. Usa A, B, ..., Z, AA, AB...`);
  }
  let n = 0;
  for (const c of limpia) n = n * 26 + (c.charCodeAt(0) - 64);
  if (n < 1 || n > MAX_COLUMNA) {
    throw new ErrorExcel(`La columna "${letra}" queda fuera de Excel (maximo XFD).`);
  }
  return n;
}

export function columnaALetra(n: number): string {
  if (!Number.isInteger(n) || n < 1 || n > MAX_COLUMNA) {
    throw new ErrorExcel(`El numero de columna ${n} no es valido (1 a ${MAX_COLUMNA}).`);
  }
  let x = n;
  let out = "";
  while (x > 0) {
    const r = (x - 1) % 26;
    out = String.fromCharCode(65 + r) + out;
    x = Math.floor((x - 1) / 26);
  }
  return out;
}

/** Convierte "A1:C10", "A1" o "$A$1:$C$10" en indices 1-based. */
export function parsearRango(texto: string): RangoA1 {
  const t = texto.trim();
  if (t.length === 0 || t.length > 40) throw new ErrorExcel("El rango esta vacio o es demasiado largo.");
  const m = RE_RANGO.exec(t);
  if (!m) {
    throw new ErrorExcel(`El rango "${texto}" no es valido. Ejemplos: A1, A1:D100, B2:F500.`);
  }
  const colInicio = letraAColumna(m[1]!);
  const filaInicio = Number(m[2]);
  const colFin = m[3] ? letraAColumna(m[3]) : colInicio;
  const filaFin = m[4] ? Number(m[4]) : filaInicio;
  if (filaInicio > MAX_FILA || filaFin > MAX_FILA) {
    throw new ErrorExcel(`El rango supera la ultima fila de Excel (${MAX_FILA}).`);
  }
  if (filaFin < filaInicio || colFin < colInicio) {
    throw new ErrorExcel("El rango esta invertido: la esquina final debe estar a la derecha y abajo de la inicial.");
  }
  return { filaInicio, colInicio, filaFin, colFin };
}

export function rangoATexto(r: RangoA1): string {
  const a = `${columnaALetra(r.colInicio)}${r.filaInicio}`;
  const b = `${columnaALetra(r.colFin)}${r.filaFin}`;
  return a === b ? a : `${a}:${b}`;
}

/** Normaliza "c" / "3" / "Edad" para resolver columnas por letra, indice o nombre. */
export function pareceLetraDeColumna(texto: string): boolean {
  return /^[A-Za-z]{1,3}$/.test(texto.trim());
}

export function pareceIndiceDeColumna(texto: string): boolean {
  return /^[1-9]\d{0,4}$/.test(texto.trim());
}
