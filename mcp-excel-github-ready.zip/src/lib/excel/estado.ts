/**
 * Deteccion NO invasiva del estado de Excel y de sus complementos.
 *
 * Solo se consulta el registro de Windows, la ruta del ejecutable y los nombres de archivo
 * de las carpetas XLSTART. No se abre Excel, no se leen archivos de complementos y no se
 * inspecciona codigo propietario.
 */
import { readFile } from "node:fs/promises";
import { createRequire } from "node:module";
import { run } from "../exec.js";
import { carpetasPermitidas } from "./rutas.js";

interface ProcesoExcel {
  id: number;
  responding: boolean;
}

interface AddinRegistro {
  nombre: string;
  raiz: string;
  loadBehavior: number | null;
  friendlyName: string | null;
  description: string | null;
  manifest: string | null;
}

export interface DeteccionExcel {
  ok: boolean;
  error: string | null;
  sistema: { plataforma: string; version: string; arquitectura: string };
  excel: {
    instalado: boolean;
    ruta: string | null;
    versionArchivo: string | null;
    versionProducto: string | null;
    progId: string | null;
    clsid: string | null;
    procesoActivo: boolean;
    procesos: ProcesoExcel[];
  };
  clickToRun: { version?: string; platform?: string; culture?: string; updateChannel?: string } | null;
  addins: AddinRegistro[];
  xlstart: { carpeta: string; archivos: string[] }[];
  versionesOffice: string[];
}

const PS_DETECCION = String.raw`
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

function Leer-Default([string]$ruta) {
  try { (Get-ItemProperty -LiteralPath $ruta -ErrorAction Stop).'(default)' } catch { $null }
}

try {
  $appPath = Leer-Default 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\excel.exe'
  if (-not $appPath) { $appPath = Leer-Default 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\excel.exe' }
  if (-not $appPath) {
    $cmd = Leer-Default 'Registry::HKEY_CLASSES_ROOT\Excel.Application\shell\open\command'
    if ($cmd -match '"([^"]+)"') { $appPath = $Matches[1] }
  }
  if ($appPath) { $appPath = $appPath.Trim('"') }

  $versionFile = $null
  $versionProduct = $null
  if ($appPath -and (Test-Path -LiteralPath $appPath)) {
    $vi = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($appPath)
    $versionFile = $vi.FileVersion
    $versionProduct = $vi.ProductVersion
  }

  $procs = @(Get-Process -Name EXCEL -ErrorAction SilentlyContinue)
  $procInfo = @($procs | ForEach-Object { [ordered]@{ id = $_.Id; responding = [bool]$_.Responding } })

  $curVer = Leer-Default 'Registry::HKEY_CLASSES_ROOT\Excel.Application\CurVer'
  $clsid = $null
  if ($curVer) { $clsid = Leer-Default ('Registry::HKEY_CLASSES_ROOT\' + $curVer + '\CLSID') }

  $click = $null
  $ctr = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration' -ErrorAction SilentlyContinue
  if ($ctr) {
    $click = [ordered]@{
      version = $ctr.VersionToReport
      platform = $ctr.Platform
      culture = $ctr.ClientCulture
      updateChannel = $ctr.CDNBaseUrl
    }
  }

  $addins = @()
  $rutas = @(
    'HKCU:\Software\Microsoft\Office\Excel\Addins',
    'HKLM:\SOFTWARE\Microsoft\Office\Excel\Addins',
    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\Excel\Addins'
  )
  foreach ($r in $rutas) {
    if (Test-Path -LiteralPath $r) {
      Get-ChildItem -LiteralPath $r -ErrorAction SilentlyContinue | ForEach-Object {
        $p = Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction SilentlyContinue
        $raiz = if ($r -like 'HKCU*') { 'HKCU' } elseif ($r -like '*WOW6432Node*') { 'HKLM-WOW6432' } else { 'HKLM' }
        $addins += [ordered]@{
          nombre = $_.PSChildName
          raiz = $raiz
          loadBehavior = $p.LoadBehavior
          friendlyName = $p.FriendlyName
          description = $p.Description
          manifest = $p.Manifest
        }
      }
    }
  }

  $xlstart = @()
  $candidatas = @(
    (Join-Path $env:APPDATA 'Microsoft\Excel\XLSTART'),
    (Join-Path $env:ProgramFiles 'Microsoft Office\root\Office16\XLSTART'),
    (Join-Path ([System.Environment]::GetEnvironmentVariable('ProgramFiles(x86)')) 'Microsoft Office\root\Office16\XLSTART')
  )
  $carpetas = $candidatas | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique
  foreach ($c in $carpetas) {
    $archivos = @(Get-ChildItem -LiteralPath $c -File -ErrorAction SilentlyContinue | Select-Object -First 100 | ForEach-Object { $_.Name })
    $xlstart += [ordered]@{ carpeta = $c; archivos = $archivos }
  }

  $versiones = @()
  foreach ($base in @('HKCU:\Software\Microsoft\Office','HKLM:\SOFTWARE\Microsoft\Office')) {
    if (Test-Path -LiteralPath $base) {
      $versiones += @(Get-ChildItem -LiteralPath $base -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -match '^\d+\.\d+$' } | ForEach-Object { $_.PSChildName })
    }
  }

  [ordered]@{
    ok = $true
    error = $null
    sistema = [ordered]@{
      plataforma = 'win32'
      version = [System.Environment]::OSVersion.VersionString
      arquitectura = $env:PROCESSOR_ARCHITECTURE
    }
    excel = [ordered]@{
      instalado = [bool]$appPath
      ruta = $appPath
      versionArchivo = $versionFile
      versionProducto = $versionProduct
      progId = $curVer
      clsid = $clsid
      procesoActivo = ($procs.Count -gt 0)
      procesos = $procInfo
    }
    clickToRun = $click
    addins = $addins
    xlstart = $xlstart
    versionesOffice = $versiones | Select-Object -Unique
  } | ConvertTo-Json -Depth 8 -Compress
} catch {
  [ordered]@{ ok = $false; error = $_.Exception.Message } | ConvertTo-Json -Compress
}
`;

let cache: { fecha: number; datos: DeteccionExcel } | null = null;
const TTL_MS = 15_000;

function deteccionVacia(error: string): DeteccionExcel {
  return {
    ok: false,
    error,
    sistema: { plataforma: process.platform, version: "desconocida", arquitectura: process.arch },
    excel: {
      instalado: false,
      ruta: null,
      versionArchivo: null,
      versionProducto: null,
      progId: null,
      clsid: null,
      procesoActivo: false,
      procesos: [],
    },
    clickToRun: null,
    addins: [],
    xlstart: [],
    versionesOffice: [],
  };
}

export async function detectarExcel(forzar = false): Promise<DeteccionExcel> {
  if (!forzar && cache && Date.now() - cache.fecha < TTL_MS) return cache.datos;
  if (process.platform !== "win32") {
    const datos = deteccionVacia("Este MCP lee archivos en cualquier sistema, pero la deteccion de Excel y complementos solo funciona en Windows.");
    cache = { fecha: Date.now(), datos };
    return datos;
  }

  const cod = Buffer.from(PS_DETECCION, "utf16le").toString("base64");
  const r = await run(
    "powershell.exe",
    ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", cod],
    { timeoutMs: 25_000 },
  );
  if (r.code !== 0) {
    const datos = deteccionVacia(`PowerShell fallo (codigo ${r.code}): ${r.stderr.slice(0, 400)}`);
    cache = { fecha: Date.now(), datos };
    return datos;
  }
  try {
    const parsed = JSON.parse(r.stdout.trim()) as Partial<DeteccionExcel>;
    if (!parsed || parsed.ok !== true) {
      const datos = deteccionVacia(String(parsed?.error ?? "PowerShell no devolvio datos utiles."));
      cache = { fecha: Date.now(), datos };
      return datos;
    }
    const datos: DeteccionExcel = {
      ok: true,
      error: null,
      sistema: parsed.sistema ?? { plataforma: "win32", version: "desconocida", arquitectura: process.arch },
      excel: parsed.excel ?? deteccionVacia("sin datos").excel,
      clickToRun: parsed.clickToRun ?? null,
      addins: Array.isArray(parsed.addins) ? parsed.addins : [],
      xlstart: Array.isArray(parsed.xlstart) ? parsed.xlstart : [],
      versionesOffice: Array.isArray(parsed.versionesOffice) ? parsed.versionesOffice : [],
    };
    cache = { fecha: Date.now(), datos };
    return datos;
  } catch (e) {
    const datos = deteccionVacia(`No pude interpretar la deteccion de Excel: ${e instanceof Error ? e.message : String(e)}`);
    cache = { fecha: Date.now(), datos };
    return datos;
  }
}

async function versionExcelJS(): Promise<string> {
  try {
    const req = createRequire(import.meta.url);
    const p = req.resolve("exceljs/package.json");
    const json = JSON.parse(await readFile(p, "utf8")) as { version?: string };
    return json.version ?? "desconocida";
  } catch {
    return "4.x";
  }
}

export interface EstadoCompleto {
  servidor: string;
  sistema: Record<string, string>;
  excel: DeteccionExcel["excel"];
  clickToRun: DeteccionExcel["clickToRun"];
  motorArchivos: Record<string, unknown>;
  permisos: Record<string, unknown>;
  deteccion: { ok: boolean; error: string | null };
  avisos: string[];
}

export async function estadoExcel(): Promise<EstadoCompleto> {
  const d = await detectarExcel();
  const avisos: string[] = [];
  if (!d.ok) avisos.push(d.error ?? "No se pudo detectar Excel.");
  else if (!d.excel.instalado) avisos.push("No encontre Excel instalado. Las herramientas de archivo (.xlsx/.csv) pueden seguir funcionando.");
  if (d.excel.procesoActivo) {
    avisos.push("Excel esta abierto. Los cambios sin guardar no son visibles para las herramientas de archivo: guarda el libro antes de leerlo.");
  }
  if (!d.excel.progId) avisos.push("No encontre el ProgID de Excel en el registro; puede ser una instalacion portable o incompleta.");

  return {
    servidor: "excel",
    sistema: {
      plataforma: process.platform,
      version: d.sistema.version,
      arquitectura: d.sistema.arquitectura,
      node: process.version,
    },
    excel: d.excel,
    clickToRun: d.clickToRun,
    motorArchivos: {
      exceljs: await versionExcelJS(),
      lectura: [".xlsx", ".xlsm", ".csv"],
      escritura: [".xlsx", ".csv"],
      calculaFormulas: false,
      nota: "Se usan los valores cacheados del archivo. Para recalcular, abre y guarda en Excel o usa la herramienta visual de recalculo.",
    },
    permisos: {
      carpetasPermitidas: carpetasPermitidas().length > 0 ? carpetasPermitidas() : null,
      variableCarpetas: "EXCEL_DIRS",
      tamanoMaximoMB: Number(process.env.EXCEL_MAX_MB) > 0 ? Number(process.env.EXCEL_MAX_MB) : 100,
      escritura: true,
      confirmacionParaEscribir: true,
      notas: "No se ejecutan macros ni comandos de shell. Las rutas se validan y se resuelven enlaces simbolicos.",
    },
    deteccion: { ok: d.ok, error: d.error },
    avisos,
  };
}

export interface PluginConocido {
  id: string;
  nombre: string;
  categoria: "A" | "B" | "C" | "D";
  licencia: string;
  enlace: string;
  queAporta: string;
  comoAprovechar: string;
  detectable: boolean;
  estado: "detectado_habilitado" | "detectado_deshabilitado" | "no_detectado" | "no_detectable" | "incluido_sin_evidencia";
  evidencias: string[];
  nota: string | null;
}

interface DefinicionPlugin {
  id: string;
  nombre: string;
  categoria: "A" | "B" | "C" | "D";
  licencia: string;
  enlace: string;
  queAporta: string;
  comoAprovechar: string;
  patrones: string[];
  incluido?: boolean;
  detectable?: boolean;
  nota?: string;
}

const DEFINICIONES: DefinicionPlugin[] = [
  {
    id: "analysis_toolpak",
    nombre: "Analysis ToolPak (Herramientas para analisis)",
    categoria: "A",
    licencia: "Incluido con Excel (complemento que se activa en Opciones > Complementos)",
    enlace: "https://support.microsoft.com/office/load-the-analysis-toolpak-in-excel-6a63e598-cd6d-42d3-931b-b2f9b0e2f0e4",
    queAporta: "Funciones y utiles de estadistica descriptiva, regresion, histogramas y ANOVA.",
    comoAprovechar: "Este MCP implementa la parte de estadistica descriptiva sin depender del complemento. Si esta activo, puedes usar sus funciones de Excel en el libro; el MCP las respeta al leer resultados cacheados.",
    patrones: ["analysis toolpak", "analysis toolpack", "analys32", "atpvbaen"],
    incluido: true,
  },
  {
    id: "solver",
    nombre: "Solver",
    categoria: "A",
    licencia: "Incluido con Excel (complemento que se activa en Opciones > Complementos)",
    enlace: "https://support.microsoft.com/office/load-the-solver-add-in-in-excel-612926fc-d53b-46b4-872c-e24772f078ca",
    queAporta: "Optimizacion lineal y no lineal con restricciones (maximizar, minimizar, alcanzar un objetivo).",
    comoAprovechar: "Se detecta su presencia. La optimizacion no se replica en esta version; si lo necesitas, usa Solver en Excel y vuelve a leer los resultados con el MCP.",
    patrones: ["solver"],
    incluido: true,
    nota: "Detectado, pero no automatizado: ejecutar Solver requiere la interfaz de Excel o macros.",
  },
  {
    id: "power_query",
    nombre: "Power Query",
    categoria: "A",
    licencia: "Incluido en Excel 2016+ y Microsoft 365",
    enlace: "https://learn.microsoft.com/power-query/power-query-what-is-power-query",
    queAporta: "Extraccion, transformacion y carga de datos (ETL) con el lenguaje M, consultas combinadas y actualizacion.",
    comoAprovechar: "Se detecta el entorno de Office. Las consultas guardadas se respetan como datos del libro; este MCP no ejecuta M ni actualiza consultas. Para ETL complejo, prepara la consulta en Excel y lee el resultado con excel_leer_tabla.",
    patrones: ["power query", "microsoft.mashup", "mashup"],
    incluido: true,
    nota: "La actualizacion de consultas necesita Excel en primer plano; no se hace desde archivo.",
  },
  {
    id: "power_pivot",
    nombre: "Power Pivot",
    categoria: "A",
    licencia: "Incluido en Microsoft 365 y algunas ediciones de Excel",
    enlace: "https://support.microsoft.com/office/power-pivot-overview-and-learning-f9354c98-4f27-4d1e-9c1e-7b3e2b0c0f5a",
    queAporta: "Modelo de datos, relaciones, medidas DAX y tablas dinamicas de alto volumen.",
    comoAprovechar: "Se detecta el complemento COM. El MCP lee los valores ya calculados en las hojas; no crea medidas DAX ni actualiza el modelo.",
    patrones: ["power pivot", "powerpivot"],
    incluido: true,
    nota: "Detectado, pero no automatizado.",
  },
  {
    id: "inquire",
    nombre: "Inquire",
    categoria: "A",
    licencia: "Incluido en Microsoft 365 (complemento COM)",
    enlace: "https://support.microsoft.com/office/inquire-about-worksheet-changes-9d1f1b8f-2d8a-4d8a-9c5c-6f0f3c1d0f7a",
    queAporta: "Auditoria de libros: relaciones entre hojas, formulas, celdas dependientes, comparacion de versiones.",
    comoAprovechar: "Se detecta el complemento COM. El MCP no lo invoca; si esta activo, puedes auditar el libro en Excel y luego leer los resultados.",
    patrones: ["inquire"],
    incluido: true,
    nota: "Detectado, pero no automatizado.",
  },
  {
    id: "office_scripts",
    nombre: "Office Scripts",
    categoria: "A",
    licencia: "Incluido con Microsoft 365 (requiere cuenta y conexion; no disponible en todas las ediciones)",
    enlace: "https://learn.microsoft.com/office/dev/scripts/overview/excel",
    queAporta: "Automatizacion con TypeScript/JavaScript dentro de Excel y ejecucion programada con Power Automate.",
    comoAprovechar: "No se ejecuta desde este MCP porque requiere el servicio en la nube y permisos del tenant. Si tu organizacion lo tiene, puedes usar Office Scripts para tareas que el MCP no cubre.",
    patrones: [],
    incluido: true,
    detectable: false,
    nota: "No detectable localmente de forma fiable.",
  },
  {
    id: "kutools",
    nombre: "Kutools for Excel",
    categoria: "B",
    licencia: "De pago (licencia por equipo; consulta precio vigente en el sitio del fabricante)",
    enlace: "https://www.extendoffice.com/product/kutools-for-excel.html",
    queAporta: "Cientos de utilidades de productividad: conversion por lotes, combinacion de libros, limpieza, navegacion y edicion avanzada.",
    comoAprovechar: "Si ya lo tienes instalado, puedes usar sus comandos en Excel. El MCP lo detecta y no lo emula ni lo piratea. Nuestras herramientas propias cubren estadistica, perfilado y limpieza basica sin depender de Kutools.",
    patrones: ["kutools", "extendoffice"],
    nota: "Categoria B: recomendacion opcional, nunca se instala ni se emula.",
  },
  {
    id: "ablebits",
    nombre: "Ablebits Ultimate Suite for Excel",
    categoria: "B",
    licencia: "De pago (suscripcion o licencia; consulta precio vigente en el sitio del fabricante)",
    enlace: "https://www.ablebits.com/excel-suite/index.php",
    queAporta: "Limpeza de datos, comparacion de tablas, busqueda de duplicados, division de texto y herramientas de fechas.",
    comoAprovechar: "Si ya lo tienes instalado, puedes usarlo en Excel. El MCP lo detecta y ofrece alternativas propias para las tareas mas comunes de limpieza.",
    patrones: ["ablebits", "able bits"],
    nota: "Categoria B: recomendacion opcional.",
  },
  {
    id: "modelrisk",
    nombre: "ModelRisk",
    categoria: "B",
    licencia: "De pago (licencia comercial; consulta precio vigente en el sitio del fabricante)",
    enlace: "https://www.vosesoftware.com/products/modelrisk/",
    queAporta: "Simulacion Monte Carlo, analisis de riesgo y ajuste de distribuciones dentro de Excel.",
    comoAprovechar: "Si ya lo tienes, ejecuta el modelo en Excel y lee los resultados con el MCP. No se replica la simulacion.",
    patrones: ["modelrisk", "vose"],
    nota: "Categoria B: recomendacion opcional.",
  },
  {
    id: "at_risk",
    nombre: "@RISK",
    categoria: "B",
    licencia: "De pago (licencia comercial; consulta precio vigente en el sitio del fabricante)",
    enlace: "https://www.palisade.com/risk/",
    queAporta: "Analisis de riesgo y simulacion Monte Carlo para modelos financieros y operativos.",
    comoAprovechar: "Si ya lo tienes, ejecuta la simulacion en Excel y lee los resultados con el MCP. No se replica la simulacion.",
    patrones: ["@risk", "at risk", "palisade"],
    nota: "Categoria B: recomendacion opcional.",
  },
  {
    id: "xltools",
    nombre: "XLTools",
    categoria: "B",
    licencia: "De pago (suscripcion; consulta precio vigente en el sitio del fabricante)",
    enlace: "https://xltools.net/",
    queAporta: "Utilidades de productividad, datos, fechas y limpieza para Excel.",
    comoAprovechar: "Si ya lo tienes, usalo en Excel. El MCP lo detecta y no lo emula.",
    patrones: ["xltools"],
    nota: "Categoria B: recomendacion opcional.",
  },
];

function normalizar(s: string): string {
  return s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase("es")
    .replace(/\s+/g, " ")
    .trim();
}

function evidenciasDe(d: DeteccionExcel): string[] {
  const out: string[] = [];
  for (const a of d.addins) {
    out.push(a.nombre);
    if (a.friendlyName) out.push(a.friendlyName);
    if (a.description) out.push(a.description);
    if (a.manifest) out.push(a.manifest);
  }
  for (const x of d.xlstart) for (const f of x.archivos) out.push(f);
  return out;
}

export interface EstadoPlugins {
  ok: boolean;
  error: string | null;
  excelInstalado: boolean;
  excelAbierto: boolean;
  totalAddins: number;
  addins: AddinRegistro[];
  xlstart: { carpeta: string; archivos: string[] }[];
  conocidos: PluginConocido[];
  desconocidos: { nombre: string; raiz: string; loadBehavior: number | null; habilitado: boolean | null }[];
  notas: string[];
}

export async function estadoPlugins(forzar = false): Promise<EstadoPlugins> {
  const d = await detectarExcel(forzar);
  const evidencias = evidenciasDe(d).map((e) => ({ original: e, normal: normalizar(e) }));
  const conocidos: PluginConocido[] = DEFINICIONES.map((def) => {
    const patrones = def.patrones.map(normalizar).filter(Boolean);
    const encontradas = evidencias.filter((e) => patrones.some((p) => e.normal.includes(p))).map((e) => e.original);
    const addinsCoincidentes = d.addins.filter((a) => {
      const campos = [a.nombre, a.friendlyName, a.description, a.manifest].filter(Boolean).map((s) => normalizar(String(s)));
      return patrones.some((p) => campos.some((c) => c.includes(p)));
    });
    let estado: PluginConocido["estado"];
    if (def.detectable === false) estado = "no_detectable";
    else if (addinsCoincidentes.some((a) => a.loadBehavior === 3)) estado = "detectado_habilitado";
    else if (addinsCoincidentes.length > 0) estado = "detectado_deshabilitado";
    else if (encontradas.length > 0) estado = "detectado_habilitado";
    else if (def.incluido && d.excel.instalado) estado = "incluido_sin_evidencia";
    else estado = "no_detectado";

    return {
      id: def.id,
      nombre: def.nombre,
      categoria: def.categoria,
      licencia: def.licencia,
      enlace: def.enlace,
      queAporta: def.queAporta,
      comoAprovechar: def.comoAprovechar,
      detectable: def.detectable !== false,
      estado,
      evidencias: [...new Set(encontradas)].slice(0, 10),
      nota: def.nota ?? null,
    };
  });

  const conocidosNorm = new Set(conocidos.flatMap((c) => c.evidencias.map(normalizar)));
  const desconocidos = d.addins
    .filter((a) => {
      const campos = [a.nombre, a.friendlyName, a.description, a.manifest].filter(Boolean).map((s) => normalizar(String(s)));
      return !campos.some((c) => conocidosNorm.has(c)) && !DEFINICIONES.some((def) => def.patrones.some((p) => campos.some((c) => c.includes(normalizar(p)))));
    })
    .map((a) => ({
      nombre: a.nombre,
      raiz: a.raiz,
      loadBehavior: a.loadBehavior,
      habilitado: a.loadBehavior === null ? null : a.loadBehavior === 3,
    }));

  const notas: string[] = [];
  if (!d.ok) notas.push(d.error ?? "No se pudo consultar el registro de Windows.");
  if (!d.excel.instalado) notas.push("No encontre Excel instalado; la deteccion de complementos puede estar incompleta.");
  notas.push(
    "Solo se consulto el registro y nombres de archivo. No se abrieron complementos, no se leyo su codigo y no se modifico nada.",
  );
  if (conocidos.some((c) => c.categoria === "B" && c.estado.startsWith("detectado"))) {
    notas.push("Hay complementos de pago instalados. Se pueden usar desde Excel si su licencia esta activa; este MCP no los emula.");
  }

  return {
    ok: d.ok,
    error: d.error,
    excelInstalado: d.excel.instalado,
    excelAbierto: d.excel.procesoActivo,
    totalAddins: d.addins.length,
    addins: d.addins,
    xlstart: d.xlstart,
    conocidos,
    desconocidos,
    notas,
  };
}
