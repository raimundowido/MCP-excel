/**
 * Reporte HTML autocontenido de una hoja.
 *
 * Genera un unico archivo .html sin scripts, sin recursos externos y con una CSP que
 * impide cargar nada de la red. Los valores se escapan antes de insertarlos: el
 * contenido de una celda se trata como dato, nunca como marcado.
 */
import { perfilarColumna, type PerfilColumna } from "./perfil.js";
import type { HojaLeida } from "./libro.js";
import { valorDeFila } from "./libro.js";

export interface OpcionesReporte {
  maxMuestra: number;
  maxValores: number;
  incluirEstadisticas: boolean;
  incluirMuestra: boolean;
}

export interface ResumenReporte {
  archivo: string;
  hoja: string;
  rango: string;
  generado: string;
  filas: number;
  columnas: number;
  filasVacias: number;
  formulasSinResultado: number;
  celdasVacias: number;
  columnasNumericas: number;
  columnasTexto: number;
  columnasConAvisos: number;
}

export interface ResultadoReporte {
  html: string;
  resumen: ResumenReporte;
}

function escapar(valor: unknown): string {
  return String(valor)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function formatear(n: number | null | undefined): string {
  if (n === null || n === undefined || !Number.isFinite(n)) return "—";
  const abs = Math.abs(n);
  if (abs !== 0 && (abs >= 1e9 || abs < 1e-4)) return n.toExponential(3);
  return n.toLocaleString("es-CL", { maximumFractionDigits: 4 });
}

function barra(porcentaje: number): string {
  const ancho = Math.max(0, Math.min(100, porcentaje));
  return `<span class="barra"><span style="width:${ancho.toFixed(1)}%"></span></span>`;
}

function histogramaSvg(valores: number[]): string {
  const ancho = 280;
  const alto = 92;
  const margen = 4;
  const bins = 10;
  let min = Number.POSITIVE_INFINITY;
  let max = Number.NEGATIVE_INFINITY;
  for (const v of valores) {
    if (v < min) min = v;
    if (v > max) max = v;
  }
  const rango = max - min;
  const cuentas = new Array<number>(bins).fill(0);
  for (const v of valores) {
    const i = rango === 0 ? 0 : Math.min(bins - 1, Math.floor(((v - min) / rango) * bins));
    cuentas[i] = (cuentas[i] ?? 0) + 1;
  }
  const maxCuenta = cuentas.reduce((a, b) => Math.max(a, b), 1);
  const anchoBarra = (ancho - margen * 2) / bins;
  const barras = cuentas
    .map((c, i) => {
      const h = Math.max(1, (c / maxCuenta) * (alto - margen * 2));
      const x = margen + i * anchoBarra + 1;
      const y = alto - margen - h;
      return `<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${Math.max(1, anchoBarra - 2).toFixed(1)}" height="${h.toFixed(1)}"><title>${c} valor(es)</title></rect>`;
    })
    .join("");
  return `<svg class="hist" viewBox="0 0 ${ancho} ${alto}" role="img" aria-label="Histograma de ${valores.length} valores entre ${escapar(formatear(min))} y ${escapar(formatear(max))}">${barras}</svg>`;
}

function tarjeta(etiqueta: string, valor: string | number, detalle = ""): string {
  return `<div class="tarjeta"><div class="etiqueta">${escapar(etiqueta)}</div><div class="valor">${escapar(valor)}</div>${
    detalle ? `<div class="detalle">${escapar(detalle)}</div>` : ""
  }</div>`;
}

function perfilDe(hoja: HojaLeida, indice: number, maxValores: number): PerfilColumna {
  return perfilarColumna(hoja, hoja.columnas[indice]!, maxValores);
}

function seccionColumna(hoja: HojaLeida, indice: number, opciones: OpcionesReporte): string {
  const columna = hoja.columnas[indice]!;
  const perfil = perfilDe(hoja, indice, opciones.maxValores);
  const dominante = Object.entries(perfil.tipos)
    .filter(([t]) => t !== "vacio")
    .sort((a, b) => b[1] - a[1])[0];
  const numerico = perfil.numerico.estadisticas;
  const numeros = hoja.filas
    .map((f) => valorDeFila(f, columna))
    .filter((c) => c.tipo === "numero")
    .map((c) => c.valor as number);

  const top = perfil.topValores
    .slice(0, opciones.maxValores)
    .map(
      (v) =>
        `<tr><td class="texto">${escapar(v.valor)}</td><td class="num">${v.frecuencia}</td><td class="num">${v.porcentaje.toFixed(1)} %</td><td>${barra(v.porcentaje)}</td></tr>`,
    )
    .join("");

  const avisos = perfil.avisos
    .slice(0, 6)
    .map((a) => `<li>${escapar(a)}</li>`)
    .join("");

  const bloqueNumerico =
    opciones.incluirEstadisticas && numerico
      ? `<div class="numerico">
          <h4>Estadística numérica</h4>
          <table class="mini">
            <tr><th>n</th><td class="num">${numerico.n}</td><th>Media</th><td class="num">${escapar(formatear(numerico.media))}</td></tr>
            <tr><th>Mediana</th><td class="num">${escapar(formatear(numerico.mediana))}</td><th>Desv. est.</th><td class="num">${escapar(formatear(numerico.desviacionEstandarMuestral))}</td></tr>
            <tr><th>Mínimo</th><td class="num">${escapar(formatear(numerico.minimo))}</td><th>Máximo</th><td class="num">${escapar(formatear(numerico.maximo))}</td></tr>
            <tr><th>Q1</th><td class="num">${escapar(formatear(numerico.q1))}</td><th>Q3</th><td class="num">${escapar(formatear(numerico.q3))}</td></tr>
            <tr><th>IQR</th><td class="num">${escapar(formatear(numerico.iqr))}</td><th>Atípicos</th><td class="num">${numerico.atipicos.length}</td></tr>
          </table>
          ${numeros.length > 1 ? histogramaSvg(numeros) : ""}
        </div>`
      : "";

  return `<section class="columna">
    <h3>${escapar(columna.nombre)} <span class="letra">${escapar(columna.letra)}</span></h3>
    <p class="meta">Tipo dominante: <strong>${escapar(dominante ? `${dominante[0]} (${dominante[1]})` : "vacío")}</strong>
      · ${perfil.noVacios} con datos · ${perfil.vacios} vacíos · ${perfil.unicos} únicos
      ${perfil.numerico.guardadosComoTexto > 0 ? ` · ${perfil.numerico.guardadosComoTexto} número(s) como texto` : ""}
    </p>
    ${
      top
        ? `<table class="top"><thead><tr><th>Valor más frecuente</th><th>Frec.</th><th>%</th><th></th></tr></thead><tbody>${top}</tbody></table>`
        : `<p class="vacio">Sin valores para mostrar.</p>`
    }
    ${bloqueNumerico}
    ${avisos ? `<ul class="avisos">${avisos}</ul>` : ""}
  </section>`;
}

export function generarReporte(hoja: HojaLeida, opciones: OpcionesReporte): ResultadoReporte {
  const maxMuestra = Math.max(0, Math.min(200, opciones.maxMuestra));
  const maxColumnasMuestra = Math.min(hoja.columnas.length, 30);
  const columnasMuestra = hoja.columnas.slice(0, maxColumnasMuestra);

  let celdasVacias = 0;
  let formulasSinResultado = 0;
  for (const fila of hoja.filas) {
    for (const c of fila.celdas) {
      if (c.tipo === "vacio") celdasVacias++;
      if (c.formulaSinResultado) formulasSinResultado++;
    }
  }

  const perfiles = hoja.columnas.map((_, i) => perfilDe(hoja, i, opciones.maxValores));
  const columnasNumericas = perfiles.filter((p) => p.numerico.estadisticas !== null).length;
  const columnasTexto = perfiles.filter((p) => p.tipos.texto > 0 && p.tipos.texto === p.noVacios).length;
  const columnasConAvisos = perfiles.filter((p) => p.avisos.length > 0).length;

  const resumen: ResumenReporte = {
    archivo: hoja.archivo,
    hoja: hoja.hoja,
    rango: hoja.rango,
    generado: new Date().toISOString(),
    filas: hoja.filas.length,
    columnas: hoja.columnas.length,
    filasVacias: hoja.filasVacias,
    formulasSinResultado,
    celdasVacias,
    columnasNumericas,
    columnasTexto,
    columnasConAvisos,
  };

  const muestra =
    opciones.incluirMuestra && maxMuestra > 0
      ? `<section class="muestra">
          <h2>Muestra de datos (${Math.min(maxMuestra, hoja.filas.length)} de ${hoja.filas.length} filas)</h2>
          <div class="scroll">
          <table>
            <thead><tr><th>#</th>${columnasMuestra.map((c) => `<th>${escapar(c.nombre)}</th>`).join("")}</tr></thead>
            <tbody>
              ${hoja.filas
                .slice(0, maxMuestra)
                .map(
                  (fila) =>
                    `<tr><td class="num">${fila.numero}</td>${columnasMuestra
                      .map((c) => {
                        const c2 = valorDeFila(fila, c);
                        const texto = c2.formulaSinResultado ? "(fórmula sin resultado)" : c2.texto;
                        return `<td class="${c2.tipo === "numero" ? "num" : "texto"}">${escapar(texto)}</td>`;
                      })
                      .join("")}</tr>`,
                )
                .join("")}
            </tbody>
          </table>
          </div>
          ${hoja.columnas.length > maxColumnasMuestra ? `<p class="meta">Se muestran las primeras ${maxColumnasMuestra} columnas de ${hoja.columnas.length}.</p>` : ""}
        </section>`
      : "";

  const avisosHoja = hoja.avisos.map((a) => `<li>${escapar(a)}</li>`).join("");
  const secciones = hoja.columnas.map((_, i) => seccionColumna(hoja, i, opciones)).join("");

  const html = `<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src data:">
<title>Reporte · ${escapar(hoja.hoja)} · ${escapar(resumen.archivo)}</title>
<style>
  :root { color-scheme: light; }
  * { box-sizing: border-box; }
  body { margin: 0; padding: 28px; font: 14px/1.5 "Segoe UI", system-ui, -apple-system, sans-serif; color: #1f2933; background: #f5f7fa; }
  h1 { margin: 0 0 4px; font-size: 26px; }
  h2 { margin: 32px 0 12px; font-size: 19px; border-bottom: 2px solid #d7dee8; padding-bottom: 6px; }
  h3 { margin: 0 0 6px; font-size: 16px; }
  h4 { margin: 14px 0 6px; font-size: 13px; text-transform: uppercase; letter-spacing: .04em; color: #52606d; }
  .sub { color: #616e7c; margin: 0 0 20px; }
  .tarjetas { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; }
  .tarjeta { background: #fff; border: 1px solid #d7dee8; border-radius: 10px; padding: 12px 14px; }
  .tarjeta .etiqueta { font-size: 11px; text-transform: uppercase; letter-spacing: .05em; color: #616e7c; }
  .tarjeta .valor { font-size: 22px; font-weight: 650; margin-top: 2px; }
  .tarjeta .detalle { font-size: 12px; color: #616e7c; }
  .columna { background: #fff; border: 1px solid #d7dee8; border-radius: 10px; padding: 16px 18px; margin-bottom: 14px; }
  .letra { font-size: 11px; color: #7b8794; border: 1px solid #d7dee8; border-radius: 4px; padding: 1px 5px; vertical-align: middle; }
  .meta { color: #616e7c; font-size: 12.5px; margin: 0 0 10px; }
  table { border-collapse: collapse; width: 100%; }
  th, td { border-bottom: 1px solid #e4e7eb; padding: 5px 8px; text-align: left; vertical-align: top; }
  th { font-size: 11.5px; text-transform: uppercase; letter-spacing: .04em; color: #52606d; background: #f0f4f8; }
  td.num { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
  td.texto { overflow-wrap: anywhere; }
  table.mini { width: auto; min-width: 340px; }
  table.mini th { background: transparent; text-transform: none; letter-spacing: 0; }
  .barra { display: inline-block; width: 120px; height: 8px; background: #e4e7eb; border-radius: 4px; overflow: hidden; }
  .barra span { display: block; height: 100%; background: #2f6f9f; }
  .hist { width: 100%; max-width: 360px; height: auto; margin-top: 8px; background: #f5f7fa; border-radius: 6px; }
  .hist rect { fill: #2f6f9f; }
  .avisos { margin: 10px 0 0; padding-left: 18px; color: #8a4b08; font-size: 12.5px; }
  .scroll { overflow-x: auto; background: #fff; }
  .muestra table { font-size: 12.5px; }
  .vacio { color: #7b8794; font-style: italic; }
  footer { margin-top: 30px; color: #7b8794; font-size: 12px; }
</style>
</head>
<body>
  <h1>Reporte de ${escapar(hoja.hoja)}</h1>
  <p class="sub">${escapar(resumen.archivo)} · rango ${escapar(resumen.rango)} · generado ${escapar(resumen.generado)}</p>

  <div class="tarjetas">
    ${tarjeta("Filas leídas", resumen.filas)}
    ${tarjeta("Columnas", resumen.columnas)}
    ${tarjeta("Filas vacías", resumen.filasVacias)}
    ${tarjeta("Columnas numéricas", resumen.columnasNumericas)}
    ${tarjeta("Columnas de texto", resumen.columnasTexto)}
    ${tarjeta("Celdas vacías", resumen.celdasVacias)}
    ${tarjeta("Fórmulas sin resultado", resumen.formulasSinResultado, "ExcelJS no calcula fórmulas")}
    ${tarjeta("Columnas con avisos", resumen.columnasConAvisos)}
  </div>

  ${avisosHoja ? `<h2>Avisos del libro</h2><ul class="avisos">${avisosHoja}</ul>` : ""}

  <h2>Calidad por columna</h2>
  ${secciones}

  ${muestra}

  <footer>Generado por MCP Excel a partir del archivo en disco. No se abrió Excel: los valores de fórmulas son los últimos guardados por Excel. Reporte sin scripts ni recursos externos.</footer>
</body>
</html>
`;

  return { html, resumen };
}
