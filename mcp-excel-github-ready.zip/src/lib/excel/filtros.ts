/**
 * Filtros y limpieza de filas.
 *
 * Los filtros trabajan sobre valores normalizados: el texto se compara sin mayusculas ni
 * acentos por defecto, y los numeros aceptan texto convertible ("1.234,50", "$ 1.200", "15%").
 */
import { ErrorExcel } from "./errores.js";
import { resolverColumna, valorDeFila, type ColumnaLeida, type FilaLeida, type HojaLeida } from "./libro.js";
import { aNumero, claveValor, limpiarTexto, normalizarTexto, type CeldaNormalizada } from "./valor.js";

export const OPERADORES = [
  "texto_contiene",
  "texto_no_contiene",
  "texto_igual",
  "texto_distinto",
  "texto_empieza_con",
  "texto_termina_con",
  "texto_en_lista",
  "texto_no_en_lista",
  "vacio",
  "no_vacio",
  "numero_igual",
  "numero_distinto",
  "numero_mayor",
  "numero_mayor_igual",
  "numero_menor",
  "numero_menor_igual",
  "numero_entre",
  "numero_en_lista",
] as const;

export type Operador = (typeof OPERADORES)[number];

export interface Condicion {
  columna: string;
  operador: Operador;
  valor?: string | number;
  valor2?: string | number;
  valores?: (string | number)[];
  ignorar_mayusculas?: boolean;
  ignorar_acentos?: boolean;
}

export interface CondicionResuelta {
  original: Condicion;
  columna: ColumnaLeida;
  descripcion: string;
  evaluar: (celda: CeldaNormalizada) => boolean;
}

function textoComparable(c: CeldaNormalizada, ignorarMayusculas: boolean, ignorarAcentos: boolean): string {
  let t = c.texto;
  t = limpiarTexto(t, {
    minusculas: ignorarMayusculas,
    sinAcentos: ignorarAcentos,
    colapsarEspacios: true,
    quitarSaltos: true,
  });
  return t;
}

function numeroDe(c: CeldaNormalizada): number | null {
  if (c.tipo === "numero") return c.valor as number;
  if (c.tipo === "texto") return aNumero(c.texto);
  return null;
}

function descripcionDe(c: Condicion): string {
  const v = c.valor === undefined ? "" : ` ${JSON.stringify(c.valor)}`;
  const v2 = c.valor2 === undefined ? "" : ` y ${JSON.stringify(c.valor2)}`;
  const lista = c.valores ? ` [${c.valores.map((x) => JSON.stringify(x)).join(", ")}]` : "";
  switch (c.operador) {
    case "texto_contiene": return `"${c.columna}" contiene${v}`;
    case "texto_no_contiene": return `"${c.columna}" no contiene${v}`;
    case "texto_igual": return `"${c.columna}" es igual a${v}`;
    case "texto_distinto": return `"${c.columna}" es distinto de${v}`;
    case "texto_empieza_con": return `"${c.columna}" empieza con${v}`;
    case "texto_termina_con": return `"${c.columna}" termina con${v}`;
    case "texto_en_lista": return `"${c.columna}" esta en${lista}`;
    case "texto_no_en_lista": return `"${c.columna}" no esta en${lista}`;
    case "vacio": return `"${c.columna}" esta vacio`;
    case "no_vacio": return `"${c.columna}" no esta vacio`;
    case "numero_igual": return `"${c.columna}" =${v}`;
    case "numero_distinto": return `"${c.columna}" !=${v}`;
    case "numero_mayor": return `"${c.columna}" >${v}`;
    case "numero_mayor_igual": return `"${c.columna}" >=${v}`;
    case "numero_menor": return `"${c.columna}" <${v}`;
    case "numero_menor_igual": return `"${c.columna}" <=${v}`;
    case "numero_entre": return `"${c.columna}" entre${v}${v2}`;
    case "numero_en_lista": return `"${c.columna}" en${lista}`;
  }
}

function exigirValorTexto(c: Condicion): string {
  if (c.valor === undefined || c.valor === null) {
    throw new ErrorExcel(`La condicion "${c.operador}" sobre "${c.columna}" necesita "valor".`);
  }
  return String(c.valor);
}

function exigirValorNumero(c: Condicion, etiqueta = "valor"): number {
  if (c.valor === undefined || c.valor === null) {
    throw new ErrorExcel(`La condicion "${c.operador}" sobre "${c.columna}" necesita "${etiqueta}".`);
  }
  const n = aNumero(c.valor);
  if (n === null) {
    throw new ErrorExcel(`El ${etiqueta} de la condicion sobre "${c.columna}" debe ser numerico.`);
  }
  return n;
}

function exigirLista(c: Condicion): (string | number)[] {
  if (!c.valores || c.valores.length === 0) {
    throw new ErrorExcel(`La condicion "${c.operador}" sobre "${c.columna}" necesita "valores" con al menos un elemento.`);
  }
  if (c.valores.length > 100) throw new ErrorExcel("La lista de valores admite como maximo 100 elementos.");
  return c.valores;
}

export function resolverCondiciones(hoja: HojaLeida, condiciones: Condicion[]): CondicionResuelta[] {
  if (condiciones.length === 0) return [];
  if (condiciones.length > 8) throw new ErrorExcel("Puedes combinar como maximo 8 condiciones.");
  return condiciones.map((c) => {
    if (!c || typeof c !== "object") throw new ErrorExcel("Cada condicion debe ser un objeto.");
    if (!OPERADORES.includes(c.operador)) {
      throw new ErrorExcel(`Operador no soportado: "${String(c.operador)}". Admitidos: ${OPERADORES.join(", ")}.`);
    }
    const columna = resolverColumna(hoja, String(c.columna ?? ""));
    const ignoraMay = c.ignorar_mayusculas !== false;
    const ignoraAce = c.ignorar_acentos !== false;

    let evaluar: (celda: CeldaNormalizada) => boolean;
    switch (c.operador) {
      case "vacio":
        evaluar = (celda) => celda.tipo === "vacio" || (celda.tipo !== "error" && celda.texto.trim() === "");
        break;
      case "no_vacio":
        evaluar = (celda) => !(celda.tipo === "vacio" || (celda.tipo !== "error" && celda.texto.trim() === ""));
        break;
      case "texto_contiene": {
        const v = textoComparable({ ...celdaVacia(), texto: exigirValorTexto(c) }, ignoraMay, ignoraAce);
        evaluar = (celda) => textoComparable(celda, ignoraMay, ignoraAce).includes(v);
        break;
      }
      case "texto_no_contiene": {
        const v = textoComparable({ ...celdaVacia(), texto: exigirValorTexto(c) }, ignoraMay, ignoraAce);
        evaluar = (celda) => !textoComparable(celda, ignoraMay, ignoraAce).includes(v);
        break;
      }
      case "texto_igual": {
        const v = textoComparable({ ...celdaVacia(), texto: exigirValorTexto(c) }, ignoraMay, ignoraAce);
        evaluar = (celda) => textoComparable(celda, ignoraMay, ignoraAce) === v;
        break;
      }
      case "texto_distinto": {
        const v = textoComparable({ ...celdaVacia(), texto: exigirValorTexto(c) }, ignoraMay, ignoraAce);
        evaluar = (celda) => textoComparable(celda, ignoraMay, ignoraAce) !== v;
        break;
      }
      case "texto_empieza_con": {
        const v = textoComparable({ ...celdaVacia(), texto: exigirValorTexto(c) }, ignoraMay, ignoraAce);
        evaluar = (celda) => textoComparable(celda, ignoraMay, ignoraAce).startsWith(v);
        break;
      }
      case "texto_termina_con": {
        const v = textoComparable({ ...celdaVacia(), texto: exigirValorTexto(c) }, ignoraMay, ignoraAce);
        evaluar = (celda) => textoComparable(celda, ignoraMay, ignoraAce).endsWith(v);
        break;
      }
      case "texto_en_lista": {
        const set = new Set(exigirLista(c).map((x) => textoComparable({ ...celdaVacia(), texto: String(x) }, ignoraMay, ignoraAce)));
        evaluar = (celda) => set.has(textoComparable(celda, ignoraMay, ignoraAce));
        break;
      }
      case "texto_no_en_lista": {
        const set = new Set(exigirLista(c).map((x) => textoComparable({ ...celdaVacia(), texto: String(x) }, ignoraMay, ignoraAce)));
        evaluar = (celda) => !set.has(textoComparable(celda, ignoraMay, ignoraAce));
        break;
      }
      case "numero_igual": {
        const v = exigirValorNumero(c);
        evaluar = (celda) => {
          const n = numeroDe(celda);
          return n !== null && Math.abs(n - v) <= 1e-9 * Math.max(1, Math.abs(v));
        };
        break;
      }
      case "numero_distinto": {
        const v = exigirValorNumero(c);
        evaluar = (celda) => {
          const n = numeroDe(celda);
          return n !== null && Math.abs(n - v) > 1e-9 * Math.max(1, Math.abs(v));
        };
        break;
      }
      case "numero_mayor": {
        const v = exigirValorNumero(c);
        evaluar = (celda) => (numeroDe(celda) ?? Number.NEGATIVE_INFINITY) > v;
        break;
      }
      case "numero_mayor_igual": {
        const v = exigirValorNumero(c);
        evaluar = (celda) => (numeroDe(celda) ?? Number.NEGATIVE_INFINITY) >= v;
        break;
      }
      case "numero_menor": {
        const v = exigirValorNumero(c);
        evaluar = (celda) => (numeroDe(celda) ?? Number.POSITIVE_INFINITY) < v;
        break;
      }
      case "numero_menor_igual": {
        const v = exigirValorNumero(c);
        evaluar = (celda) => (numeroDe(celda) ?? Number.POSITIVE_INFINITY) <= v;
        break;
      }
      case "numero_entre": {
        const a = exigirValorNumero(c, "valor");
        if (c.valor2 === undefined || c.valor2 === null) {
          throw new ErrorExcel(`La condicion "numero_entre" sobre "${c.columna}" necesita "valor2".`);
        }
        const b = exigirValorNumero({ ...c, valor: c.valor2 }, "valor2");
        if (a > b) throw new ErrorExcel(`En "numero_entre" el valor inicial (${a}) no puede ser mayor que valor2 (${b}).`);
        evaluar = (celda) => {
          const n = numeroDe(celda);
          return n !== null && n >= a && n <= b;
        };
        break;
      }
      case "numero_en_lista": {
        const set = exigirLista(c).map((x) => {
          const n = aNumero(x);
          if (n === null) throw new ErrorExcel(`El valor ${JSON.stringify(x)} de "numero_en_lista" no es numerico.`);
          return n;
        });
        evaluar = (celda) => {
          const n = numeroDe(celda);
          return n !== null && set.some((v) => Math.abs(n - v) <= 1e-9 * Math.max(1, Math.abs(v)));
        };
        break;
      }
    }
    return { original: c, columna, descripcion: descripcionDe(c), evaluar };
  });
}

function celdaVacia(): CeldaNormalizada {
  return { tipo: "vacio", valor: null, texto: "", formula: null, formulaSinResultado: false, formato: null };
}

export function evaluarFila(fila: FilaLeida, condiciones: CondicionResuelta[], modo: "todas" | "alguna"): boolean {
  if (condiciones.length === 0) return true;
  const resultados = condiciones.map((c) => c.evaluar(valorDeFila(fila, c.columna)));
  return modo === "todas" ? resultados.every(Boolean) : resultados.some(Boolean);
}

export interface ResultadoFiltro {
  totalFilas: number;
  coincidentes: FilaLeida[];
  noCoincidentes: number;
  ejemplosExcluidos: FilaLeida[];
  vaciasCoincidentes: number;
}

export function filtrarFilas(
  hoja: HojaLeida,
  condiciones: CondicionResuelta[],
  modo: "todas" | "alguna",
  maxCoincidentes: number,
  maxEjemplosExcluidos = 5,
): ResultadoFiltro {
  const coincidentes: FilaLeida[] = [];
  let noCoincidentes = 0;
  let vaciasCoincidentes = 0;
  const ejemplosExcluidos: FilaLeida[] = [];
  for (const fila of hoja.filas) {
    if (evaluarFila(fila, condiciones, modo)) {
      if (coincidentes.length < maxCoincidentes) coincidentes.push(fila);
      if (fila.celdas.every((c) => c.tipo === "vacio")) vaciasCoincidentes++;
    } else {
      noCoincidentes++;
      if (ejemplosExcluidos.length < maxEjemplosExcluidos) ejemplosExcluidos.push(fila);
    }
  }
  return { totalFilas: hoja.filas.length, coincidentes, noCoincidentes, ejemplosExcluidos, vaciasCoincidentes };
}

export interface OpcionesLimpieza {
  condiciones: CondicionResuelta[];
  modo: "todas" | "alguna";
  conservarCoincidentes: boolean;
  descartarVacias: boolean;
  descartarSiVacioEn: ColumnaLeida[];
  recortarEspacios: boolean;
  colapsarEspacios: boolean;
  quitarDuplicados: boolean;
  columnasClave: ColumnaLeida[];
}

export interface ReporteLimpieza {
  filasEntrada: number;
  filasSalida: number;
  eliminadasPorFiltro: number;
  eliminadasVacias: number;
  eliminadasPorVacios: number;
  eliminadasDuplicadas: number;
  celdasRecortadas: number;
  celdasEspaciosColapsados: number;
  totalEliminadas: number;
}

export interface ResultadoLimpieza {
  filas: FilaLeida[];
  reporte: ReporteLimpieza;
  avisos: string[];
}

function filaVacia(f: FilaLeida): boolean {
  return f.celdas.every((c) => c.tipo === "vacio" || c.texto.trim() === "");
}

function clonarCelda(c: CeldaNormalizada): CeldaNormalizada {
  return { ...c };
}

export function limpiarFilas(hoja: HojaLeida, opciones: OpcionesLimpieza): ResultadoLimpieza {
  const avisos: string[] = [];
  const filasEntrada = hoja.filas.length;
  let filas = hoja.filas.map((f) => ({ numero: f.numero, celdas: f.celdas.map(clonarCelda) }));
  let eliminadasPorFiltro = 0;
  let eliminadasVacias = 0;
  let eliminadasPorVacios = 0;
  let eliminadasDuplicadas = 0;
  let celdasRecortadas = 0;
  let celdasEspaciosColapsados = 0;

  if (opciones.condiciones.length > 0) {
    const antes = filas.length;
    filas = filas.filter((f) => {
      const coincide = evaluarFila(f, opciones.condiciones, opciones.modo);
      return opciones.conservarCoincidentes ? coincide : !coincide;
    });
    eliminadasPorFiltro = antes - filas.length;
  }

  if (opciones.descartarVacias) {
    const antes = filas.length;
    filas = filas.filter((f) => !filaVacia(f));
    eliminadasVacias = antes - filas.length;
  }

  if (opciones.descartarSiVacioEn.length > 0) {
    const antes = filas.length;
    filas = filas.filter((f) =>
      opciones.descartarSiVacioEn.every((c) => {
        const celda = f.celdas[c.indice - 1];
        return celda && celda.tipo !== "vacio" && celda.texto.trim() !== "";
      }),
    );
    eliminadasPorVacios = antes - filas.length;
  }

  if (opciones.recortarEspacios || opciones.colapsarEspacios) {
    for (const f of filas) {
      for (let i = 0; i < f.celdas.length; i++) {
        const c = f.celdas[i]!;
        if (c.tipo !== "texto" || c.formulaSinResultado) continue;
        const antes = c.texto;
        let despues = antes.replace(/\u00a0/g, " ").replace(/[\u200b-\u200d\ufeff]/g, "");
        if (opciones.colapsarEspacios) despues = despues.replace(/\s+/g, " ");
        if (opciones.recortarEspacios) despues = despues.trim();
        if (despues !== antes) {
          if (despues.trim() !== antes.trim()) celdasRecortadas++;
          else celdasEspaciosColapsados++;
          f.celdas[i] = {
            ...c,
            valor: despues,
            texto: despues,
            formula: null,
            formulaSinResultado: false,
          };
        }
      }
    }
  }

  if (opciones.quitarDuplicados) {
    const claves = opciones.columnasClave;
    const vistos = new Set<string>();
    const antes = filas.length;
    filas = filas.filter((f) => {
      const partes = claves.length > 0
        ? claves.map((c) => claveValor(f.celdas[c.indice - 1] ?? celdaVacia()))
        : f.celdas.map((c) => claveValor(c));
      const clave = partes.join("\u0001");
      if (vistos.has(clave)) return false;
      vistos.add(clave);
      return true;
    });
    eliminadasDuplicadas = antes - filas.length;
    if (claves.length > 0) avisos.push(`Duplicados evaluados solo con: ${claves.map((c) => c.nombre).join(", ")}.`);
  }

  const totalEliminadas = filasEntrada - filas.length;
  if (totalEliminadas === 0) avisos.push("Ninguna fila fue eliminada con los criterios actuales.");

  return {
    filas,
    reporte: {
      filasEntrada,
      filasSalida: filas.length,
      eliminadasPorFiltro,
      eliminadasVacias,
      eliminadasPorVacios,
      eliminadasDuplicadas,
      celdasRecortadas,
      celdasEspaciosColapsados,
      totalEliminadas,
    },
    avisos,
  };
}

/** Convierte filas a una matriz de valores simples para exportar. */
export function matrizSalida(hoja: HojaLeida, filas: FilaLeida[]): (string | number | boolean | null)[][] {
  return filas.map((f) =>
    f.celdas.map((c) => {
      if (c.tipo === "vacio" || c.formulaSinResultado) return null;
      if (c.tipo === "error") return c.texto;
      return c.valor as string | number | boolean;
    }),
  );
}

/** Descripcion legible de una fila (para la vista previa). */
export function filaComoObjeto(hoja: HojaLeida, fila: FilaLeida): Record<string, string | number | boolean | null> {
  const o: Record<string, string | number | boolean | null> = { _fila: fila.numero };
  for (const c of hoja.columnas) {
    const celda = fila.celdas[c.indice - 1];
    o[c.nombre] = celda && celda.tipo !== "vacio" && !celda.formulaSinResultado ? (celda.valor as string | number | boolean) : null;
  }
  return o;
}

/** Normaliza el texto de una lista de valores para mostrarla en mensajes. */
export function unirNombres(columnas: ColumnaLeida[]): string {
  return columnas.map((c) => c.nombre).join(", ");
}

/** Exportado para pruebas unitarias. */
export { numeroDe as numeroDeCelda, textoComparable as textoComparableParaFiltro };
