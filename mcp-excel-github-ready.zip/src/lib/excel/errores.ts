/**
 * Errores controlados del motor de Excel.
 *
 * La idea es que las herramientas nunca lancen una excepcion "cruda" al modelo:
 * capturan ErrorExcel y devuelven un mensaje que explique QUE paso y COMO corregirlo.
 */
export class ErrorExcel extends Error {
  constructor(
    mensaje: string,
    readonly sugerencia?: string,
  ) {
    super(mensaje);
    this.name = "ErrorExcel";
  }
}

/** Convierte cualquier fallo en un mensaje corto y accionable (sin pilas ni rutas internas). */
export function mensajeError(e: unknown): string {
  if (e instanceof ErrorExcel) {
    return e.sugerencia ? `${e.message}\n\nSugerencia: ${e.sugerencia}` : e.message;
  }
  if (e instanceof Error) {
    const codigo = (e as NodeJS.ErrnoException).code;
    if (codigo === "ENOENT") return "No existe el archivo o la carpeta indicada. Revisa la ruta.";
    if (codigo === "EACCES" || codigo === "EPERM") {
      return "Windows no permite leer o escribir ese archivo. Cierra Excel si lo tiene abierto, revisa los permisos o elige otra carpeta.";
    }
    if (codigo === "EBUSY") return "El archivo esta en uso (probablemente abierto en Excel). Guarda y cierra el libro, o usa una copia.";
    if (/corrupt|zip|end of central directory|invalid signature/i.test(e.message)) {
      return "El archivo no parece un .xlsx/.xlsm valido o esta protegido. Si es un .xls antiguo, guardalo como .xlsx desde Excel.";
    }
    return `No se pudo completar la operacion: ${e.message}`;
  }
  return `No se pudo completar la operacion: ${String(e)}`;
}
