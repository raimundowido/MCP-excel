# CHANGELOG

Cambios del servidor MCP `excel`. Las fechas usan el formato `AAAA-MM-DD`.

## [2.5.0] — 2026-11-13

Mejora incremental. No se elimino ninguna herramienta ni se cambio el comportamiento de las existentes.

### Anadido
- **`excel_ordenar_filas`**: ordena una tabla por una o varias columnas (asc/desc) y exporta a un archivo nuevo, con simulacion por defecto.
- **`excel_agrupar_tabla`**: agrupa por una o varias columnas y calcula conteo, suma, promedio, minimo, maximo y valores distintos; exporta a un archivo nuevo.
- **`excel_buscar_reemplazar`**: reemplazo literal y seguro en celdas de texto, con opciones de mayusculas/acentos y coincidencia exacta, con simulacion por defecto.

### Corregido
- `excel_visual_recalcular_guardar` valida `confirmar=true` tambien en el manejador.
- La deteccion automatica de la fila de encabezado acepta un encabezado aunque las filas inmediatas siguientes esten vacias o solo con espacios.

### Pruebas
- `scripts/test-excel.mjs` cubre las tres nuevas herramientas (simulacion y escritura) y `npm test` pasa.

## [2.4.0] — 2026-11-13

Iteración de mejora sobre la base `2.3.0-rea.1`. No se eliminó ninguna herramienta ni se cambió el comportamiento de las existentes.

### Añadido — prioridad alta

- **`excel_inspeccionar_libro`**: inspección estructural del contenedor OOXML con JSZip. Describe hojas y visibilidad, tablas, nombres definidos, conexiones externas (sin cadenas ni credenciales), Power Query (sin código M), caché de tablas dinámicas, enlaces a otros libros, macros, protección, propiedades y objetos incrustados. Solo lectura.
- **`excel_comparar_archivos`**: comparación de dos versiones de una tabla por una o varias claves, o por posición. Devuelve filas nuevas, eliminadas y cambiadas con valores antes/después, columnas comunes y exclusivas, tolerancia numérica y avisos por claves duplicadas o vacías. Solo lectura.
- **`excel_generar_reporte`**: reporte `.html` autocontenido con resumen, calidad por columna, valores frecuentes, estadística numérica, histogramas SVG y muestra de filas. Sin scripts, sin recursos externos y con CSP que bloquea la red. Escribe un archivo nuevo; para sobrescribir exige `sobrescribir=true` y `confirmar=true`.

### Añadido — prioridad media

- **Tres herramientas visuales de alto nivel** en `src/tools/excel-visual.ts` (se restauró la fuente, que solo existía compilada):
  - `excel_visual_abrir_archivo` (Ctrl+O + ruta + captura de verificación).
  - `excel_visual_recalcular_guardar` (F9 + Ctrl+S, con `confirmar=true`).
  - `excel_visual_ir_a_celda` (Ctrl+G a una referencia A1).
  - Usan las primitivas de `src/lib/visual/nucleo.ts` sin debilitar el freno `PARAR.txt`, el límite de acciones, la validación de coordenadas ni las combinaciones bloqueadas.
- Dependencia explícita `jszip@^3.10.1` (ya venía de forma transitiva con ExcelJS).
- Validador de salida `.html` en `src/lib/excel/rutas.ts`, separado de `validarArchivoSalida` para no alterar la escritura `.xlsx`/`.csv`.

### Corregido / endurecido

- La comparación trata como «sin clave» las celdas de clave que solo contienen espacios, en lugar de emparejarlas entre sí.
- `src/index.ts` informa la versión `2.4.0` del servidor (antes `1.0.0`, desalineada con el paquete).
- Los reportes HTML escapan todo valor de celda y no incluyen scripts; las cadenas de conexión y el código M/VBA nunca se devuelven.

### Documentación

- `README.md`: tabla de herramientas actualizada, ejemplos de comparación/inspección/reporte, decisiones de ruta, capacidades propias y limitaciones.
- `RESEARCH.md`: plan de herramientas actualizado con lo implementado y lo que queda para otra iteración.
- `PLUGINS.md`: categoría C actualizada (C6, C9 y C10 implementadas) y atribución de JSZip.
- `CHANGELOG.md`: este archivo.

### Pruebas

- `scripts/test-excel.mjs` genera ahora un segundo libro con cambios, un libro con una tabla real y un reporte HTML. Comprueba las 14 herramientas de Excel, la inspección estructural, la comparación por clave, la protección contra sobrescritura del reporte y las tres herramientas visuales con `VISUAL_BACKEND=simulado`.
- `npm run build` y `npm test` pasan en esta sesión.

### No verificado

- La ejecución de las herramientas visuales contra una ventana real de Excel. Solo se probaron con el backend `simulado`, sin pantalla.
- Libros reales con Power Query, Power Pivot, conexiones OLEDB/ODBC, macros firmadas o protección compleja. La inspección está probada con libros generados por ExcelJS; su comportamiento con libros de producción puede variar según cómo los guarde cada versión de Excel.
- El formato exacto de algunos atributos OOXML varía entre versiones de Excel; la inspección es tolerante (devuelve `null` o listas vacías) pero no sustituye a abrir el libro en Excel.
