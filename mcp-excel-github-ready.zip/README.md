# MCP Excel

Servidor **MCP** (Model Context Protocol) en TypeScript para trabajar con **Microsoft Excel** en Windows: leer libros, calcular estadística descriptiva de una columna numérica, perfilar su calidad, filtrar/limpiar filas, comparar dos versiones de una tabla, inspeccionar la estructura del libro y generar un reporte HTML, exportando resultados a archivos nuevos.

La vía principal es **leer y escribir archivos** (`.xlsx`, `.xlsm`, `.csv`) con ExcelJS. No abre Excel, no ejecuta macros y no toca el registro salvo para **leer** información de diagnóstico. Para lo que un archivo no puede hacer (recalcular fórmulas, mostrar el libro), hay tres herramientas visuales acotadas.

## Herramientas

| Herramienta | Qué hace | ¿Modifica datos? |
|---|---|---|
| `excel_estado` | Diagnóstico: Excel instalado, versión, si hay una instancia abierta, formatos admitidos, permisos y carpetas | No |
| `excel_listar_hojas` | Lista hojas, rango usado, filas/columnas y tablas con nombre | No |
| `excel_leer_tabla` | Lee una hoja o tabla y devuelve encabezados, tipos, muestra de filas y fórmulas detectadas | No |
| `excel_estadisticas_columna` | n, suma, media, mediana, moda, mínimo, máximo, rango, varianza, desviación, cuartiles, IQR, atípicos, asimetría, curtosis e IC 95 % | No |
| `excel_perfilar_columna` | Tipos, vacíos, únicos, top valores, números como texto, espacios, mayúsculas, correos/URLs/teléfonos y casi duplicados | No |
| `excel_filtrar_filas` | Previsualiza filas que cumplen condiciones de texto o número (AND/OR), con ejemplos excluidos | No |
| `excel_limpiar_datos` | Filtra, quita duplicados, descarta vacíos y normaliza espacios; por defecto **simula**; escribe un archivo nuevo solo con `simular=false` + `confirmar=true` | **Sí** (con confirmación) |
| `excel_plugins_estado` | Detecta complementos instalados leyendo solo el registro y nombres de `XLSTART` | No |
| `excel_inspeccionar_libro` | Estructura profunda del OOXML: tablas, nombres definidos, conexiones, Power Query, tablas dinámicas, enlaces externos, macros, protección, propiedades y objetos | No |
| `excel_comparar_archivos` | Compara dos versiones de una tabla por clave o posición: filas nuevas, eliminadas, cambiadas y columnas exclusivas | No |
| `excel_ordenar_filas` | Ordena las filas por una o varias columnas y exporta a un archivo nuevo (simulación por defecto) | **Sí** (archivo nuevo) |
| `excel_agrupar_tabla` | Agrupa filas por una o varias columnas y calcula agregaciones (conteo, suma, promedio, mínimo, máximo, distintos) | **Sí** (archivo nuevo) |
| `excel_buscar_reemplazar` | Busca y reemplaza texto en las celdas y exporta a un archivo nuevo (simulación por defecto) | **Sí** (archivo nuevo) |
| `excel_generar_reporte` | Escribe un reporte `.html` autocontenido con calidad por columna, estadística, histogramas SVG y muestra | **Sí** (archivo nuevo) |
| `excel_visual_abrir_archivo` | Abre un libro en Excel con Ctrl+O y la ruta escrita; devuelve captura | Estado de la app |
| `excel_visual_recalcular_guardar` | Envía F9 y Ctrl+S para que Excel recalcule y guarde; exige `confirmar=true` | **Sí** (con confirmación) |
| `excel_visual_ir_a_celda` | Selecciona una celda o rango con Ctrl+G | No |

El proyecto también incluye las herramientas visuales genéricas (`visual_capturar`, `visual_clic`, `visual_arrastrar`, `visual_escribir`, `visual_tecla`, `visual_scroll`, `visual_esperar`, `visual_comparar`, `visual_estado`), heredadas de la plantilla.

## Ejemplos de frases para pedirlas

1. **Leer y analizar**
   > «Abre `C:\datos\ventas_2026.xlsx`, dime qué hojas y tablas tiene y calcula la media, la mediana y los valores atípicos de la columna Monto.»

2. **Detectar problemas antes de limpiar**
   > «Perfila la columna Ciudad de `clientes.xlsx`: quiero saber si hay espacios de más, mayúsculas mezcladas o valores casi duplicados antes de unificarla.»

3. **Filtrar y exportar**
   > «De `ventas.xlsx` quita las filas duplicadas y las que no tengan correo, conserva solo las ventas mayores o iguales a 50.000, y guárdalo como `ventas_limpias.xlsx`. Primero muéstrame una simulación.»

4. **Antes de automatizar un libro**
   > «Inspecciona `informe_mensual.xlsm`: quiero saber si tiene macros, conexiones externas, Power Query, tablas dinámicas, enlaces a otros libros o protección, antes de tocarlo.»

5. **Comparar dos versiones**
   > «Compara `ventas_v1.xlsx` con `ventas_v2.xlsx` usando la columna ID y dime qué filas se agregaron, cuáles se eliminaron y qué celdas cambiaron. Ignora diferencias de espacios.»

6. **Reporte para revisar con calma**
   > «Genera un reporte HTML de la hoja Ventas de `ventas.xlsx`, con la calidad de cada columna y un histograma de Monto. Déjalo en la misma carpeta.»

## Requisitos

- **Node.js 20 o superior** (probado con v24.22.1).
- **Windows** para la detección de Excel y complementos y para el control visual nativo. La lectura/escritura de archivos funciona en cualquier sistema.
- **Microsoft Excel** instalado solo si quieres usar el recalculo visual o abrir el libro en pantalla. No es necesario para las herramientas de archivo.
- Permisos de lectura sobre los archivos de entrada y de escritura sobre la carpeta de salida.
- Para el control visual real: permiso de accesibilidad/automatización del sistema (en Windows, que la sesión no esté bloqueada y que Excel esté abierto y visible).

## Instalación y configuración

```powershell
npm install
npm run build
npm test
```

En `opencode.json` el servidor queda registrado así:

```json
{
  "mcp": {
    "excel": {
      "type": "local",
      "command": ["node", "dist/index.js"]
    }
  }
}
```

Variables de entorno opcionales:

| Variable | Efecto | Valor por defecto |
|---|---|---|
| `EXCEL_DIRS` | Lista de carpetas permitidas, separadas por `;`. Si se define, cualquier ruta fuera de ellas se rechaza | sin restricción |
| `EXCEL_MAX_MB` | Tamaño máximo del archivo de entrada | 100 |
| `EXCEL_MAX_CELDAS` | Máximo de celdas por lectura | 5 000 000 |
| `VISUAL_BACKEND` | `simulado` para pruebas sin pantalla | backend real del sistema |
| `VISUAL_APP` | Nombre de la ventana a controlar | `Excel` |
| `VISUAL_MAX_ACCIONES` | Límite de acciones visuales por sesión | 400 |

## Decisiones de ruta (API / archivos / interfaz)

| Capacidad | Vía | Por qué |
|---|---|---|
| Leer hojas, tablas y valores | Archivos (ExcelJS) | Determinista, sin abrir Excel |
| Estadística, perfil y filtros | TypeScript propio | Resultados estables, sin fórmulas ni idioma |
| Limpiar y exportar | Archivos (ExcelJS) | Archivo nuevo, simulación previa |
| Detectar Excel y complementos | PowerShell de solo lectura | No abre Excel ni lee código ajeno |
| Inspeccionar la estructura del libro | OOXML + JSZip | ExcelJS no expone conexiones, Power Query, macros ni protección |
| Comparar dos versiones | ExcelJS + diferencia propia | No requiere Excel abierto ni complementos |
| Reporte HTML de calidad | HTML propio sin scripts | Revisable en cualquier navegador, sin instalar nada |
| Recalcular fórmulas | Visual (F9 + Ctrl+S) | ExcelJS no calcula fórmulas |
| Abrir un libro o ir a una celda | Visual (Ctrl+O / Ctrl+G) | Solo la interfaz puede mostrarlo |
| Gráficos, tablas dinámicas, macros | No implementado | Fuera del alcance o riesgo de seguridad |

El detalle completo está en `RESEARCH.md` (sección 7) e `INVESTIGACION.md`.

## Complementos recomendados

El MCP **no instala, piratea ni emula** complementos. `excel_plugins_estado` detecta de forma no invasiva lo que ya está instalado (registro de Windows y nombres de `XLSTART`) y clasifica cada complemento en las categorías A/B/C/D de `PLUGINS.md`.

- **Incluidos con Excel (categoría A)**: Analysis ToolPak, Solver, Power Query, Power Pivot, Inquire, Office Scripts. La estadística descriptiva del Analysis ToolPak ya está cubierta por `excel_estadisticas_columna`; si tienes Power Query o Power Pivot, el MCP respeta los resultados que dejen en la hoja.
- **De pago (categoría B, opcionales)**: Kutools for Excel, Ablebits Ultimate Suite, XLTools, @RISK, ModelRisk. Solo tienen sentido si ya los usas; para este flujo no es necesario comprar nada.
- **No procede (categoría D)**: ejecutar macros del libro, escribir VBA, descompilar o parchear complementos, saltarse licencias.

En este equipo la detección encontró Data Streamer y Power Pivot (este último desactivado en Excel).

## Capacidades propias

Implementadas desde cero, sin copiar código ni interfaz de terceros:

1. **Estadística descriptiva** con varianza y desviación **muestral**, cuartiles por el método 7 (el de Excel), atípicos por 1,5 × IQR, asimetría y curtosis ajustadas e intervalo de confianza al 95 % con t de Student.
2. **Perfilado de calidad** de una columna: tipos, vacíos, únicos, frecuencia, números guardados como texto, espacios extremos/dobles, caracteres invisibles, mayúsculas mezcladas, correos/URLs/teléfonos y grupos casi duplicados.
3. **Filtrado y limpieza** con condiciones combinables, duplicados por clave, descarte de filas vacías o sin un campo obligatorio, recorte/colapso de espacios y exportación a `.xlsx`/`.csv`, con simulación por defecto.
4. **Recalculo asistido** con F9 + Ctrl+S cuando hace falta que Excel evalúe fórmulas.
5. **Inspección estructural OOXML** con JSZip: hojas y visibilidad, tablas, nombres definidos, conexiones (sin cadenas ni credenciales), Power Query (sin código M), caché de tablas dinámicas, enlaces externos, macros, protección, propiedades y objetos incrustados.
6. **Comparación de versiones** por una o varias claves (o por posición): filas nuevas, eliminadas y cambiadas con valores antes/después, columnas comunes y exclusivas, tolerancia numérica y avisos de claves duplicadas.
7. **Reporte HTML autocontenido**: resumen, calidad por columna, valores frecuentes con barras, estadística numérica, histograma SVG y muestra de filas, con CSP sin red y sin scripts.
8. **Ordenación de filas**: por una o varias columnas, ascendente o descendente, con exportación a archivo nuevo y simulación previa.
9. **Agrupación y agregación**: resúmenes por grupo (conteo, suma, promedio, mínimo, máximo y valores distintos) para análisis rápidos sin tablas dinámicas.
10. **Buscar y reemplazar**: reemplazo literal y seguro en celdas de texto, con detección de mayúsculas/acentos y simulación previa.

Propuestas para otra iteración (detalle en `PLUGINS.md`): agrupar categorías casi duplicadas, escribir un rango conservando formato, exportar a PDF y evaluar fórmulas sin Excel.

## Bucle para recrear una vista a partir de una imagen de referencia

Para tareas como «deja esta hoja igual que la captura»:

1. Prepara o abre el libro (`excel_visual_abrir_archivo` o la vía de archivos).
2. `visual_capturar` para obtener el estado actual.
3. Coloca el PNG de referencia en `referencias/` y ejecuta `visual_comparar`.
4. Revisa `similitud`, `porcentajeCambiado` y las zonas más distintas. Corrige **una** cosa por iteración (ancho de columna, formato, valor, selección).
5. Repite captura → comparación. Para con similitud ≥ 0,98 o tras **8 intentos** como máximo.
6. Revisa siempre la captura final: la comparación mide píxeles, no si el contenido tiene sentido.

## Pruebas

```powershell
npm run build
npm test
```

`npm test` hace tres cosas:

1. Compila TypeScript.
2. Ejecuta la prueba de humo genérica (handshake, listado y descripciones).
3. Ejecuta `scripts/test-excel.mjs`, que genera libros `.xlsx`, una tabla real y un CSV temporales y prueba lectura, estadísticas, perfil, filtros, limpieza simulada y escrita, inspección estructural, comparación de versiones, reporte HTML, errores de ruta y las tres herramientas visuales con `VISUAL_BACKEND=simulado`.

## Limitaciones conocidas

- **Las fórmulas se leen como valor cacheado.** Si el libro nunca se recalculó, la celda queda vacía y se avisa. `excel_visual_recalcular_guardar` lo resuelve abriendo Excel.
- **No se ven los cambios sin guardar** de un Excel abierto: se lee el archivo en disco.
- **La escritura no conserva macros, estilos ni fórmulas**: exporta valores a un archivo nuevo.
- **No se leen `.xls` antiguos ni libros cifrados**: hay que guardar como `.xlsx` sin contraseña.
- **No se crean tablas dinámicas, gráficos, segmentaciones ni formato avanzado.**
- **No se ejecutan macros, VBA ni Office Scripts.**
- **La inspección estructural describe lo que hay en el contenedor, no lo interpreta**: no ejecuta Power Query, no actualiza conexiones y no lee código M/VBA ni cadenas de conexión (pueden contener credenciales).
- **La comparación es de valores, no de formato ni de fórmulas**: dos celdas con la misma fórmula y distinto resultado se ven como cambio; los estilos no se comparan. Sin clave, las filas se alinean por posición.
- **El reporte HTML usa los valores cacheados**: no recalcula fórmulas y no incluye gráficos nativos de Excel.
- **La limpieza no interpreta reglas de negocio**: aplica exactamente las condiciones que recibe; por eso simula por defecto.
- **El control visual depende del foco y del idioma de Excel.** Las secuencias se probaron con el backend simulado; la ejecución real con Excel abierto no se verificó en esta sesión.
- **La detección de complementos solo mira el registro y `XLSTART`**; un complemento puede estar instalado y no aparecer si se carga por otra vía.

## Documentación del proyecto

- `RESEARCH.md` — referentes, capacidades de frontera, plan priorizado e interfaces descubiertas.
- `INVESTIGACION.md` — vías evaluadas, entorno real, formato, seguridad y limitaciones.
- `PLUGINS.md` — categorías A/B/C/D, complementos detectados y capacidades propias.
- `CHANGELOG.md` — cambios de esta iteración, priorizados y con fecha.
- `VISUAL.md` — uso del control visual y pruebas sin pantalla.
