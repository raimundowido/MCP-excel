/**
 * Herramientas de analisis e inspeccion del libro.
 *
 * Tres capacidades propias, implementadas desde cero sobre el formato OOXML y ExcelJS:
 *  - excel_inspeccionar_libro: estructura profunda que ExcelJS no expone.
 *  - excel_comparar_archivos: diferencias entre dos versiones de una tabla.
 *  - excel_generar_reporte: reporte HTML autocontenido de calidad y estadisticas.
 *
 * Ninguna ejecuta macros, sigue enlaces externos ni interpreta el contenido del libro
 * como instrucciones. La unica que escribe es el reporte, y solo en un archivo .html nuevo.
 */
import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { stat, writeFile } from "node:fs/promises";
import path from "node:path";
import { z } from "zod";
import { error, json } from "../lib/respuestas.js";
import { compararHojas } from "../lib/excel/comparar.js";
import { ErrorExcel, mensajeError } from "../lib/excel/errores.js";
import { inspeccionarLibro } from "../lib/excel/estructura.js";
import { leerHoja } from "../lib/excel/libro.js";
import { generarReporte } from "../lib/excel/reporte.js";
import { mismaRuta, validarArchivoEntrada, validarArchivoSalidaHtml } from "../lib/excel/rutas.js";

const ARCHIVO = z
  .string()
  .min(1)
  .max(4096)
  .describe("Ruta local del archivo .xlsx, .xlsm o .csv. Ejemplo: C:\\datos\\ventas.xlsx");

const HOJA = z
  .string()
  .max(200)
  .optional()
  .describe("Nombre de la hoja o su numero (1 = primera). Si se omite, se usa la primera hoja visible.");

const RANGO = z
  .string()
  .min(1)
  .max(40)
  .optional()
  .describe("Rango A1 opcional, por ejemplo A1:F200. Si se omite y hay una tabla, se usa la tabla.");

const FILA_ENCABEZADO = z
  .number()
  .int()
  .min(1)
  .max(1_048_576)
  .optional()
  .describe("Fila que contiene los nombres de columna. Si se omite, se detecta automaticamente.");

async function conManejo(fn: () => Promise<unknown>) {
  try {
    return json(await fn());
  } catch (e) {
    return error(mensajeError(e));
  }
}

export function register(server: McpServer): void {
  server.registerTool(
    "excel_inspeccionar_libro",
    {
      title: "Inspeccionar la estructura de un libro",
      description:
        "Lee el contenedor OOXML de un .xlsx/.xlsm y describe lo que ExcelJS no muestra: nombres definidos, tablas, conexiones externas, Power Query (sin el codigo M), cache de tablas dinamicas, enlaces a otros libros, macros, proteccion, propiedades e imagenes/graficos. Es de solo lectura: no abre Excel, no ejecuta macros, no actualiza conexiones y no devuelve cadenas de conexion ni credenciales. Usala antes de automatizar un libro para saber que contiene.",
      inputSchema: {
        archivo: ARCHIVO,
        incluir_objetos: z
          .boolean()
          .default(true)
          .describe("Lista imagenes, graficos, comentarios y controles incrustados (solo nombres y tamanos)."),
        max_elementos: z
          .number()
          .int()
          .min(1)
          .max(500)
          .default(100)
          .describe("Tope de elementos por lista (hojas, tablas, nombres, conexiones...)."),
      },
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
    },
    async (args) =>
      conManejo(async () => {
        const a = await validarArchivoEntrada(args.archivo);
        const r = await inspeccionarLibro(a, {
          incluirObjetos: args.incluir_objetos,
          maxElementos: args.max_elementos,
        });
        return {
          ...r,
          nota:
            "Inspeccion estructural de solo lectura. Las cadenas de conexion y el codigo M/VBA no se leen a proposito porque pueden contener credenciales o codigo.",
        };
      }),
  );

  server.registerTool(
    "excel_comparar_archivos",
    {
      title: "Comparar dos versiones de una tabla",
      description:
        "Compara dos libros o CSV y devuelve filas nuevas, eliminadas y cambiadas, mas las columnas comunes y las que solo estan en uno. Recomendado indicar columnas_clave (por ejemplo ID) para emparejar filas; sin ellas se compara por posicion y los cambios aparecen en cascada. Es de solo lectura. Con tolerancia puedes ignorar diferencias numericas pequenas. No escribe ni sincroniza archivos.",
      inputSchema: {
        archivo_a: ARCHIVO.describe("Ruta del archivo A (version anterior). Ejemplo: C:\\datos\\ventas_v1.xlsx"),
        archivo_b: ARCHIVO.describe("Ruta del archivo B (version nueva). Ejemplo: C:\\datos\\ventas_v2.xlsx"),
        hoja_a: HOJA,
        hoja_b: HOJA,
        rango_a: RANGO,
        rango_b: RANGO,
        fila_encabezado_a: FILA_ENCABEZADO,
        fila_encabezado_b: FILA_ENCABEZADO,
        columnas_clave: z
          .array(z.string().min(1).max(200))
          .max(10)
          .default([])
          .describe("Columnas que identifican una fila en ambos archivos. Ejemplo: ['ID'] o ['Fecha','Cliente']."),
        max_filas: z
          .number()
          .int()
          .min(1)
          .max(200_000)
          .default(50_000)
          .describe("Maximo de filas a leer de cada archivo. Si se supera, se avisa y la comparacion es parcial."),
        max_ejemplos: z
          .number()
          .int()
          .min(1)
          .max(100)
          .default(20)
          .describe("Cuantas filas de ejemplo devolver por categoria (nuevas, eliminadas, cambiadas)."),
        ignorar_espacios: z
          .boolean()
          .default(true)
          .describe("Considera iguales los textos que solo difieren en espacios extremos o repetidos."),
        ignorar_mayusculas: z
          .boolean()
          .default(false)
          .describe("Considera iguales los textos que solo difieren en mayusculas/minusculas."),
        tolerancia: z
          .number()
          .min(0)
          .max(1e12)
          .default(0)
          .describe("Diferencia maxima para considerar iguales dos numeros. 0 = exacto. Ejemplo: 0.01."),
      },
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
    },
    async (args) =>
      conManejo(async () => {
        const a = await validarArchivoEntrada(args.archivo_a);
        const b = await validarArchivoEntrada(args.archivo_b);
        const hojaA = await leerHoja(a, {
          hoja: args.hoja_a,
          rango: args.rango_a,
          filaEncabezado: args.fila_encabezado_a,
          maxFilas: args.max_filas,
          maxColumnas: 200,
        });
        const hojaB = await leerHoja(b, {
          hoja: args.hoja_b,
          rango: args.rango_b,
          filaEncabezado: args.fila_encabezado_b,
          maxFilas: args.max_filas,
          maxColumnas: 200,
        });
        const r = compararHojas(hojaA, hojaB, {
          claves: args.columnas_clave,
          maxEjemplos: args.max_ejemplos,
          ignorarEspacios: args.ignorar_espacios,
          ignorarMayusculas: args.ignorar_mayusculas,
          tolerancia: args.tolerancia,
        });
        const avisos = [...new Set([...hojaA.avisos, ...hojaB.avisos, ...r.avisos])];
        return {
          archivoA: a.ruta,
          archivoB: b.ruta,
          hojaA: hojaA.hoja,
          hojaB: hojaB.hoja,
          rangoA: hojaA.rango,
          rangoB: hojaB.rango,
          ...r,
          resumen: r.filas,
          avisos,
        };
      }),
  );

  server.registerTool(
    "excel_generar_reporte",
    {
      title: "Generar un reporte HTML de calidad",
      description:
        "Analiza una hoja y escribe un reporte .html autocontenido (sin scripts ni recursos externos) con resumen, calidad por columna, valores mas frecuentes, estadistica numerica, histograma SVG y una muestra de filas. No abre Excel ni evalua formulas: usa los valores cacheados. Escribe un archivo NUEVO; si ya existe, exige sobrescribir=true y confirmar=true.",
      inputSchema: {
        archivo: ARCHIVO,
        hoja: HOJA,
        rango: RANGO,
        fila_encabezado: FILA_ENCABEZADO,
        salida: z
          .string()
          .min(1)
          .max(4096)
          .optional()
          .describe("Ruta .html de salida. Si se omite: <nombre>_reporte.html junto al archivo original."),
        max_filas: z
          .number()
          .int()
          .min(1)
          .max(50_000)
          .default(5_000)
          .describe("Maximo de filas a analizar. Un reporte muy grande tarda y ocupa mas espacio."),
        max_muestra: z
          .number()
          .int()
          .min(0)
          .max(200)
          .default(30)
          .describe("Filas de muestra en el reporte (0 = no incluir tabla de muestra)."),
        max_valores: z
          .number()
          .int()
          .min(1)
          .max(50)
          .default(10)
          .describe("Valores mas frecuentes por columna."),
        incluir_estadisticas: z
          .boolean()
          .default(true)
          .describe("Incluye media, mediana, cuartiles, desviacion e histograma de columnas numericas."),
        incluir_muestra: z.boolean().default(true).describe("Incluye una tabla con las primeras filas."),
        sobrescribir: z
          .boolean()
          .default(false)
          .describe("Permite reemplazar un reporte existente (requiere confirmar=true)."),
        confirmar: z
          .literal(true)
          .optional()
          .describe("Obligatorio true junto con sobrescribir=true para reemplazar un reporte existente."),
      },
      annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
    },
    async (args) =>
      conManejo(async () => {
        const a = await validarArchivoEntrada(args.archivo);
        const h = await leerHoja(a, {
          hoja: args.hoja,
          rango: args.rango,
          filaEncabezado: args.fila_encabezado,
          maxFilas: args.max_filas,
          maxColumnas: 200,
        });

        const salidaTexto =
          args.salida ??
          path.join(path.dirname(a.ruta), `${path.basename(a.ruta, path.extname(a.ruta))}_reporte.html`);
        const destino = await validarArchivoSalidaHtml(salidaTexto);

        if (mismaRuta(a.ruta, destino.ruta) || (destino.rutaReal !== null && mismaRuta(a.rutaReal, destino.rutaReal))) {
          throw new ErrorExcel(
            "El reporte no puede sobrescribir el archivo de entrada.",
            "Elige otro nombre, por ejemplo ventas_reporte.html.",
          );
        }
        if (destino.existe) {
          if (!args.sobrescribir || args.confirmar !== true) {
            throw new ErrorExcel(
              `Ya existe el reporte: ${destino.ruta}`,
              "Elige otro nombre o envia sobrescribir=true y confirmar=true para reemplazarlo.",
            );
          }
        }

        const { html, resumen } = generarReporte(h, {
          maxMuestra: args.max_muestra,
          maxValores: args.max_valores,
          incluirEstadisticas: args.incluir_estadisticas,
          incluirMuestra: args.incluir_muestra,
        });

        await writeFile(destino.ruta, html, "utf8");
        const info = await stat(destino.ruta);

        return {
          archivo: a.ruta,
          hoja: h.hoja,
          rango: h.rango,
          salida: destino.ruta,
          bytes: info.size,
          resumen,
          avisos: h.avisos,
          nota:
            "Reporte HTML generado sin scripts ni recursos externos. Los valores de formulas son los ultimos guardados por Excel.",
        };
      }),
  );
}
