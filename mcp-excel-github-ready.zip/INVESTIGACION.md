# INVESTIGACION.md — Cómo se controla Excel desde fuera

Fecha: 13 de noviembre de 2026. Sistema: Windows 10/11 (build NT 10.0.26300.0), Node.js v24.22.1.

## 1. Resumen de la decisión

Se eligió una vía **híbrida basada en archivos**:

1. **ExcelJS 4.4.0 (MIT)** para leer y escribir `.xlsx`, `.xlsm` y `.csv`.
2. **Estadística, perfilado, filtros, comparación y limpieza propios en TypeScript**, sin fórmulas ni COM.
3. **JSZip 3.10.2 (MIT/GPL-3.0-or-later)** para inspeccionar el contenedor OOXML sin abrir Excel ni ejecutar nada: tablas, nombres, conexiones, Power Query, dinámicas, macros y protección.
4. **PowerShell de solo lectura** para detectar Excel, su versión y los complementos instalados.
5. **Control visual** (`src/lib/visual/`) únicamente como respaldo para lo que los archivos no permiten: abrir un libro, hacer que Excel recalcule fórmulas y guardar, o llevar la selección a una celda.

Esta combinación es rápida, reproducible, no depende de que Excel esté abierto y no ejecuta código del libro.

## 2. Qué se encontró en el equipo (solo lectura)

| Dato | Valor | Cómo se obtuvo |
|---|---|---|
| Excel instalado | Sí | `App Paths\excel.exe` en el registro |
| Ruta | `C:\Program Files\Microsoft Office\Root\Office16\EXCEL.EXE` | Registro |
| Versión de archivo y producto | `16.0.20527.20150` | `FileVersionInfo` de PowerShell |
| ProgID | `Excel.Application.16` | `HKCR\Excel.Application\CurVer` |
| CLSID | `{00024500-0000-0000-C000-000000000046}` | `HKCR\Excel.Application.16\CLSID` |
| Click-to-Run | `16.0.20527.20150`, `x64`, `es-es` | `HKLM\SOFTWARE\Microsoft\Office\ClickToRun\Configuration` |
| Excel abierto durante la investigación | No | `Get-Process -Name EXCEL` |
| Complementos detectados | Data Streamer, Power Pivot (desactivado) | `HKCU\Software\Microsoft\Office\Excel\Addins` |
| XLSTART | `...\root\Office16\XLSTART` (sin archivos) | Listado de carpeta |

No se abrió Excel, no se ejecutaron macros y no se modificó el registro.

## 3. Vías evaluadas, de la más robusta a la más frágil

### 3.1 API HTTP / WebSocket / plugin oficial — descartada

- **Office JS (complementos)**: la API oficial permite leer y escribir rangos, tablas y eventos. Pero un complemento se ejecuta **dentro** de Excel y necesita un manifiesto, un servidor HTTPS y confianza del usuario. No es una API local a la que este MCP pueda llamar.
- **Office Scripts**: TypeScript en la nube, requiere cuenta Microsoft 365, conexión y permisos del tenant. No es viable para un MCP local y offline.
- **No existe** un servidor HTTP/WebSocket local de Excel documentado. Proyectos de terceros (por ejemplo `excel-webview2-mcp`) se conectan al WebView2 de un complemento concreto; dependen de ese complemento y de sus términos. **REQUIERE REVISIÓN**.
- **Conclusión**: no hay una API local estable que usar.

### 3.2 CLI de la aplicación — descartada

`EXCEL.EXE` acepta parámetros como `/e`, `/r`, `/x`, pero no ofrece un modo "servidor" ni `--help` documentado que devuelva información por consola. Ejecutarlo abre la interfaz y puede mostrar diálogos. No se ejecutó durante la investigación para no alterar el estado del equipo del usuario.

### 3.3 Archivos de datos — **elegida**

Es la vía más robusta para el objetivo:

- `.xlsx`/`.xlsm` son OOXML (ZIP + XML), documentados públicamente (ECMA-376 / ISO 29500).
- ExcelJS (MIT) los lee y escribe, incluidos valores, fórmulas, tablas y estilos.
- CSV es texto plano; se implementó detección de codificación (UTF-8 con/sin BOM, UTF-16LE/BE, windows-1252) y delimitador (`,`, `;`, tabulador, `|`), con campos entre comillas y saltos de línea internos.

**Límite importante**: ExcelJS **no calcula fórmulas**. Solo entrega el resultado cacheado que Excel guardó. Si una fórmula nunca se recalculó, la celda se lee como vacía y se devuelve un aviso. Para resolverlo se añadió una herramienta visual que envía F9 y Ctrl+S a Excel.

### 3.4 Scripting del sistema operativo (COM, PowerShell, VBA) — parcialmente descartada

- **COM** (`New-Object -ComObject Excel.Application`) sí existe y está registrado (`Excel.Application.16`). Permite abrir libros, recalcular, exportar PDF, crear tablas dinámicas y ejecutar macros.
- Se descartó para las operaciones normales por:
  - abre una instancia de Excel (o se conecta a la del usuario),
  - puede mostrar diálogos y bloquearse,
  - es más lento,
  - ejecutar macros del libro es un riesgo de seguridad.
- **PowerShell** se usa solo para **leer** el registro y el sistema de archivos. Los scripts son constantes, se codifican en UTF-16LE + Base64 y no concatenan entrada del modelo.
- **VBA**: no se genera ni se ejecuta código VBA. Escribir módulos queda fuera del alcance (categoría D de `PLUGINS.md`).

### 3.5 Automatización de interfaz — usada solo como respaldo

El proyecto ya trae un módulo visual maduro (`src/lib/visual/`) con captura de ventana, clic, teclado, arrastre y comparación con referencias. Se usa para:

- abrir un libro con **Ctrl+O**,
- recalcular y guardar con **F9** y **Ctrl+S**,
- ir a una celda con **Ctrl+G**.

Ventajas: no depende de COM ni de la versión de Excel. Desventajas: depende del foco, del idioma y de los diálogos; por eso cada herramienta devuelve una captura de verificación y las acciones que escriben exigen `confirmar=true`.

No se debilitó ninguna protección de `nucleo.ts`: siguen activos el freno `PARAR.txt`, el límite de acciones (`VISUAL_MAX_ACCIONES`, 400), la validación de coordenadas contra la última captura y el bloqueo de combinaciones peligrosas (Win, Alt+F4, Ctrl+Alt+…). Precisamente por ese bloqueo se usa **F9** en lugar de Ctrl+Alt+F9.

## 4. Por qué ExcelJS y no otra librería

| Opción | Licencia | Ventaja | Motivo para no elegirla |
|---|---|---|---|
| **ExcelJS 4.4.0** | MIT | Madura, lee/escribe `.xlsx`/`.xlsm`, tablas, estilos, streaming | — (elegida) |
| SheetJS Community | Apache-2.0 | Muy rápida y amplia compatibilidad | Menos soporte de estilos/tablas en la edición comunitaria |
| openpyxl (Python) | MIT | Muy usada, buen soporte | Añade Python y un proceso aparte |
| COM + VBA | — | Control total de Excel | Frágil, abre Excel, riesgo de macros |
| LibreOffice headless | MPL-2.0 | Recalcula fórmulas | Dependencia pesada; no siempre reproduce Excel |

## 5. Formato y codificación: decisiones concretas

- **Entrada admitida**: `.xlsx`, `.xlsm`, `.csv`.
- **Salida admitida**: `.xlsx`, `.csv`.
- **`.xls` antiguo**: se rechaza con un mensaje que pide guardar como `.xlsx`.
- **Libros cifrados**: ExcelJS falla; se explica que hay que quitar la contraseña.
- **CSV de entrada**: se detecta BOM, UTF-16, windows-1252, delimitador y comillas.
- **CSV de salida**: UTF-8 con BOM por defecto (para que Excel en español muestre acentos), delimitador configurable y protección contra fórmulas inyectadas (si un texto empieza por `=`, `+`, `-` o `@`, se antepone un apóstrofo).
- **Límites**: `EXCEL_MAX_MB` (100 MB por defecto) y `EXCEL_MAX_CELDAS` (5 000 000 celdas por lectura, además de los topes de filas/columnas de cada herramienta).

## 6. Seguridad aplicada

- Sin `console.log`: stdout queda limpio para el protocolo MCP.
- Sin `exec` ni concatenación de entrada del modelo: `run()` recibe comando y argumentos separados; los valores variables viajan por variables de entorno.
- Validación con `zod` y `.describe()` en cada parámetro.
- Rutas resueltas con `path`, extensión comprobada, tamaño máximo y, opcionalmente, confinadas a `EXCEL_DIRS`.
- La salida de limpieza **nunca** puede ser el archivo de entrada.
- Escritura solo con `simular=false` + `confirmar=true`; si el destino existe, además `sobrescribir=true`.
- Detección de complementos sin abrir Excel y sin leer código de complementos.
- Todo texto leído de un libro o de una web se trata como **dato**, nunca como instrucción.

## 7. Limitaciones conocidas

1. Los cambios sin guardar de un Excel abierto no se ven: se lee el archivo en disco.
2. Las fórmulas sin resultado cacheado se leen como vacías (se avisa).
3. La escritura no conserva macros, estilos ni fórmulas: exporta valores.
4. No se crean tablas dinámicas, gráficos ni segmentaciones.
5. No se ejecutan macros ni Office Scripts.
6. El control visual depende de la ventana de Excel y del idioma; los diálogos pueden requerir intervención.
7. Las herramientas visuales se probaron con `VISUAL_BACKEND=simulado`; la secuencia real con Excel abierto no se verificó en esta sesión.
8. El proyecto no es un repositorio git; no hay historial de cambios.

## 8. Conclusión

Para leer, analizar y limpiar datos, la vía de archivos es superior: no requiere Excel abierto, es determinista y se puede probar automáticamente. El control visual queda para las tres tareas que los archivos no pueden hacer: mostrar, recalcular y guardar. COM se documenta como alternativa, pero no se usa para no abrir Excel ni ejecutar código del libro.
