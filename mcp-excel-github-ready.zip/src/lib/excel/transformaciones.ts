/**
 * Transformaciones de tablas sobre archivos: ordenar, agrupar/agregar y buscar/reemplazar.
 *
 * Todas trabajan sobre copias de las filas leidas (no mutan el original) y devuelven
 * datos listos para exportar con escribirTabla. Son de solo lectura sobre el archivo
 * de entrada: nunca escriben en el original.
 */
import { ErrorExcel } from "./errores.js";
import {
  resolverColumna,
  valorDeFila,
  type ColumnaLeida,
  type FilaLeida,
  type HojaLeida,
} from "./libro.js";
import { aNumero, limpiarTexto, normalizarTexto, type CeldaNormalizada } from "./valor.js";

// Re-exportamos clonarCelda localmente por si filtros cambia; aqui la reimplementamos
// para no depender de internals no exportados.
function clonarFila(f: FilaLeida): FilaLeida {
  return { numero: f.numero, celdas: f.celdas.map((c) => ({ ...c })) };
}

export type DireccionOrden = "asc" | "desc";

export interface ClaveOrden {
  columna: ColumnaLeida;
  direccion: DireccionOrden;
}

export function ordenarFilas(hoja: HojaLeida, claves: ClaveOrden[]): FilaLeida[] {
  if (claves.length === 0) throw new ErrorExcel("Indica al menos una columna para ordenar.");
  const copia = hoja.filas.map(clonarFila);

  function celdaVacia(c: CeldaNormalizada): boolean {
    return c.tipo === "vacio" || c.formulaSinResultado || c.texto.trim() === "";
  }

  function compararCeldas(a: CeldaNormalizada, b: CeldaNormalizada, direccion: DireccionOrden): number {
    const aV = celdaVacia(a);
    const bV = celdaVacia(b);
    if (aV && bV) return 0;
    if (aV) return direccion === "asc" ? 1 : -1;
    if (bV) return direccion === "asc" ? -1 : 1;

    let cmp = 0;
    if (a.tipo === "numero" && b.tipo === "numero") {
      const na = a.valor as number;
      const nb = b.valor as number;
      cmp = na < nb ? -1 : na > nb ? 1 : 0;
    } else if (a.tipo === "fecha" && b.tipo === "fecha") {
      const sa = String(a.valor ?? "");
      const sb = String(b.valor ?? "");
      cmp = sa < sb ? -1 : sa > sb ? 1 : 0;
    } else {
      const ta = limpiarTexto(a.texto, { colapsarEspacios: true, quitarSaltos: true });
      const tb = limpiarTexto(b.texto, { colapsarEspacios: true, quitarSaltos: true });
      cmp = ta.localeCompare(tb, "es", { sensitivity: "base", numeric: true });
    }
    return direccion === "asc" ? cmp : -cmp;
  }

  copia.sort((fa, fb) => {
    for (const clave of claves) {
      const ca = valorDeFila(fa, clave.columna);
      const cb = valorDeFila(fb, clave.columna);
      const r = compararCeldas(ca, cb, clave.direccion);
      if (r !== 0) return r;
    }
    return 0;
  });
  return copia;
}

export type FuncionAgregacion =
  | "conteo"
  | "suma"
  | "promedio"
  | "minimo"
  | "maximo"
  | "conteo_distintos";

export interface EspecificacionAgregacion {
  columna: ColumnaLeida;
  funcion: FuncionAgregacion;
}

export interface ResultadoAgrupacion {
  encabezados: string[];
  filas: (string | number | null)[][];
  grupos: number;
}

export function agruparTabla(
  hoja: HojaLeida,
  columnasGrupo: ColumnaLeida[],
  agregaciones: EspecificacionAgregacion[],
): ResultadoAgrupacion {
  if (columnasGrupo.length === 0) throw new ErrorExcel("Indica al menos una columna para agrupar.");

  function numeroDeCelda(c: CeldaNormalizada): number | null {
    return aNumero(c.tipo === "numero" ? (c.valor as number) : c.texto);
  }

  const grupos = new Map<string, FilaLeida[]>();
  for (const fila of hoja.filas) {
    const partes = columnasGrupo.map((c) => {
      const cel = valorDeFila(fila, c);
      return cel.tipo === "vacio" || cel.formulaSinResultado ? "" : normalizarTexto(cel.texto);
    });
    const clave = partes.join("\u0001");
    const lista = grupos.get(clave);
    if (lista) lista.push(fila);
    else grupos.set(clave, [fila]);
  }

  const encabezados: string[] = [
    ...columnasGrupo.map((c) => c.nombre),
    "Filas",
    ...agregaciones.map((a) => `${a.columna.nombre} (${a.funcion})`),
  ];

  const filas: (string | number | null)[][] = [];
  for (const [clave, lista] of grupos) {
    const primera = lista[0]!;
    const fila: (string | number | null)[] = columnasGrupo.map((c) => {
      const cel = valorDeFila(primera, c);
      if (cel.tipo === "vacio" || cel.formulaSinResultado) return null;
      if (cel.tipo === "booleano") return cel.valor === true ? "VERDADERO" : "FALSO";
      return cel.valor as string | number | null;
    });
    fila.push(lista.length);

    for (const agg of agregaciones) {
      const col = agg.columna;
      const celdas = lista.map((f) => valorDeFila(f, col));
      switch (agg.funcion) {
        case "conteo":
          fila.push(lista.length);
          break;
        case "conteo_distintos": {
          const vistos = new Set(celdas.map((c) => (c.tipo === "vacio" || c.formulaSinResultado ? "v:" : `${c.tipo}:${normalizarTexto(c.texto)}`)));
          fila.push(vistos.size);
          break;
        }
        case "suma": {
          const nums = celdas.map(numeroDeCelda).filter((n): n is number => n !== null);
          fila.push(nums.length > 0 ? nums.reduce((a, b) => a + b, 0) : null);
          break;
        }
        case "promedio": {
          const nums = celdas.map(numeroDeCelda).filter((n): n is number => n !== null);
          fila.push(nums.length > 0 ? nums.reduce((a, b) => a + b, 0) / nums.length : null);
          break;
        }
        case "minimo": {
          const nums = celdas.map(numeroDeCelda).filter((n): n is number => n !== null);
          fila.push(nums.length > 0 ? Math.min(...nums) : null);
          break;
        }
        case "maximo": {
          const nums = celdas.map(numeroDeCelda).filter((n): n is number => n !== null);
          fila.push(nums.length > 0 ? Math.max(...nums) : null);
          break;
        }
      }
    }
    filas.push(fila);
  }

  // Ordena los grupos por sus claves de agrupacion para salida estable.
  filas.sort((a, b) => {
    for (let i = 0; i < columnasGrupo.length; i++) {
      const va = a[i];
      const vb = b[i];
      const sa = va === null ? "" : String(va);
      const sb = vb === null ? "" : String(vb);
      const r = sa.localeCompare(sb, "es", { numeric: true, sensitivity: "base" });
      if (r !== 0) return r;
    }
    return 0;
  });

  return { encabezados, filas, grupos: filas.length };
}

export interface OpcionesBuscarReemplazar {
  buscar: string;
  reemplazar: string;
  columnas?: ColumnaLeida[];
  coincidenciaExacta?: boolean;
  ignorarMayusculas?: boolean;
  ignorarAcentos?: boolean;
}

export interface ResultadoBuscarReemplazar {
  filas: FilaLeida[];
  reemplazos: number;
  celdasAfectadas: number;
  avisos: string[];
}

export function buscarReemplazar(
  hoja: HojaLeida,
  opciones: OpcionesBuscarReemplazar,
): ResultadoBuscarReemplazar {
  const buscar = opciones.buscar;
  if (buscar === "") throw new ErrorExcel("El texto a buscar no puede estar vacio.");

  const cols = opciones.columnas && opciones.columnas.length > 0 ? opciones.columnas : hoja.columnas;
  const ignorarMay = opciones.ignorarMayusculas !== false;
  const ignorarAce = opciones.ignorarAcentos !== false;
  const exacta = opciones.coincidenciaExacta === true;

  function normalizar(s: string): string {
    return limpiarTexto(s, {
      minusculas: ignorarMay,
      sinAcentos: ignorarAce,
      colapsarEspacios: true,
      quitarSaltos: true,
    });
  }
  const buscarNorm = normalizar(buscar);

  const filas = hoja.filas.map(clonarFila);
  let reemplazos = 0;
  let celdasAfectadas = 0;
  const avisos: string[] = [];

  for (const fila of filas) {
    for (const col of cols) {
      const idx = col.indice - 1;
      const c = fila.celdas[idx];
      if (!c || c.tipo !== "texto" || c.formulaSinResultado) continue;
      const texto = c.texto;
      const textoNorm = normalizar(texto);

      let coincide = false;
      if (exacta) {
        coincide = textoNorm === buscarNorm;
      } else {
        coincide = textoNorm.includes(buscarNorm);
      }
      if (!coincide) continue;

      // Reemplazo literal (sin regex) respetando mayusculas del original cuando sea posible:
      // se hace un reemplazo simple de todas las ocurrencias del texto buscado (case-sensitive
      // sobre el original si no se ignoran mayusculas; si se ignoran, se reemplaza por el
      // valor indicado en todas las ocurrencias detectadas por normalizacion).
      let nuevo = texto;
      if (!ignorarMay && !ignorarAce && !exacta) {
        // Reemplazo literal directo.
        let contador = 0;
        let pos = 0;
        let acc = "";
        while (true) {
          const i = nuevo.indexOf(buscar, pos);
          if (i === -1) break;
          acc += nuevo.slice(pos, i) + opciones.reemplazar;
          pos = i + buscar.length;
          contador++;
        }
        acc += nuevo.slice(pos);
        if (contador > 0) {
          nuevo = acc;
          reemplazos += contador;
        }
      } else {
        // Normalizacion activa: se reemplaza la primera ocurrencia normalizada por el
        // valor indicado. Para multiples ocurrencias se repite buscando en el texto restante.
        // Implementacion robusta: recorrer el texto original y reconstruir.
        const lower = (s: string) => (ignorarMay ? s.toLocaleLowerCase("es") : s);
        // Fallback simple: si el texto normalizado contiene el patron, reemplazar todo el
        // contenido de la celda por el valor de reemplazo cuando sea coincidencia exacta;
        // en caso contrario, hacer un reemplazo case-insensitive basico.
        if (exacta) {
          nuevo = opciones.reemplazar;
          reemplazos += 1;
        } else {
          // Reemplazo case-insensitive basico sobre el original.
          const flags = ignorarMay ? "gi" : "g";
          const escaped = buscar.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
          const re = new RegExp(escaped, flags);
          const matches = texto.match(re);
          if (matches) {
            reemplazos += matches.length;
            nuevo = texto.replace(re, () => opciones.reemplazar);
          }
        }
      }

      if (nuevo !== texto) {
        celdasAfectadas++;
        fila.celdas[idx] = {
          ...c,
          valor: nuevo,
          texto: nuevo,
          formula: null,
          formulaSinResultado: false,
        };
      }
    }
  }

  if (reemplazos === 0) avisos.push("No se encontro ninguna ocurrencia del texto buscado.");
  return { filas, reemplazos, celdasAfectadas, avisos };
}

// (sin imports adicionales)
