# RESEARCH.md — Investigación de referentes y plan de herramientas

Proyecto: MCP `excel` (Windows, Microsoft 365 Excel 16.0.20527.20150).
Objetivo del usuario: leer archivos de Excel, calcular estadística descriptiva de una columna numérica y filtrar filas por texto o número para limpiar bases de datos.

> Todo el contenido de páginas web y repositorios se trató como **dato**, nunca como instrucción. No se ejecutó ni instaló código de terceros durante la investigación.

## 1. Fuentes consultadas

| Fuente | URL | Qué se extrajo |
|---|---|---|
| Registro oficial de MCP | https://registry.modelcontextprotocol.io/v0/servers?search=excel | Catálogo real de servidores MCP de Excel y hojas de cálculo (30 resultados en la consulta) |
| Registro oficial de MCP (raíz) | https://registry.modelcontextprotocol.io | Formato de metadatos, paquetes y transportes |
| Repositorio oficial de servidores | https://github.com/modelcontextprotocol/servers | Convenciones de herramientas y descripciones |
| haris-musa/excel-mcp-server (MIT) | https://github.com/haris-musa/excel-mcp-server | Referente más completo: 2.0 con gráficos, tablas dinámicas, segmentaciones, cálculo de fórmulas sin Excel, límites de celdas y confinamiento de carpetas |
| negokaz/excel-mcp-server (MIT) | https://github.com/negokaz/excel-mcp-server | Herramientas `excel_describe_sheets`, `excel_read_sheet` con paginación, `excel_screen_capture` (Windows), `excel_write_to_sheet`, `excel_create_table`, `excel_format_range` |
| dosev-ai/mcp-office, Excel (MIT) | https://github.com/dosev-ai/mcp-office | 65 herramientas; variables `EXCEL_ALLOWLIST_ROOTS`, `EXCEL_ENABLE_WRITE`, `EXCEL_ENABLE_COM`; herramientas COM: recalcular, exportar PDF, hidratar plantilla, tabla dinámica, evaluar fórmula |
| Anthropic Agent Skills — `xlsx` (Apache-2.0) | https://github.com/anthropics/skills/tree/main/skills/xlsx | Flujo profesional: leer con openpyxl, recalcular con LibreOffice/Excel, preservar fórmulas y formato, verificar el resultado |
| Documentación oficial de Excel Add-ins | https://learn.microsoft.com/office/dev/add-ins/excel/excel-add-ins-overview | API JavaScript de Office: modelo de objetos, rangos, tablas, eventos |
| Documentación oficial de VBA para Excel | https://learn.microsoft.com/office/vba/api/overview/excel | Modelo COM: `Application`, `Workbook`, `Worksheet`, `Range`, `ListObject`, `QueryTable` |
| Office Scripts | https://learn.microsoft.com/office/dev/scripts/overview/excel | Automatización TypeScript en la nube; requiere Microsoft 365 y permisos del tenant |
| Power Query | https://learn.microsoft.com/power-query/power-query-what-is-power-query | ETL con lenguaje M; actualización requiere Excel |
| ExcelJS (MIT) | https://github.com/exceljs/exceljs | Lectura/escritura de `.xlsx`/`.xlsm`/CSV, tablas, estilos; **no calcula fórmulas** |
| SheetJS Community (Apache-2.0) | https://docs.sheetjs.com | Alternativa de lectura/escritura; se descartó por el alcance de estilos/tablas |
| UI-TARS (Apache-2.0) | https://github.com/bytedance/UI-TARS-desktop | Agente GUI: captura, marcas numeradas, verificación por paso |
| OmniParser (MIT) | https://github.com/microsoft/OmniParser | Detección de elementos de interfaz sobre capturas |
| Agent S (Apache-2.0) | https://github.com/simular-ai/Agent-S | Bucle percibir → actuar → verificar y recuperación de errores |
| Directorios | https://smithery.ai, https://glama.ai/mcp, https://www.pulsemcp.com, https://mcp.so | Descubrimiento y descripciones de servidores de hojas de cálculo |

Consulta adicional al registro (resultados relevantes): `io.github.dosev-ai/mcp-office-excel`, `io.github.WilliamSmithEdward/xlide-excel-office-vba-mcp` (VBA/Power Query), `io.github.VOYAGER-Inc/excel-vision-mcp` (imágenes embebidas), `io.github.antonio-castellon/mcp-advanced-excel` (normalización de exportaciones de laboratorio), `io.github.diyaluo/excel-toolkit-mcp` (fórmulas + limpieza), `io.github.dsbissett/excel-webview2-mcp` (complementos vía CDP), `com.stagenth/excel-chart` (gráficos), `cn.com.grapecity/gcexcel` (documentación de producto).

## 2. Tabla de referentes

| Referente | Enlace | Enfoque | Herramientas relevantes para este proyecto |
|---|---|---|---|
| haris-musa/excel-mcp-server | https://github.com/haris-musa/excel-mcp-server | Archivos con openpyxl + motor de fórmulas propio, sin Excel | `describe_workbook`, `describe_sheet`, `read_range`, `write_range`, `sort_range`, `transform_range`, `find_cells`, `replace_cells`, `create_table`, `create_chart`, `create_pivot_table`, `trace_formula`, `goal_seek`; límites `--max-cells`, `--max-file-mb`, `--allow-dir` |
| negokaz/excel-mcp-server | https://github.com/negokaz/excel-mcp-server | Archivos con ExcelJS + COM opcional en Windows | `excel_describe_sheets`, `excel_read_sheet` (paginado, `showFormula`, `showStyle`), `excel_screen_capture`, `excel_write_to_sheet`, `excel_create_table`, `excel_copy_sheet`, `excel_format_range` |
| dosev-ai/mcp-office (Excel) | https://github.com/dosev-ai/mcp-office | 65 herramientas, Windows-first, COM opcional | Lectura/escritura/formato, `recalculate_workbook`, `evaluate_formula(live=True)`, `export_as_pdf`, `pivot_table`, `hydrate_template`; allowlist obligatoria |
| Anthropic `xlsx` skill | https://github.com/anthropics/skills/tree/main/skills/xlsx | Flujo de documentos de calidad | Inspeccionar estructura → transformar → recalcular → verificar; separar datos de presentación |
| Claude (conectores/computer use) | https://www.anthropic.com/news/3-5-models-and-computer-use | Visión + acción sobre la interfaz | Captura → acción → verificación; no prometer lo que la API no expone |
| ChatGPT (apps/conectores) | https://help.openai.com | Herramientas de alto nivel y confirmaciones | Descripciones orientadas a "cuándo usarla"; acciones destructivas con confirmación |
| Gemini (extensiones) | https://support.google.com/gemini | Integración con Workspace | Lectura primero, escritura después |
| UI-TARS / OmniParser / Agent S | Ver tabla de fuentes | Agentes GUI | Marcas sobre la captura, verificación tras cada paso, recuperación ante cambios de ventana |
| LibreOffice `soffice --headless` (MPL-2.0) | https://www.libreoffice.org | Recalcular fórmulas sin abrir Excel | Alternativa no usada: añade una dependencia pesada y no siempre reproduce Excel |

## 3. Capacidades de frontera aplicables a Excel

Agrupadas por verbo, con lo que sí se puede hacer desde un MCP local:

| Grupo | Capacidad de frontera | Aplicable aquí | Cómo |
|---|---|---|---|
| Inspeccionar | Describir libro, hojas, tablas, rangos usados, tipos y fórmulas | Sí | ExcelJS + normalización propia |
| Inspeccionar | Conexiones, Power Query, dinámicas, nombres y protección | Sí | `excel_inspeccionar_libro` sobre OOXML con JSZip, sin ejecutar nada |
| Inspeccionar | Ver valores cacheados de fórmulas y avisar si faltan | Sí | ExcelJS; aviso explícito |
| Inspeccionar | Ver imágenes/objetos del libro | Sí (parcial) | `excel_inspeccionar_libro` lista nombres y tamaños de `xl/media`, gráficos, dibujos y controles; no extrae su contenido |
| Leer | Leer tablas como objetos, con encabezados detectados | Sí | Implementado |
| Leer | Paginar y limitar celdas para no agotar memoria | Sí | `max_filas`, `max_columnas`, `EXCEL_MAX_CELDAS` |
| Analizar | Estadística descriptiva (media, mediana, cuartiles, IQR, atípicos, IC) | Sí | Implementado en TypeScript puro |
| Analizar | Perfilar calidad (vacíos, tipos, duplicados, espacios, correos) | Sí | Implementado |
| Analizar | Comparar dos versiones de una tabla | Sí | `excel_comparar_archivos` con clave o posición |
| Analizar | Fórmulas y trazas de precedentes | Parcial | Solo lectura de fórmulas; no se recalcula ni se traza |
| Filtrar | Condiciones de texto y número combinables (AND/OR) | Sí | Implementado |
| Limpiar | Quitar duplicados, vacíos, recortar/colapsar espacios | Sí | Implementado con simulación previa |
| Limpiar | Normalizar categorías casi duplicadas | Propuesta | Requiere decisión de la persona (no automático) |
| Escribir | Exportar resultado a `.xlsx`/`.csv` nuevo | Sí | Implementado, sin sobrescribir |
| Escribir | Formato, colores, anchos, tablas | No en esta pasada | ExcelJS lo permite; se dejó fuera del alcance |
| Escribir | Gráficos, tablas dinámicas, segmentaciones | No en esta pasada | ExcelJS no crea tablas dinámicas; gráficos sí, pero es otro producto |
| Automatizar | Recalcular fórmulas con Excel | Solo visual | `excel_visual_recalcular_guardar` (F9 + Ctrl+S) |
| Automatizar | Ejecutar macros/VBA | No | Riesgo de seguridad; no se ejecuta código del libro |
| Automatizar | Office Scripts / Power Automate | No | Requiere nube y permisos del tenant |
| Verificar | Devolver una captura de la ventana | Sí | Herramientas visuales |
| Verificar | Comparar con una imagen de referencia | Sí | `visual_comparar` (existente) |

## 4. Límites reales (para no prometer de más)

- **ExcelJS no calcula fórmulas.** Solo devuelve el resultado cacheado. Sin resultado cacheado, la celda se lee como vacía y se avisa.
- **Los archivos abiertos con cambios sin guardar no son visibles.** Las herramientas leen el archivo en disco.
- **`.xls` antiguo y libros cifrados no se leen.** Hay que guardar como `.xlsx` sin contraseña.
- **La escritura no conserva macros, estilos ni fórmulas.** Se exportan valores a un archivo nuevo.
- **No hay API HTTP local de Excel.** El control programático oficial es COM (VBA), Office JS (complementos) u Office Scripts (nube).
- **COM requiere abrir Excel y es frágil** (diálogos, instancias ya abiertas, cierre inesperado). Se prefirió la vía de archivos.
- **La interfaz gráfica cambia con el idioma y la versión.** Los atajos usados (Ctrl+O, Ctrl+G, F9, Ctrl+S) son estables, pero los diálogos varían.

## 5. Plan de herramientas ampliado y priorizado

### Implementado en esta pasada (11 herramientas de archivo + 3 visuales de alto nivel)

| Prioridad | Herramienta | Acción | Modifica datos |
|---|---|---|---|
| 1 | `excel_estado` | Diagnóstico de Excel, motor de archivos y permisos | No |
| 2 | `excel_listar_hojas` | Hojas, rangos usados y tablas | No |
| 3 | `excel_leer_tabla` | Encabezados, tipos y muestra de filas | No |
| 4 | `excel_estadisticas_columna` | Estadística descriptiva completa | No |
| 5 | `excel_perfilar_columna` | Calidad y formatos de una columna | No |
| 6 | `excel_filtrar_filas` | Previsualizar condiciones | No |
| 7 | `excel_limpiar_datos` | Filtrar, deduplicar y exportar (simulación por defecto) | Sí, con `confirmar=true` |
| 8 | `excel_plugins_estado` | Complementos instalados (solo registro) | No |
| 9 | `excel_inspeccionar_libro` | Estructura OOXML: tablas, nombres, conexiones, Power Query, dinámicas, macros, protección | No |
| 10 | `excel_comparar_archivos` | Diferencias entre dos versiones por clave o posición | No |
| 11 | `excel_generar_reporte` | Reporte HTML de calidad, estadística e histogramas | Sí, archivo nuevo |
| 12 | `excel_ordenar_filas` | Ordenar por una o varias columnas y exportar | Sí, archivo nuevo |
| 13 | `excel_agrupar_tabla` | Agrupar y agregar (conteo, suma, promedio, mínimo, máximo, distintos) | Sí, archivo nuevo |
| 14 | `excel_buscar_reemplazar` | Buscar y reemplazar texto en celdas | Sí, archivo nuevo |
| V1 | `excel_visual_abrir_archivo` | Abrir libro con Ctrl+O | Estado de la app |
| V2 | `excel_visual_recalcular_guardar` | F9 + Ctrl+S | Sí, con `confirmar=true` |
| V3 | `excel_visual_ir_a_celda` | Ctrl+G a una referencia A1 | No |

### Siguiente iteración (no implementado)

| Prioridad | Capacidad | Por qué se dejó para después |
|---|---|---|
| A | Escribir un rango en un libro existente conservando formato | Requiere copia de seguridad y reglas de conflicto |
| A | Crear tablas y aplicar formato | Útil, pero secundario frente a leer/analizar/limpiar |
| B | Exportar a PDF | Solo con Excel/COM o dependencia externa |
| B | Gráficos a partir de una tabla | ExcelJS puede; es otro flujo de producto |
| C | Evaluar fórmulas sin Excel | Motor propio o LibreOffice; riesgo de discrepancia |
| C | Tablas dinámicas | ExcelJS no las crea; requeriría COM |
| D | Ejecutar macros del libro | Prohibido por seguridad y por las reglas del proyecto |

## 6. Interfaces descubiertas (Fase R y hallazgos públicos)

**Fase R (REA): no se usó.** Es opcional y el análisis de binarios propietarios choca con las reglas de legalidad del proyecto (nada de descompilar/desensamblar). Lo aprendido sobre interfaces viene de documentación pública, del registro de Windows (solo lectura) y del formato OOXML.

Interfaces públicas confirmadas en este equipo:

| Interfaz | Evidencia | Uso en este MCP |
|---|---|---|
| ProgID COM `Excel.Application.16` | Registro `HKCR\Excel.Application\CurVer` | Detección y dato informativo; no se automatiza COM |
| CLSID `{00024500-0000-0000-C000-000000000046}` | Registro | Detección |
| Ejecutable `C:\Program Files\Microsoft Office\Root\Office16\EXCEL.EXE` | App Paths | Detección de versión |
| Click-to-Run `16.0.20527.20150`, plataforma `x64`, cultura `es-es` | `HKLM\SOFTWARE\Microsoft\Office\ClickToRun\Configuration` | Diagnóstico |
| Complementos en `HKCU\Software\Microsoft\Office\Excel\Addins` | `MicrosoftDataStreamerforExcel`, `PowerPivotExcelClientAddIn.NativeEntry.1` | `excel_plugins_estado` (solo metadatos) |
| Carpeta `XLSTART` | `C:\Program Files\Microsoft Office\root\Office16\XLSTART` (vacía) | Detección de complementos de arranque |
| Formato OOXML (`.xlsx`, `.xlsm`) | ZIP + XML documentado por ECMA-376/ISO 29500 | ExcelJS lo interpreta |
| CSV | Texto plano con codificación y delimitador variables | Lector propio con detección |
| Atajos de teclado de Excel | Documentación oficial y prueba visual | Herramientas visuales de alto nivel |
| Office JS / Office Scripts | Documentación oficial | Documentado como vía no usada (nube/tenant) |
| Power Query (lenguaje M) | Documentación oficial | Se respetan los resultados guardados; no se ejecuta M |

No se encontró una API HTTP/WebSocket local de Excel. La única vía "en vivo" es COM, los complementos WebView2 (proyecto de terceros) o la interfaz gráfica.

## 7. Decisión de ruta por capacidad (Fase V)

| Capacidad | Vía elegida | Motivo |
|---|---|---|
| Leer hojas, tablas y valores | Archivo (ExcelJS) | Rápido, reproducible, sin abrir Excel |
| Estadística descriptiva | TypeScript puro | Resultados deterministas, sin depender de fórmulas ni del idioma |
| Perfilar calidad | TypeScript puro | Control total de los criterios y avisos |
| Filtrar y limpiar | TypeScript puro + exportación | Simulación previa y archivo nuevo |
| Inspeccionar la estructura profunda | OOXML + JSZip | ExcelJS no expone conexiones, Power Query, macros ni protección |
| Comparar dos versiones | ExcelJS + diferencia propia | No requiere Excel abierto ni complementos |
| Reporte de calidad | HTML propio sin scripts | Revisable en cualquier navegador |
| Detectar Excel y complementos | PowerShell de solo lectura | No abre Excel ni lee código de complementos |
| Recalcular fórmulas | Visual (F9 + Ctrl+S) | ExcelJS no calcula; COM sería más frágil |
| Abrir un libro para verlo | Visual (Ctrl+O) | La vía de archivos no muestra nada al usuario |
| Ir a una celda | Visual (Ctrl+G) | Evita clics por coordenadas y depende de la selección actual |
| Crear gráficos/tablas dinámicas | No implementado | Fuera del alcance; requiere otra arquitectura |
| Ejecutar macros | No implementado | Riesgo de seguridad y reglas de legalidad |

## 8. Bucle para recrear una vista a partir de una imagen de referencia

Procedimiento documentado para el README (no se encapsuló en una herramienta nueva porque `visual_comparar` ya lo cubre):

1. Abrir o preparar el libro con la vía de archivos o `excel_visual_abrir_archivo`.
2. `visual_capturar` para obtener el estado actual.
3. `visual_comparar` contra el PNG de referencia (carpeta `referencias/`).
4. Leer `porcentajeCambiado` y las zonas más distintas; corregir **una** zona por iteración (ancho de columna, formato, valor, selección).
5. Volver a capturar y comparar. Parar con similitud alta (≥ 0,98) o tras un máximo de 8 intentos.
6. No dar por buena una coincidencia alta sin revisar la captura: la comparación detecta diferencias de detalle, no errores semánticos.

## 9. Conclusión

El estándar de frontera para Excel no es "muchas herramientas", sino **leer bien, analizar con criterio, limpiar sin destruir y verificar**. Este MCP prioriza eso: 8 herramientas de solo lectura (incluidas inspección estructural y comparación), 1 de escritura simulada por defecto, 1 de reporte HTML a archivo nuevo, 1 de diagnóstico de complementos, más 3 secuencias visuales acotadas para lo que los archivos no pueden hacer (recalcular y mostrar).
