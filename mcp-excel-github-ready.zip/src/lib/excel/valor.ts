/**
 * Normalizacion de valores de celda y conversion de texto a numero.
 *
 * ExcelJS entrega numeros, fechas, booleanos, textos, errores y formulas con resultado
 * cacheado. Aqui se unifica todo eso para que las demas capas no tengan que saberlo.
 */
import type ExcelJS from "exceljs";
import { ErrorExcel } from "./errores.js";

export type TipoCelda = "vacio" | "numero" | "texto" | "fecha" | "booleano" | "error";

export interface CeldaNormalizada {
  tipo: TipoCelda;
  /** Numero, texto, booleano o ISO de fecha. null si esta vacia o es un error. */
  valor: number | string | boolean | null;
  /** Representacion legible (para mostrar y comparar como texto). */
  texto: string;
  /** Formula original, si la celda es una formula. */
  formula: string | null;
  /** true si era formula y el archivo no trae resultado cacheado. */
  formulaSinResultado: boolean;
  /** Formato numerico de Excel, si existe. */
  formato: string | null;
}

export interface OpcionesNumero {
  /** "auto" (coma decimal en caso de duda), "punto" o "coma". */
  decimal?: "auto" | "punto" | "coma";
  /** Si es false, un "%" no divide por 100. */
  interpretarPorcentaje?: boolean;
}

const VACIA: CeldaNormalizada = {
  tipo: "vacio",
  valor: null,
  texto: "",
  formula: null,
  formulaSinResultado: false,
  formato: null,
};

function esObjeto(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null;
}

function textoDeRichText(rt: unknown): string | null {
  if (!Array.isArray(rt)) return null;
  const partes: string[] = [];
  for (const p of rt) {
    if (esObjeto(p) && typeof p.text === "string") partes.push(p.text);
    else if (typeof p === "string") partes.push(p);
  }
  return partes.join("");
}

function fechaISO(d: Date): string {
  if (Number.isNaN(d.getTime())) return "";
  return d.toISOString();
}

function transferirFormula(base: CeldaNormalizada, formula: string | null, sinResultado: boolean): CeldaNormalizada {
  return { ...base, formula, formulaSinResultado: sinResultado };
}

/** Convierte el `value` crudo de ExcelJS en una celda normalizada. */
export function normalizarValor(valor: unknown, formato: string | null = null): CeldaNormalizada {
  if (valor === null || valor === undefined || valor === "") {
    return { ...VACIA, formato };
  }

  if (typeof valor === "number") {
    if (!Number.isFinite(valor)) {
      return { tipo: "error", valor: null, texto: "NUMERO_INVALIDO", formula: null, formulaSinResultado: false, formato };
    }
    return { tipo: "numero", valor, texto: String(valor), formula: null, formulaSinResultado: false, formato };
  }

  if (typeof valor === "boolean") {
    return {
      tipo: "booleano",
      valor,
      texto: valor ? "VERDADERO" : "FALSO",
      formula: null,
      formulaSinResultado: false,
      formato,
    };
  }

  if (valor instanceof Date) {
    const iso = fechaISO(valor);
    return { tipo: "fecha", valor: iso, texto: iso, formula: null, formulaSinResultado: false, formato };
  }

  if (typeof valor === "string") {
    return { tipo: "texto", valor, texto: valor, formula: null, formulaSinResultado: false, formato };
  }

  if (esObjeto(valor)) {
    // Formula (normal o compartida) con resultado cacheado.
    const formula =
      typeof valor.formula === "string"
        ? valor.formula
        : typeof valor.sharedFormula === "string"
          ? valor.sharedFormula
          : null;
    if (formula !== null) {
      const resultado = "result" in valor ? valor.result : undefined;
      if (resultado === undefined || resultado === null || resultado === "") {
        return {
          tipo: "vacio",
          valor: null,
          texto: "",
          formula,
          formulaSinResultado: true,
          formato,
        };
      }
      return transferirFormula(normalizarValor(resultado, formato), formula, false);
    }

    // Error de Excel (#DIV/0!, #N/A...).
    if (typeof valor.error === "string") {
      return { tipo: "error", valor: null, texto: valor.error, formula: null, formulaSinResultado: false, formato };
    }

    // Texto enriquecido.
    const rt = textoDeRichText(valor.richText);
    if (rt !== null) {
      return { tipo: "texto", valor: rt, texto: rt, formula: null, formulaSinResultado: false, formato };
    }

    // Hipervinculo con texto visible.
    if (typeof valor.text === "string") {
      return { tipo: "texto", valor: valor.text, texto: valor.text, formula: null, formulaSinResultado: false, formato };
    }

    // Algunos escritores usan { value: ... } o { result: ... } sin formula.
    if ("value" in valor && !("richText" in valor)) return normalizarValor(valor.value, formato);
    if ("result" in valor) return normalizarValor(valor.result, formato);
  }

  return {
    tipo: "texto",
    valor: String(valor),
    texto: String(valor),
    formula: null,
    formulaSinResultado: false,
    formato,
  };
}

export function normalizarCelda(celda: ExcelJS.Cell): CeldaNormalizada {
  const formato = typeof celda.numFmt === "string" && celda.numFmt.length > 0 ? celda.numFmt : null;
  try {
    return normalizarValor(celda.value, formato);
  } catch {
    return normalizarValor(celda.text ?? null, formato);
  }
}

/** Texto visible de una celda (nunca null). */
export function textoCelda(c: CeldaNormalizada): string {
  return c.texto;
}

const SIMBOLOS_MONEDA = /[$€£¥₡₹₩₽₺₴₦₱₲₵₸₼₾]/g;
const CODIGOS_MONEDA =
  /\b(?:USD|EUR|GBP|CLP|ARS|MXN|COP|PEN|BRL|UYU|BOB|PYG|VES|DOP|GTQ|CRC|HNL|NIO|PAB|ILS|JPY|CNY|CHF|CAD|AUD|NZD|SEK|NOK|DKK|PLN|CZK|HUF|RON|BGN|HRK|RUB|UAH|TRY|ZAR|INR|KRW|SGD|HKD|THB|MYR|IDR|PHP|VND|AED|SAR|QAR|KWD|BHD|OMR|JOD|EGP|NGN|KES|GHS|MAD|TND|DZD)\b/g;

function quitarEspaciosNumericos(s: string): string {
  return s.replace(/[\s\u00a0\u2007\u202f]/g, "");
}

/**
 * Convierte un valor a numero.
 *
 * Acepta numeros reales, texto con separadores de miles/decimales, simbolos de moneda,
 * parentesis para negativos y porcentajes. Devuelve null si no es un numero razonable.
 *
 * En caso ambiguo ("1,234") se interpreta coma decimal, que es lo habitual en Excel en
 * espanol. Se puede forzar con la variable EXCEL_DECIMAL=punto|coma.
 */
export function aNumero(valor: unknown, opciones: OpcionesNumero = {}): number | null {
  if (typeof valor === "number") return Number.isFinite(valor) ? valor : null;
  if (typeof valor === "boolean" || valor === null || valor === undefined) return null;
  if (valor instanceof Date) return null;
  if (typeof valor !== "string") return null;

  let s = valor.trim();
  if (s === "") return null;

  let negativo = false;
  if (/^\(.*\)$/.test(s)) {
    negativo = true;
    s = s.slice(1, -1).trim();
  }

  let porcentaje = false;
  if (s.includes("%")) {
    porcentaje = true;
    s = s.replace(/%/g, "");
  }

  s = s.replace(CODIGOS_MONEDA, "").replace(SIMBOLOS_MONEDA, "").trim();
  s = quitarEspaciosNumericos(s);
  if (s === "") return null;

  let signo = 1;
  if (s.startsWith("+")) s = s.slice(1);
  else if (s.startsWith("-")) {
    signo = -1;
    s = s.slice(1);
  }

  // Exponente separado para no confundirlo con separadores.
  let exponente = "";
  const mExp = /^(.*?)([eE][+-]?\d+)$/.exec(s);
  if (mExp) {
    s = mExp[1]!;
    exponente = mExp[2]!;
  }

  if (!/^\d[\d.,]*$/.test(s)) return null;

  const modo = opciones.decimal ?? (process.env.EXCEL_DECIMAL === "punto" || process.env.EXCEL_DECIMAL === "coma" ? process.env.EXCEL_DECIMAL : "auto");
  const puntos = (s.match(/\./g) ?? []).length;
  const comas = (s.match(/,/g) ?? []).length;

  let normalizado: string;
  if (puntos > 0 && comas > 0) {
    const ultimoPunto = s.lastIndexOf(".");
    const ultimaComa = s.lastIndexOf(",");
    if (ultimaComa > ultimoPunto) {
      // 1.234,56 -> coma decimal
      normalizado = s.replace(/\./g, "").replace(",", ".");
    } else {
      // 1,234.56 -> punto decimal
      normalizado = s.replace(/,/g, "");
    }
  } else if (comas > 0) {
    if (modo === "punto") normalizado = s.replace(/,/g, "");
    else if (comas > 1) normalizado = s.replace(/,/g, "");
    else normalizado = s.replace(",", ".");
  } else if (puntos > 0) {
    if (modo === "coma") normalizado = s.replace(/\./g, "");
    else if (puntos > 1) normalizado = s.replace(/\./g, "");
    else normalizado = s;
  } else {
    normalizado = s;
  }

  const n = Number(`${normalizado}${exponente}`);
  if (!Number.isFinite(n)) return null;
  let resultado = signo * n;
  if (negativo) resultado = -Math.abs(resultado);
  if (porcentaje && opciones.interpretarPorcentaje !== false) resultado /= 100;
  return resultado;
}

export interface OpcionesTexto {
  minusculas?: boolean;
  sinAcentos?: boolean;
  colapsarEspacios?: boolean;
  quitarSaltos?: boolean;
}

/** Limpieza real del texto (conserva mayusculas y acentos salvo que se pida lo contrario). */
export function limpiarTexto(s: string, opciones: OpcionesTexto = {}): string {
  let t = s.replace(/\u00a0/g, " ").replace(/[\u200b-\u200d\ufeff]/g, "");
  if (opciones.quitarSaltos) t = t.replace(/[\r\n\t]+/g, " ");
  else t = t.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  t = t.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, "");
  if (opciones.colapsarEspacios) t = t.replace(/[ \t]+/g, " ");
  t = t.trim();
  if (opciones.minusculas) t = t.toLocaleLowerCase("es");
  if (opciones.sinAcentos) t = t.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  return t;
}

/** Clave de comparacion: sin mayusculas, sin acentos, espacios colapsados. */
export function normalizarTexto(s: string): string {
  return limpiarTexto(s, { minusculas: true, sinAcentos: true, colapsarEspacios: true, quitarSaltos: true });
}

/** Clave estable para detectar duplicados sin confundir 1 con "1,0". */
export function claveValor(c: CeldaNormalizada): string {
  if (c.tipo === "vacio" || c.formulaSinResultado) return "v:";
  if (c.tipo === "numero") return `n:${(c.valor as number).toPrecision(15)}`;
  if (c.tipo === "booleano") return `b:${c.valor === true ? "1" : "0"}`;
  if (c.tipo === "fecha") return `f:${String(c.valor)}`;
  if (c.tipo === "error") return `e:${c.texto}`;
  return `t:${normalizarTexto(c.texto)}`;
}

export function pareceEmail(s: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(s) && s.length <= 254;
}

export function pareceUrl(s: string): boolean {
  return /^https?:\/\/[^\s.]+\.[^\s]{2,}$/i.test(s) && s.length <= 2048;
}

export function pareceTelefono(s: string): boolean {
  const limpio = s.replace(/[\s().-]/g, "");
  return /^\+?\d{7,15}$/.test(limpio);
}

/** Valida un numero escrito por el modelo para usarlo en un filtro. */
export function numeroDeParametro(valor: string | number, etiqueta: string): number {
  const n = aNumero(valor);
  if (n === null) throw new ErrorExcel(`"${etiqueta}" debe ser un numero valido; recibi ${JSON.stringify(valor)}.`);
  return n;
}
