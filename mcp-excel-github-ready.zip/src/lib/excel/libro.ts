/**
 * Lectura de libros .xlsx/.xlsm y CSV con ExcelJS.
 *
 * ExcelJS no calcula formulas: usa el resultado cacheado que Excel guardo la ultima vez.
 * Si una formula no tiene resultado, la celda queda vacia y se avisa en vez de inventarlo.
 */
import { readFile } from "node:fs/promises";
import path from "node:path";
import ExcelJS from "exceljs";
import { ErrorExcel } from "./errores.js";
import { columnaALetra, parsearRango, rangoATexto, type RangoA1 } from "./rango.js";
import type { ArchivoEntrada } from "./rutas.js";
import { normalizarCelda, type CeldaNormalizada } from "./valor.js";

export interface TablaResumen {
  nombre: string;
  rango: string;
  filaEncabezado: number;
  filas: number;
  columnas: number;
}

export interface HojaResumen {
  nombre: string;
  indice: number;
  estado: "visible" | "hidden" | "veryHidden" | string;
  filas: number;
  columnas: number;
  rango: string | null;
  tablas: TablaResumen[];
}

export interface ColumnaLeida {
  indice: number;
  letra: string;
  nombre: string;
}

export interface FilaLeida {
  numero: number;
  celdas: CeldaNormalizada[];
}

export interface HojaLeida {
  archivo: string;
  hoja: string;
  filaEncabezado: number;
  rango: string;
  columnas: ColumnaLeida[];
  filas: FilaLeida[];
  filasTotalesDatos: number;
  columnasTotales: number;
  truncadoFilas: boolean;
  truncadoColumnas: boolean;
  filasVacias: number;
  formulaSinResultado: number;
  tablas: TablaResumen[];
  tablaUsada: string | null;
  avisos: string[];
}

interface LibroCargado {
  ruta: string;
  extension: string;
  workbook: ExcelJS.Workbook;
  avisos: string[];
}

interface OpcionesLeer {
  hoja?: string;
  rango?: string;
  filaEncabezado?: number;
  maxFilas: number;
  maxColumnas: number;
}

const MAX_FILAS_SEGURIDAD = 250_000;
const MAX_COLUMNAS_SEGURIDAD = 1_000;

function parsearTabla(t: ExcelJS.Table): TablaResumen {
  let r: RangoA1;
  try {
    r = parsearRango(t.ref);
  } catch {
    r = { filaInicio: 1, colInicio: 1, filaFin: 1, colFin: 1 };
  }
  const filas = Math.max(0, r.filaFin - r.filaInicio);
  return {
    nombre: t.name,
    rango: t.ref,
    filaEncabezado: r.filaInicio,
    filas,
    columnas: r.colFin - r.colInicio + 1,
  };
}

function tablasDe(hoja: ExcelJS.Worksheet): TablaResumen[] {
  try {
    return hoja.getTables().map(([t]) => parsearTabla(t));
  } catch {
    return [];
  }
}

function rangoDeDimensiones(hoja: ExcelJS.Worksheet): RangoA1 | null {
  const d = hoja.dimensions;
  if (!d || d.bottom < d.top || d.right < d.left) return null;
  if (d.top < 1 || d.left < 1) return null;
  return { filaInicio: d.top, colInicio: d.left, filaFin: d.bottom, colFin: d.right };
}

function decodificarCsv(buf: Buffer): { texto: string; codificacion: string } {
  if (buf.length >= 3 && buf[0] === 0xef && buf[1] === 0xbb && buf[2] === 0xbf) {
    return { texto: buf.subarray(3).toString("utf8"), codificacion: "utf-8 con BOM" };
  }
  if (buf.length >= 2 && buf[0] === 0xff && buf[1] === 0xfe) {
    return { texto: new TextDecoder("utf-16le").decode(buf.subarray(2)), codificacion: "utf-16le" };
  }
  if (buf.length >= 2 && buf[0] === 0xfe && buf[1] === 0xff) {
    const texto = new TextDecoder("utf-16be").decode(buf.subarray(2));
    return { texto, codificacion: "utf-16be" };
  }
  // UTF-16 sin BOM: muchos bytes nulos en las posiciones impares.
  const muestra = buf.subarray(0, Math.min(4000, buf.length));
  let nulosPares = 0;
  let nulosImpares = 0;
  for (let i = 0; i < muestra.length; i++) {
    if (muestra[i] === 0) {
      if (i % 2 === 0) nulosPares++;
      else nulosImpares++;
    }
  }
  if (nulosImpares > muestra.length * 0.2) return { texto: new TextDecoder("utf-16le").decode(buf), codificacion: "utf-16le" };
  if (nulosPares > muestra.length * 0.2) return { texto: new TextDecoder("utf-16be").decode(buf), codificacion: "utf-16be" };

  try {
    return { texto: new TextDecoder("utf-8", { fatal: true }).decode(buf), codificacion: "utf-8" };
  } catch {
    try {
      return { texto: new TextDecoder("windows-1252").decode(buf), codificacion: "windows-1252" };
    } catch {
      return { texto: buf.toString("latin1"), codificacion: "latin1" };
    }
  }
}

function detectarDelimitador(texto: string): string {
  const muestra = texto.slice(0, 64 * 1024);
  const cuenta: Record<string, number> = { ";": 0, ",": 0, "\t": 0, "|": 0 };
  let comillas = false;
  let lineas = 0;
  for (let i = 0; i < muestra.length && lineas < 30; i++) {
    const c = muestra[i]!;
    if (c === '"') {
      if (comillas && muestra[i + 1] === '"') i++;
      else comillas = !comillas;
    } else if (!comillas) {
      if (c === "\n") lineas++;
      else if (c in cuenta) cuenta[c]!++;
    }
  }
  let mejor = ",";
  let max = 0;
  for (const [d, n] of Object.entries(cuenta)) {
    if (n > max) {
      max = n;
      mejor = d;
    }
  }
  return mejor;
}

interface CsvParseado {
  filas: string[][];
  delimitador: string;
  codificacion: string;
  truncado: boolean;
}

function parsearCsv(texto: string, maxFilas: number, maxColumnas: number): CsvParseado {
  const delimitador = detectarDelimitador(texto);
  const filas: string[][] = [];
  let fila: string[] = [];
  let campo = "";
  let comillas = false;
  let truncado = false;

  const cerrarCampo = () => {
    if (fila.length < maxColumnas) fila.push(campo);
    else truncado = true;
    campo = "";
  };
  const cerrarFila = () => {
    cerrarCampo();
    if (filas.length < maxFilas) filas.push(fila);
    else truncado = true;
    fila = [];
  };

  for (let i = 0; i < texto.length; i++) {
    const c = texto[i]!;
    if (comillas) {
      if (c === '"') {
        if (texto[i + 1] === '"') {
          campo += '"';
          i++;
        } else {
          comillas = false;
        }
      } else {
        campo += c;
      }
      continue;
    }
    if (c === '"' && campo.length === 0) {
      comillas = true;
    } else if (c === delimitador) {
      cerrarCampo();
    } else if (c === "\n") {
      cerrarFila();
    } else if (c === "\r") {
      if (texto[i + 1] === "\n") i++;
      cerrarFila();
    } else {
      campo += c;
    }
  }
  cerrarFila();
  // Quita una ultima fila totalmente vacia producida por el salto final.
  while (filas.length > 0 && filas[filas.length - 1]!.every((v) => v === "")) filas.pop();

  return { filas, delimitador, codificacion: "", truncado };
}

function inferirValorCsv(s: string): unknown {
  if (s === "") return null;
  const t = s.trim();
  if (t === "") return s;
  if (/^-?(0|[1-9]\d*)(\.\d+)?([eE][+-]?\d+)?$/.test(t)) {
    const n = Number(t);
    if (Number.isFinite(n)) return n;
  }
  if (/^(true|false)$/i.test(t)) return /^true$/i.test(t);
  return s;
}

async function cargarLibro(archivo: ArchivoEntrada): Promise<LibroCargado> {
  const avisos: string[] = [];

  if (archivo.extension === ".csv") {
    const buf = await readFile(archivo.rutaReal);
    const dec = decodificarCsv(buf);
    const csv = parsearCsv(dec.texto, MAX_FILAS_SEGURIDAD, MAX_COLUMNAS_SEGURIDAD);
    csv.codificacion = dec.codificacion;
    if (csv.truncado) {
      avisos.push(
        `El CSV supera el limite de ${MAX_FILAS_SEGURIDAD.toLocaleString("es-CL")} filas o ${MAX_COLUMNAS_SEGURIDAD} columnas; se leyo solo una parte.`,
      );
    }
    if (csv.filas.length === 0) throw new ErrorExcel("El CSV no contiene filas de datos.");
    const wb = new ExcelJS.Workbook();
    const ws = wb.addWorksheet("CSV");
    for (const f of csv.filas) ws.addRow(f.map(inferirValorCsv));
    avisos.push(
      `CSV leido como ${csv.codificacion}, delimitador ${JSON.stringify(csv.delimitador === "\t" ? "tabulador" : csv.delimitador)}.`,
    );
    return { ruta: archivo.ruta, extension: archivo.extension, workbook: wb, avisos };
  }

  const wb = new ExcelJS.Workbook();
  try {
    await wb.xlsx.readFile(archivo.rutaReal);
  } catch (e) {
    throw new ErrorExcel(
      `No pude abrir el libro: ${e instanceof Error ? e.message : String(e)}`,
      "Comprueba que no este abierto con cambios sin guardar, que no tenga contrasena y que sea un .xlsx/.xlsm real.",
    );
  }
  if (wb.worksheets.length === 0) throw new ErrorExcel("El libro no tiene hojas.");
  return { ruta: archivo.ruta, extension: archivo.extension, workbook: wb, avisos };
}

function elegirHoja(libro: LibroCargado, pedida?: string): ExcelJS.Worksheet {
  const hojas = libro.workbook.worksheets;
  if (!pedida || pedida.trim() === "") {
    return hojas.find((h) => h.state === "visible") ?? hojas[0]!;
  }
  const p = pedida.trim();
  if (/^\d+$/.test(p)) {
    const i = Number(p) - 1;
    if (i >= 0 && i < hojas.length) return hojas[i]!;
  }
  const buscada = p.toLocaleLowerCase("es");
  const encontrada = hojas.find((h) => h.name.toLocaleLowerCase("es") === buscada);
  if (!encontrada) {
    throw new ErrorExcel(
      `No existe la hoja "${pedida}". Hojas disponibles: ${hojas.map((h) => h.name).join(", ")}.`,
    );
  }
  return encontrada;
}

export async function listarHojas(archivo: ArchivoEntrada, incluirOcultas: boolean): Promise<{ hojas: HojaResumen[]; avisos: string[] }> {
  const libro = await cargarLibro(archivo);
  const hojas: HojaResumen[] = [];
  for (const [i, h] of libro.workbook.worksheets.entries()) {
    if (!incluirOcultas && h.state !== "visible") continue;
    const r = rangoDeDimensiones(h);
    hojas.push({
      nombre: h.name,
      indice: i + 1,
      estado: h.state,
      filas: r ? r.filaFin - r.filaInicio + 1 : 0,
      columnas: r ? r.colFin - r.colInicio + 1 : 0,
      rango: r ? rangoATexto(r) : null,
      tablas: tablasDe(h),
    });
  }
  return { hojas, avisos: libro.avisos };
}

function detectarFilaEncabezado(hoja: ExcelJS.Worksheet, r: RangoA1): number {
  const ultima = Math.min(r.filaFin, r.filaInicio + 19);
  for (let fila = r.filaInicio; fila <= ultima; fila++) {
    let noVacios = 0;
    let textos = 0;
    for (let col = r.colInicio; col <= r.colFin; col++) {
      const c = normalizarCelda(hoja.getCell(fila, col));
      if (c.tipo !== "vacio" && c.texto.trim() !== "") {
        noVacios++;
        if (c.tipo === "texto") textos++;
      }
    }
    if (noVacios >= 2 && textos >= Math.ceil(noVacios / 2)) {
      // La fila siguiente (o alguna de las siguientes) debe tener datos, salvo que el rango termine aqui.
      if (fila === r.filaFin) return fila;
      let siguiente = 0;
      for (let k = 1; k <= 3 && fila + k <= r.filaFin && siguiente === 0; k++) {
        for (let col = r.colInicio; col <= r.colFin; col++) {
          const c = normalizarCelda(hoja.getCell(fila + k, col));
          if (c.tipo !== "vacio" && c.texto.trim() !== "") siguiente++;
        }
      }
      if (siguiente > 0) return fila;
    }
  }
  return r.filaInicio;
}

function nombresDeColumnas(hoja: ExcelJS.Worksheet, fila: number, r: RangoA1): string[] {
  const vistos = new Map<string, number>();
  const nombres: string[] = [];
  for (let col = r.colInicio; col <= r.colFin; col++) {
    const letra = columnaALetra(col);
    const c = normalizarCelda(hoja.getCell(fila, col));
    let nombre = c.texto.trim();
    if (nombre === "") nombre = `Columna_${letra}`;
    const clave = nombre.toLocaleLowerCase("es");
    const n = (vistos.get(clave) ?? 0) + 1;
    vistos.set(clave, n);
    if (n > 1) nombre = `${nombre} (${n})`;
    nombres.push(nombre);
  }
  return nombres;
}

/**
 * Lee una hoja y devuelve encabezados + filas normalizadas.
 * Si no se indica rango y hay una tabla, usa la primera tabla de la hoja.
 */
export async function leerHoja(archivo: ArchivoEntrada, opciones: OpcionesLeer): Promise<HojaLeida> {
  const libro = await cargarLibro(archivo);
  const hoja = elegirHoja(libro, opciones.hoja);
  const avisos = [...libro.avisos];
  const tablas = tablasDe(hoja);

  let rango: RangoA1;
  let tablaUsada: string | null = null;
  if (opciones.rango) {
    rango = parsearRango(opciones.rango);
  } else if (tablas.length > 0) {
    const ordenadas = [...tablas].sort((a, b) => a.filaEncabezado - b.filaEncabezado);
    const t = ordenadas[0]!;
    rango = parsearRango(t.rango);
    tablaUsada = t.nombre;
    if (tablas.length > 1) {
      avisos.push(`La hoja tiene ${tablas.length} tablas; se uso "${t.nombre}". Indica "rango" para elegir otra zona.`);
    }
  } else {
    const dims = rangoDeDimensiones(hoja);
    if (!dims) {
      throw new ErrorExcel(`La hoja "${hoja.name}" esta vacia (no tiene celdas con datos).`);
    }
    rango = dims;
  }

  if (rango.filaFin < rango.filaInicio || rango.colFin < rango.colInicio) {
    throw new ErrorExcel("El rango indicado no contiene celdas.");
  }

  let filaEncabezado: number;
  if (opciones.filaEncabezado !== undefined) {
    filaEncabezado = opciones.filaEncabezado;
    if (filaEncabezado < rango.filaInicio || filaEncabezado > rango.filaFin) {
      throw new ErrorExcel(
        `La fila de encabezado ${filaEncabezado} queda fuera del rango ${rangoATexto(rango)}.`,
      );
    }
  } else if (tablaUsada) {
    filaEncabezado = rango.filaInicio;
  } else {
    filaEncabezado = detectarFilaEncabezado(hoja, rango);
    if (filaEncabezado !== rango.filaInicio) {
      avisos.push(`Encabezado detectado en la fila ${filaEncabezado} (las filas anteriores parecen titulos o estan vacias).`);
    }
  }

  const totalColumnasRango = rango.colFin - rango.colInicio + 1;
  const maxColumnas = Math.max(1, Math.min(MAX_COLUMNAS_SEGURIDAD, opciones.maxColumnas));
  const colFin = Math.min(rango.colFin, rango.colInicio + maxColumnas - 1);
  const truncadoColumnas = colFin < rango.colFin;
  if (truncadoColumnas) {
    avisos.push(`El rango tiene ${totalColumnasRango} columnas; se leyeron las primeras ${maxColumnas}.`);
  }

  const rangoColumnas: RangoA1 = { ...rango, colFin };
  const nombres = nombresDeColumnas(hoja, filaEncabezado, rangoColumnas);
  const columnas: ColumnaLeida[] = nombres.map((nombre, i) => ({
    indice: i + 1,
    letra: columnaALetra(rango.colInicio + i),
    nombre,
  }));

  const totalFilas = Math.max(0, rango.filaFin - filaEncabezado);
  let maxFilas = Math.max(1, Math.min(MAX_FILAS_SEGURIDAD, opciones.maxFilas));
  const maxCeldas = Math.max(10_000, Number(process.env.EXCEL_MAX_CELDAS) || 5_000_000);
  if (maxFilas * columnas.length > maxCeldas) {
    const antes = maxFilas;
    maxFilas = Math.max(1, Math.floor(maxCeldas / columnas.length));
    avisos.push(
      `Se redujo la lectura de ${antes.toLocaleString("es-CL")} a ${maxFilas.toLocaleString("es-CL")} filas por el limite de ${maxCeldas.toLocaleString("es-CL")} celdas (EXCEL_MAX_CELDAS). Acota con "rango" si necesitas otra zona.`,
    );
  }
  const truncadoFilas = totalFilas > maxFilas;
  if (truncadoFilas) {
    avisos.push(
      `La tabla tiene ${totalFilas.toLocaleString("es-CL")} filas de datos; se leyeron las primeras ${maxFilas.toLocaleString("es-CL")}.`,
    );
  }
  maxFilas = Math.min(maxFilas, totalFilas);

  const filas: FilaLeida[] = [];
  let filasVacias = 0;
  let formulaSinResultado = 0;

  for (let i = 0; i < maxFilas; i++) {
    const numero = filaEncabezado + 1 + i;
    const celdas: CeldaNormalizada[] = [];
    let vacia = true;
    for (let j = 0; j < columnas.length; j++) {
      const c = normalizarCelda(hoja.getCell(numero, rango.colInicio + j));
      if (c.tipo !== "vacio") vacia = false;
      if (c.formulaSinResultado) formulaSinResultado++;
      celdas.push(c);
    }
    if (vacia) filasVacias++;
    filas.push({ numero, celdas });
  }

  if (formulaSinResultado > 0) {
    avisos.push(
      `Hay ${formulaSinResultado} celdas con formula sin resultado cacheado. ExcelJS no calcula formulas: abre y guarda el libro en Excel (o usa la herramienta visual de recalculo) para que tengan valor.`,
    );
  }
  if (filasVacias > 0) avisos.push(`Hay ${filasVacias} filas totalmente vacias dentro del rango.`);

  return {
    archivo: archivo.ruta,
    hoja: hoja.name,
    filaEncabezado,
    rango: rangoATexto({ ...rango, colFin }),
    columnas,
    filas,
    filasTotalesDatos: totalFilas,
    columnasTotales: totalColumnasRango,
    truncadoFilas,
    truncadoColumnas,
    filasVacias,
    formulaSinResultado,
    tablas,
    tablaUsada,
    avisos,
  };
}

/** Resuelve una columna por nombre, letra o indice 1-based. */
export function resolverColumna(hoja: HojaLeida, pedida: string): ColumnaLeida {
  const p = pedida.trim();
  if (p === "") throw new ErrorExcel("Indica el nombre, la letra o el numero de la columna.");

  const porNombre = hoja.columnas.find((c) => c.nombre.toLocaleLowerCase("es") === p.toLocaleLowerCase("es"));
  if (porNombre) return porNombre;

  if (/^[A-Za-z]{1,3}$/.test(p)) {
    const letra = p.toUpperCase();
    const c = hoja.columnas.find((col) => col.letra === letra);
    if (c) return c;
  }
  if (/^\d+$/.test(p)) {
    const c = hoja.columnas[Number(p) - 1];
    if (c) return c;
  }

  // Coincidencia por nombre normalizado (sin acentos ni mayusculas) como ultimo recurso.
  const norm = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("es").trim();
  const aproximada = hoja.columnas.find((c) => norm(c.nombre) === norm(p));
  if (aproximada) return aproximada;

  throw new ErrorExcel(
    `No encuentro la columna "${pedida}". Columnas disponibles: ${hoja.columnas.map((c) => `${c.nombre} (${c.letra})`).join(", ")}.`,
  );
}

export function valorDeFila(fila: FilaLeida, columna: ColumnaLeida): CeldaNormalizada {
  return fila.celdas[columna.indice - 1] ?? {
    tipo: "vacio",
    valor: null,
    texto: "",
    formula: null,
    formulaSinResultado: false,
    formato: null,
  };
}

/** Para mensajes y pruebas: nombre visible del archivo. */
export function nombreArchivo(ruta: string): string {
  return path.basename(ruta);
}
