/**
 * Herramientas visuales de ALTO NIVEL para Excel.
 *
 * Son secuencias cortas y seguras sobre el nucleo visual (capturar -> accion -> verificar).
 * Solo se usan cuando la via de archivos no alcanza: abrir un libro para que Excel
 * recalcule formulas, o guardar el resultado del recalculo.
 *
 * No se debilita ninguna proteccion de ../lib/visual/nucleo.ts: el freno PARAR.txt,
 * el limite de acciones, la validacion de coordenadas y las combinaciones bloqueadas
 * siguen activos (por eso aqui se usa F9 y no Ctrl+Alt+F9, que esta bloqueado).
 */
import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import { error } from "../lib/respuestas.js";
import { validarArchivoEntrada } from "../lib/excel/rutas.js";
import { ErrorVisual, capturar, esperar, escribir, tecla } from "../lib/visual/nucleo.js";

function imagen(r: Awaited<ReturnType<typeof capturar>>, resumen: string) {
  return {
    content: [
      { type: "image" as const, data: r.png.toString("base64"), mimeType: "image/png" },
      { type: "text" as const, text: `${resumen}\n${JSON.stringify(r.meta)}` },
    ],
  };
}

export function register(server: McpServer): void {
  server.registerTool(
    "excel_visual_abrir_archivo",
    {
      title: "Abrir un libro en Excel (visual)",
      description:
        "Abre un archivo .xlsx/.xlsm/.csv en la ventana de Excel usando Ctrl+O y escribiendo la ruta, sin clics por coordenadas. Usala cuando necesites que Excel abra y calcule el libro (por ejemplo para generar resultados cacheados de formulas) o cuando la persona quiera verlo en pantalla. Verifica con una captura al final. No guarda nada por si sola.",
      inputSchema: {
        archivo: z
          .string()
          .min(1)
          .max(4096)
          .describe("Ruta local del archivo a abrir. Debe existir. Ejemplo: C:\\datos\\ventas.xlsx"),
        espera_ms: z
          .number()
          .int()
          .min(300)
          .max(10_000)
          .default(2000)
          .describe("Milisegundos a esperar despues de Enter antes de capturar (libros grandes tardan mas)."),
      },
      annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
    },
    async ({ archivo, espera_ms }) => {
      try {
        const a = await validarArchivoEntrada(archivo);
        await capturar({ frente: true });
        await tecla("ctrl+o");
        await esperar(700);
        await escribir(a.ruta);
        await esperar(250);
        await tecla("enter");
        await esperar(espera_ms);
        const r = await capturar({ frente: false });
        return imagen(
          r,
          `Envie Ctrl+O y la ruta "${a.ruta}". Revisa la captura: si ves un aviso de Excel (por ejemplo sobre formulas o formato), resuelvelo con visual_clic o visual_tecla.`,
        );
      } catch (e) {
        const msg = e instanceof ErrorVisual || e instanceof Error ? e.message : String(e);
        return error(`No se pudo abrir el archivo de forma visual: ${msg}`);
      }
    },
  );

  server.registerTool(
    "excel_visual_recalcular_guardar",
    {
      title: "Recalcular y guardar el libro abierto (visual)",
      description:
        "Envia F9 (recalcular) y Ctrl+S (guardar) a la ventana de Excel y devuelve una captura de verificacion. Sirve para que las formulas tengan resultado cacheado y las herramientas de archivo puedan leerlas. Es una accion que ESCRIBE en el libro abierto: exige confirmar=true. Si Excel muestra un dialogo (por ejemplo 'mantener formato' en CSV), resolvelo con visual_clic o visual_tecla y vuelve a capturar.",
      inputSchema: {
        confirmar: z
          .literal(true)
          .describe("Obligatorio true: confirma que se guardara el libro que este abierto en Excel."),
        espera_ms: z
          .number()
          .int()
          .min(300)
          .max(10_000)
          .default(1200)
          .describe("Milisegundos a esperar despues de F9 y antes de Ctrl+S."),
      },
      annotations: { readOnlyHint: false, destructiveHint: true, openWorldHint: false },
    },
    async ({ confirmar, espera_ms }) => {
      if (confirmar !== true) {
        return error("Para recalcular y guardar debes enviar confirmar=true.");
      }
      try {
        await capturar({ frente: true });
        await tecla("f9");
        await esperar(espera_ms);
        await tecla("ctrl+s");
        await esperar(900);
        const r = await capturar({ frente: false });
        return imagen(
          r,
          "Envie F9 y Ctrl+S. Comprueba en la captura que no quedo un dialogo pendiente; si lo hay, resuelvelo antes de leer el archivo con excel_leer_tabla.",
        );
      } catch (e) {
        const msg = e instanceof ErrorVisual || e instanceof Error ? e.message : String(e);
        return error(`No se pudo recalcular/guardar de forma visual: ${msg}`);
      }
    },
  );

  server.registerTool(
    "excel_visual_ir_a_celda",
    {
      title: "Ir a una celda o rango (visual)",
      description:
        "Usa Ctrl+G (Ir a) para seleccionar una celda o rango por direccion A1, sin calcular coordenadas. Util para dejar visible una zona concreta antes de una captura o para revisar el resultado de una limpieza. No modifica datos.",
      inputSchema: {
        referencia: z
          .string()
          .min(1)
          .max(20)
          .regex(/^[A-Za-z]{1,3}[1-9]\d{0,6}(:[A-Za-z]{1,3}[1-9]\d{0,6})?$/, "Usa una direccion A1 valida, por ejemplo C10 o A1:F200.")
          .describe("Celda o rango A1 al que ir. Ejemplo: B2 o A1:F200"),
      },
      annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
    },
    async ({ referencia }) => {
      try {
        const destino = referencia.toUpperCase();
        await capturar({ frente: true });
        await tecla("ctrl+g");
        await esperar(500);
        await escribir(destino);
        await esperar(150);
        await tecla("enter");
        await esperar(600);
        const r = await capturar({ frente: false });
        return imagen(r, `Seleccione "${destino}" con Ctrl+G. Revisa la captura para confirmar que el rango visible es el esperado.`);
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        return error(`No se pudo ir a la celda de forma visual: ${msg}`);
      }
    },
  );
}
