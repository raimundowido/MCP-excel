/**
 * Herramientas principales del MCP de Excel.
 *
 * Motor: lectura/escritura de archivos con ExcelJS + estadistica y limpieza propias.
 * No se abre Excel ni se ejecutan macros. Las herramientas visuales viven en excel-visual.ts.
 */
import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import path from "node:path";
import { z } from "zod";
import { error, json } from "../lib/respuestas.js";
import { estadoExcel, estadoPlugins } from "../lib/excel/estado.js";
import { ErrorExcel, mensajeError } from "../lib/excel/errores.js";
import {
  OPERADORES,
  filtrarFilas,
  filaComoObjeto,
  limpiarFilas,
  matrizSalida,
  resolverCondiciones,
  type Condicion,
} from "../lib/excel/filtros.js";
import { calcularEstadisticas } from "../lib/excel/estadisticas.js";
import { leerHoja, listarHojas, resolverColumna, type HojaLeida } from "../lib/excel/libro.js";
import { perfilarColumna } from "../lib/excel/perfil.js";
import { mismaRuta, validarArchivoEntrada, validarArchivoSalida } from "../lib/excel/rutas.js";
import { escribirTabla } from "../lib/excel/salida.js";
import { aNumero } from "../lib/excel/valor.js";

const ARCHIVO = z
  .string()
  .min(1)
  .max(4096)
  .describe("Ruta local del archivo .xlsx, .xlsm o .csv. Ejemplo: C:\\datos\\ventas.xlsx");

const HOJA = z
  .string()
  .max(200)
  .optional()
  .describe("Nombre de la hoja o su numero (1 = primera). Si se omite, se usa la primera hoja visible.");

const RANGO = z
  .string()
  .min(1)
  .max(40)
  .optional()
  .describe("Rango A1 opcional, por ejemplo A1:F200. Si se omite y hay una tabla, se usa la tabla.");

const FILA_ENCABEZADO = z
  .number()
  .int()
  .min(1)
  .max(1_048_576)
  .optional()
  .describe("Fila que contiene los nombres de columna. Si se omite, se detecta automaticamente.");

const CONDICION = z.object({
  columna: z
    .string()
    .min(1)
    .max(200)
    .describe("Columna por nombre, letra (C) o numero (3). Ejemplo: Ciudad, C, 3"),
  operador: z.enum(OPERADORES).describe(
    "Operacion. Texto: texto_contiene, texto_no_contiene, texto_igual, texto_distinto, texto_empieza_con, texto_termina_con, texto_en_lista, texto_no_en_lista. Vacio: vacio, no_vacio. Numero: numero_igual, numero_distinto, numero_mayor, numero_mayor_igual, numero_menor, numero_menor_igual, numero_entre, numero_en_lista.",
  ),
  valor: z
    .union([z.string(), z.number()])
    .optional()
    .describe("Valor de comparacion para operadores de texto o numero. Ejemplo: 'San Jose' o 1000."),
  valor2: z
    .union([z.string(), z.number()])
    .optional()
    .describe("Segundo valor, solo para numero_entre (limite superior inclusive)."),
  valores: z
    .array(z.union([z.string(), z.number()]))
    .min(1)
    .max(100)
    .optional()
    .describe("Lista de valores para texto_en_lista, texto_no_en_lista o numero_en_lista."),
  ignorar_mayusculas: z.boolean().default(true).describe("Para texto: comparar sin distinguir mayusculas (por defecto true)."),
  ignorar_acentos: z.boolean().default(true).describe("Para texto: comparar sin tildes (por defecto true)."),
});

async function conManejo(fn: () => Promise<unknown>) {
  try {
    return json(await fn());
  } catch (e) {
    return error(mensajeError(e));
  }
}

function resumenColumnas(hoja: HojaLeida) {
  return hoja.columnas.map((c) => {
    const celdas = hoja.filas.flatMap((f) => {
      const celda = f.celdas[c.indice - 1];
      return celda ? [celda] : [];
    });
    const tipos: Record<string, number> = {};
    let noVacios = 0;
    const ejemplos: string[] = [];
    for (const celda of celdas) {
      tipos[celda.tipo] = (tipos[celda.tipo] ?? 0) + 1;
      if (celda.tipo !== "vacio" && celda.texto.trim() !== "") {
        noVacios++;
        if (ejemplos.length < 3 && !ejemplos.includes(celda.texto)) ejemplos.push(celda.texto);
      }
    }
    return {
      ...c,
      noVacios,
      vacios: celdas.length - noVacios,
      tipos,
      ejemplos,
    };
  });
}

function prefijoComun(hoja: HojaLeida) {
  return {
    archivo: hoja.archivo,
    hoja: hoja.hoja,
    filaEncabezado: hoja.filaEncabezado,
    rango: hoja.rango,
    tablas: hoja.tablas,
    avisos: hoja.avisos,
  };
}

export function register(server: McpServer): void {
  server.registerTool(
    "excel_estado",
    {
      title: "Estado de Excel y del motor de archivos",
      description:
        "Diagnostico de solo lectura: comprueba si Excel esta instalado, su version, si hay una instancia abierta, que formatos puede leer este MCP y que permisos/carpetas estan configurados. Llamala primero si una herramienta de archivo falla o si necesitas saber si Excel esta disponible.",
      inputSchema: {},
      annotations: { readOnlyHint: true },
    },
    async () => conManejo(() => estadoExcel()),
  );

  server.registerTool(
    "excel_listar_hojas",
    {
      title: "Listar hojas y tablas de un libro",
      description:
        "Lee la estructura de un archivo .xlsx/.xlsm/.csv sin modificarlo: nombres de hojas, filas, columnas, rango usado y tablas definidas. Usala antes de excel_leer_tabla para elegir la hoja correcta, o para saber si el libro contiene tablas con nombre.",
      inputSchema: {
        archivo: ARCHIVO,
        incluir_ocultas: z.boolean().default(false).describe("Si es true, incluye hojas ocultas o muy ocultas."),
      },
      annotations: { readOnlyHint: true },
    },
    async ({ archivo, incluir_ocultas }) =>
      conManejo(async () => {
        const a = await validarArchivoEntrada(archivo);
        const r = await listarHojas(a, incluir_ocultas);
        return {
          archivo: a.ruta,
          nombre: a.nombre,
          extension: a.extension,
          tamanoMB: Math.round(a.tamanoMB * 100) / 100,
          hojas: r.hojas,
          avisos: r.avisos,
        };
      }),
  );

  server.registerTool(
    "excel_leer_tabla",
    {
      title: "Leer una tabla de Excel",
      description:
        "Lee una hoja o tabla y devuelve encabezados, tipos de dato y filas como objetos. Usala para inspeccionar datos antes de analizarlos o limpiarlos. Devuelve solo una muestra (max_filas); usa excel_estadisticas_columna o excel_filtrar_filas para trabajar con toda la tabla. Los valores de formulas son los cacheados por Excel (ExcelJS no calcula).",
      inputSchema: {
        archivo: ARCHIVO,
        hoja: HOJA,
        rango: RANGO,
        fila_encabezado: FILA_ENCABEZADO,
        max_filas: z.number().int().min(1).max(10_000).default(100).describe("Maximo de filas de datos a devolver (1 a 10000)."),
        max_columnas: z.number().int().min(1).max(500).default(50).describe("Maximo de columnas a devolver (1 a 500)."),
        incluir_filas_vacias: z.boolean().default(false).describe("Si es true, incluye filas totalmente vacias en la muestra."),
        incluir_formulas: z.boolean().default(true).describe("Si es true, agrega una lista de celdas con formula y su resultado cacheado."),
      },
      annotations: { readOnlyHint: true },
    },
    async ({ archivo, hoja, rango, fila_encabezado, max_filas, max_columnas, incluir_filas_vacias, incluir_formulas }) =>
      conManejo(async () => {
        const a = await validarArchivoEntrada(archivo);
        const h = await leerHoja(a, {
          hoja,
          rango,
          filaEncabezado: fila_encabezado,
          maxFilas: max_filas,
          maxColumnas: max_columnas,
        });
        const visibles = incluir_filas_vacias
          ? h.filas
          : h.filas.filter((f) => f.celdas.some((c) => c.tipo !== "vacio" || c.formulaSinResultado));
        const formulas = incluir_formulas
          ? h.filas
              .flatMap((f) =>
                f.celdas
                  .map((c, i) => ({ c, i }))
                  .filter(({ c }) => c.formula)
                  .map(({ c, i }) => ({
                    celda: `${h.columnas[i]?.letra ?? "?"}${f.numero}`,
                    columna: h.columnas[i]?.nombre ?? null,
                    formula: c.formula,
                    resultado: c.formulaSinResultado ? null : c.valor,
                    sinResultado: c.formulaSinResultado,
                  })),
              )
              .slice(0, 50)
          : [];
        const totalFormulas = h.filas.reduce((n, f) => n + f.celdas.filter((c) => c.formula).length, 0);
        return {
          ...prefijoComun(h),
          nombre: a.nombre,
          columnas: resumenColumnas(h),
          filasTotalesDatos: h.filasTotalesDatos,
          filasDevueltas: visibles.length,
          truncado: h.truncadoFilas || h.truncadoColumnas,
          filasVaciasOmitidas: incluir_filas_vacias ? 0 : h.filas.filter((f) => f.celdas.every((c) => c.tipo === "vacio")).length,
          formulas: {
            total: totalFormulas,
            mostradas: formulas.length,
            celdas: formulas,
            nota: "El resultado es el valor cacheado en el archivo. Si esta vacio, abre y guarda el libro en Excel o usa excel_visual_recalcular_guardar.",
          },
          filas: visibles.map((f) => filaComoObjeto(h, f)),
        };
      }),
  );

  server.registerTool(
    "excel_estadisticas_columna",
    {
      title: "Estadisticas descriptivas de una columna",
      description:
        "Calcula estadisticas descriptivas de una columna numerica: n, suma, media, mediana, moda, minimo, maximo, rango, varianza, desviacion estandar, cuartiles, IQR, atipicos, asimetria, curtosis e intervalo de confianza de la media. Acepta numeros guardados como texto ('1.234,50', '$ 1.200', '15%'). Usala para responder preguntas como 'promedio de ventas' o 'dispersion de edades'.",
      inputSchema: {
        archivo: ARCHIVO,
        columna: z.string().min(1).max(200).describe("Columna por nombre, letra (C) o numero (3). Ejemplo: Monto, D, 4"),
        hoja: HOJA,
        rango: RANGO,
        fila_encabezado: FILA_ENCABEZADO,
        max_atipicos: z.number().int().min(0).max(100).default(20).describe("Cuantos valores atipicos listar (0 = no listar)."),
        incluir_interpretacion: z.boolean().default(true).describe("Agrega una frase corta que resume los resultados."),
      },
      annotations: { readOnlyHint: true },
    },
    async ({ archivo, columna, hoja, rango, fila_encabezado, max_atipicos, incluir_interpretacion }) =>
      conManejo(async () => {
        const a = await validarArchivoEntrada(archivo);
        const h = await leerHoja(a, { hoja, rango, filaEncabezado: fila_encabezado, maxFilas: 200_000, maxColumnas: 100 });
        const col = resolverColumna(h, columna);
        let vacios = 0;
        let noNumericos = 0;
        let errores = 0;
        let textoNumerico = 0;
        let fechas = 0;
        let formulasSinResultado = 0;
        const numeros: number[] = [];

        for (const fila of h.filas) {
          const c = fila.celdas[col.indice - 1]!;
          if (c.formulaSinResultado) formulasSinResultado++;
          if (c.tipo === "vacio" || (c.tipo !== "error" && c.texto.trim() === "")) {
            vacios++;
            continue;
          }
          if (c.tipo === "error") {
            errores++;
            continue;
          }
          if (c.tipo === "fecha") {
            fechas++;
            continue;
          }
          const n = aNumero(c.valor);
          if (n === null) {
            noNumericos++;
            continue;
          }
          if (c.tipo === "texto") textoNumerico++;
          numeros.push(n);
        }

        if (numeros.length === 0) {
          throw new ErrorExcel(
            `La columna "${col.nombre}" no tiene valores numericos utilizables (${vacios} vacios, ${noNumericos} no numericos, ${errores} errores, ${fechas} fechas).`,
            "Elige una columna con numeros o revisa el perfil con excel_perfilar_columna para ver que formatos contiene.",
          );
        }

        const estadisticas = calcularEstadisticas(numeros, max_atipicos);
        const avisos: string[] = [...h.avisos];
        if (vacios > 0) avisos.push(`${vacios} celdas vacias no entraron en el calculo.`);
        if (noNumericos > 0) avisos.push(`${noNumericos} valores no numericos se omitieron. Revisa excel_perfilar_columna.`);
        if (textoNumerico > 0) avisos.push(`${textoNumerico} numeros estaban guardados como texto y se convirtieron para el calculo.`);
        if (errores > 0) avisos.push(`${errores} celdas con error de Excel se omitieron.`);
        if (fechas > 0) avisos.push(`${fechas} fechas se omitieron: no mezcles fechas con la estadistica numerica.`);
        if (formulasSinResultado > 0) avisos.push(`${formulasSinResultado} formulas sin resultado cacheado se leyeron como vacias.`);
        if (numeros.length < 3) avisos.push("Con menos de 3 valores, la desviacion, la asimetria y la curtosis son poco fiables.");

        const interpretacion =
          `La columna "${col.nombre}" tiene ${numeros.length} valores numericos. ` +
          `Media ${estadisticas.media}, mediana ${estadisticas.mediana}, minimo ${estadisticas.minimo} y maximo ${estadisticas.maximo}. ` +
          `Desviacion estandar muestral ${estadisticas.desviacionEstandarMuestral}; ` +
          (estadisticas.atipicos.length > 0
            ? `${estadisticas.atipicos.length} valores atipicos con la regla 1,5 x IQR.`
            : "no se detectaron atipicos con la regla 1,5 x IQR.");

        return {
          ...prefijoComun(h),
          nombre: a.nombre,
          columna: { nombre: col.nombre, letra: col.letra, indice: col.indice },
          totalFilas: h.filas.length,
          vacios,
          noNumericos,
          errores,
          fechas,
          textoNumerico,
          formulasSinResultado,
          estadisticas,
          interpretacion: incluir_interpretacion ? interpretacion : null,
          avisos,
        };
      }),
  );

  server.registerTool(
    "excel_perfilar_columna",
    {
      title: "Perfilar la calidad de una columna",
      description:
        "Analiza una columna sin modificarla: tipos de dato, vacios, valores unicos y repetidos, top valores, numeros guardados como texto, espacios o caracteres invisibles, mayusculas/minusculas mezcladas, correos/URLs/telefonos y grupos de valores casi duplicados. Usala antes de limpiar una base de datos para decidir que corregir.",
      inputSchema: {
        archivo: ARCHIVO,
        columna: z.string().min(1).max(200).describe("Columna por nombre, letra (C) o numero (3)."),
        hoja: HOJA,
        rango: RANGO,
        fila_encabezado: FILA_ENCABEZADO,
        max_ejemplos: z.number().int().min(1).max(50).default(10).describe("Cuantos valores frecuentes mostrar (1 a 50)."),
      },
      annotations: { readOnlyHint: true },
    },
    async ({ archivo, columna, hoja, rango, fila_encabezado, max_ejemplos }) =>
      conManejo(async () => {
        const a = await validarArchivoEntrada(archivo);
        const h = await leerHoja(a, { hoja, rango, filaEncabezado: fila_encabezado, maxFilas: 200_000, maxColumnas: 100 });
        const col = resolverColumna(h, columna);
        return {
          ...prefijoComun(h),
          nombre: a.nombre,
          perfil: perfilarColumna(h, col, max_ejemplos),
        };
      }),
  );

  server.registerTool(
    "excel_filtrar_filas",
    {
      title: "Filtrar filas por texto o numero",
      description:
        "Previsualiza que filas cumplen una o varias condiciones de texto o numero, sin modificar el archivo. Devuelve el conteo, las primeras coincidencias y ejemplos excluidos. Usala para validar un criterio de limpieza antes de ejecutar excel_limpiar_datos. El texto se compara sin mayusculas ni acentos por defecto.",
      inputSchema: {
        archivo: ARCHIVO,
        condiciones: z.array(CONDICION).min(1).max(8).describe("Una a ocho condiciones. Se combinan con 'todas' (AND) o 'alguna' (OR)."),
        modo: z.enum(["todas", "alguna"]).default("todas").describe("'todas' = AND; 'alguna' = OR."),
        hoja: HOJA,
        rango: RANGO,
        fila_encabezado: FILA_ENCABEZADO,
        max_filas: z.number().int().min(1).max(500).default(50).describe("Maximo de filas coincidentes a devolver (1 a 500)."),
        incluir_columnas: z
          .array(z.string().min(1).max(200))
          .min(1)
          .max(50)
          .optional()
          .describe("Columnas a mostrar en la vista previa. Si se omite, se muestran todas."),
        incluir_ejemplos_excluidos: z.boolean().default(true).describe("Si es true, devuelve hasta 5 filas que NO cumplen las condiciones."),
      },
      annotations: { readOnlyHint: true },
    },
    async ({ archivo, condiciones, modo, hoja, rango, fila_encabezado, max_filas, incluir_columnas, incluir_ejemplos_excluidos }) =>
      conManejo(async () => {
        const a = await validarArchivoEntrada(archivo);
        const h = await leerHoja(a, { hoja, rango, filaEncabezado: fila_encabezado, maxFilas: 200_000, maxColumnas: 100 });
        const resueltas = resolverCondiciones(h, condiciones as Condicion[]);
        const r = filtrarFilas(h, resueltas, modo, max_filas);
        const columnasPedidas = incluir_columnas && incluir_columnas.length > 0
          ? [...new Map(incluir_columnas.map((n) => {
              const c = resolverColumna(h, n);
              return [c.indice, c] as const;
            })).values()]
          : h.columnas;
        const objeto = (fila: (typeof h.filas)[number]) => {
          const o: Record<string, string | number | boolean | null> = { _fila: fila.numero };
          for (const c of columnasPedidas) {
            const celda = fila.celdas[c.indice - 1];
            o[c.nombre] = celda && celda.tipo !== "vacio" && !celda.formulaSinResultado
              ? (celda.valor as string | number | boolean)
              : null;
          }
          return o;
        };
        const totalCoincidentes = h.filas.length - r.noCoincidentes;
        return {
          ...prefijoComun(h),
          nombre: a.nombre,
          condiciones: resueltas.map((c) => ({ columna: c.columna.nombre, descripcion: c.descripcion })),
          modo,
          totalFilas: h.filas.length,
          filasCoincidentes: totalCoincidentes,
          filasNoCoincidentes: r.noCoincidentes,
          filasVaciasCoincidentes: r.vaciasCoincidentes,
          truncado: totalCoincidentes > r.coincidentes.length,
          columnas: columnasPedidas.map((c) => c.nombre),
          filas: r.coincidentes.map(objeto),
          ejemplosExcluidos: incluir_ejemplos_excluidos ? r.ejemplosExcluidos.map(objeto) : [],
          avisos: h.avisos,
        };
      }),
  );

  server.registerTool(
    "excel_limpiar_datos",
    {
      title: "Limpiar y exportar una tabla",
      description:
        "Filtra, quita duplicados, descarta filas vacias y normaliza espacios, y escribe el resultado en un .xlsx o .csv NUEVO. Por defecto solo simula (simular=true) y muestra una vista previa; para escribir de verdad usa simular=false y confirmar=true. Nunca sobrescribe el archivo de entrada. No conserva formulas ni estilos: exporta valores.",
      inputSchema: {
        archivo: ARCHIVO,
        salida: z
          .string()
          .max(4096)
          .optional()
          .describe("Ruta de salida .xlsx o .csv. Si se omite: <nombre>_limpio.xlsx junto al original."),
        condiciones: z.array(CONDICION).max(8).default([]).describe("Condiciones de filtro; vacio = no filtrar."),
        modo: z.enum(["todas", "alguna"]).default("todas").describe("'todas' = AND; 'alguna' = OR."),
        conservar_coincidentes: z
          .boolean()
          .default(true)
          .describe("true = conservar las filas que cumplen; false = eliminarlas y conservar el resto."),
        quitar_duplicados: z.boolean().default(false).describe("Elimina filas duplicadas; conserva la primera."),
        columnas_clave: z
          .array(z.string().min(1).max(200))
          .max(20)
          .optional()
          .describe("Columnas para decidir duplicados. Si se omite, se comparan todas las columnas."),
        recortar_espacios: z.boolean().default(true).describe("Quita espacios al inicio y al final de los textos."),
        colapsar_espacios: z.boolean().default(false).describe("Convierte espacios y saltos repetidos en un solo espacio."),
        descartar_filas_vacias: z.boolean().default(true).describe("Elimina filas sin ningun dato."),
        descartar_si_vacio_en: z
          .array(z.string().min(1).max(200))
          .max(20)
          .optional()
          .describe("Elimina filas que tengan vacia alguna de estas columnas (por ejemplo un ID obligatorio)."),
        formato: z.enum(["xlsx", "csv"]).optional().describe("Formato de salida. Si se omite, se deduce de la extension de 'salida' (o xlsx)."),
        delimitador_csv: z.enum([",", ";"]).default(",").describe("Delimitador para CSV. Usa ';' si Excel en espanol abre todo en una columna."),
        bom: z.boolean().default(true).describe("Agrega BOM UTF-8 al CSV para que Excel muestre bien los acentos."),
        simular: z.boolean().default(true).describe("true = no escribe nada, solo muestra el resultado. false = escribe el archivo."),
        sobrescribir: z.boolean().default(false).describe("Permite reemplazar un archivo de salida existente (requiere confirmar=true)."),
        confirmar: z
          .literal(true)
          .optional()
          .describe("Obligatorio true cuando simular=false. Confirma que se escribira un archivo nuevo."),
        max_filas_preview: z.number().int().min(0).max(200).default(20).describe("Filas de vista previa a devolver (0 a 200)."),
        hoja: HOJA,
        rango: RANGO,
        fila_encabezado: FILA_ENCABEZADO,
      },
      annotations: { readOnlyHint: false, destructiveHint: true, openWorldHint: false },
    },
    async (args) =>
      conManejo(async () => {
        const a = await validarArchivoEntrada(args.archivo);
        const h = await leerHoja(a, {
          hoja: args.hoja,
          rango: args.rango,
          filaEncabezado: args.fila_encabezado,
          maxFilas: 200_000,
          maxColumnas: 100,
        });
        const claves = (args.columnas_clave ?? []).map((n) => resolverColumna(h, n));
        const vacios = (args.descartar_si_vacio_en ?? []).map((n) => resolverColumna(h, n));
        const resueltas = resolverCondiciones(h, args.condiciones as Condicion[]);
        const resultado = limpiarFilas(h, {
          condiciones: resueltas,
          modo: args.modo,
          conservarCoincidentes: args.conservar_coincidentes,
          descartarVacias: args.descartar_filas_vacias,
          descartarSiVacioEn: vacios,
          recortarEspacios: args.recortar_espacios,
          colapsarEspacios: args.colapsar_espacios,
          quitarDuplicados: args.quitar_duplicados,
          columnasClave: claves,
        });

        let formato = args.formato;
        if (args.salida) {
          const ext = path.extname(args.salida).toLowerCase();
          if (formato && ((formato === "xlsx" && ext !== ".xlsx") || (formato === "csv" && ext !== ".csv"))) {
            throw new ErrorExcel(
              `El formato "${formato}" no coincide con la extension de la salida "${ext}".`,
              "Cambia la extension de 'salida' o el parametro 'formato' para que coincidan.",
            );
          }
          formato = formato ?? (ext === ".csv" ? "csv" : "xlsx");
        }
        formato = formato ?? "xlsx";

        const salidaTexto = args.salida
          ? args.salida
          : path.join(path.dirname(a.ruta), `${path.basename(a.ruta, path.extname(a.ruta))}_limpio.${formato}`);
        const destino = await validarArchivoSalida(salidaTexto);

        if (destino.extension.slice(1) !== formato) {
          throw new ErrorExcel(`La salida "${destino.ruta}" no coincide con el formato ${formato}.`);
        }
        if (mismaRuta(a.ruta, destino.ruta) || (destino.rutaReal !== null && mismaRuta(a.rutaReal, destino.rutaReal))) {
          throw new ErrorExcel(
            "La salida no puede ser el mismo archivo de entrada.",
            "Elige otro nombre (por ejemplo ventas_limpio.xlsx). Asi no se pierden formulas, estilos ni el original.",
          );
        }
        if (!args.simular) {
          if (args.confirmar !== true) {
            throw new ErrorExcel(
              "Para escribir el archivo debes enviar simular=false y confirmar=true.",
              "Primero prueba con simular=true (por defecto), revisa la vista previa y luego confirma.",
            );
          }
          if (destino.existe && !args.sobrescribir) {
            throw new ErrorExcel(
              `Ya existe el archivo de salida: ${destino.ruta}`,
              "Elige otro nombre o envia sobrescribir=true junto con confirmar=true.",
            );
          }
          if (resultado.filas.length === 0) {
            throw new ErrorExcel(
              "La limpieza no dejo ninguna fila; no se escribio el archivo.",
              "Relaja las condiciones o desactiva descartar_filas_vacias/quitar_duplicados y vuelve a simular.",
            );
          }
        }

        const vistaPrevia = resultado.filas.slice(0, args.max_filas_preview).map((f) => filaComoObjeto(h, f));
        const base = {
          ...prefijoComun(h),
          nombre: a.nombre,
          formatosSalida: ["xlsx", "csv"],
          columnas: h.columnas.map((c) => c.nombre),
          reporte: resultado.reporte,
          vistaPrevia,
          salidaPrevista: destino.ruta,
          salidaExiste: destino.existe,
          avisos: [...h.avisos, ...resultado.avisos],
        };

        if (args.simular) {
          return {
            ...base,
            simulado: true,
            escrito: false,
            nota: "No se escribio ningun archivo. Para escribir, repite con simular=false y confirmar=true.",
          };
        }

        const escritura = await escribirTabla({
          destino,
          encabezados: h.columnas.map((c) => c.nombre),
          filas: matrizSalida(h, resultado.filas),
          nombreHoja: h.hoja,
          delimitador: args.delimitador_csv,
          bom: args.bom,
          protegerFormulas: true,
        });

        return {
          ...base,
          simulado: false,
          escrito: true,
          salida: escritura.ruta,
          formato: escritura.formato,
          bytes: escritura.bytes,
          avisos: [...base.avisos, ...escritura.avisos],
          nota: "Se exportaron valores (no formulas ni estilos) a un archivo nuevo.",
        };
      }),
  );

  server.registerTool(
    "excel_plugins_estado",
    {
      title: "Detectar complementos de Excel",
      description:
        "Detecta de forma no invasiva que complementos hay instalados o habilitados en Excel (Analysis ToolPak, Solver, Power Query, Power Pivot, Inquire, Kutools, Ablebits, etc.) leyendo solo el registro de Windows y nombres de archivo. No abre Excel, no lee codigo de complementos y no modifica nada. Usala para saber que funciones extra puede aprovechar la persona.",
      inputSchema: {
        forzar_actualizacion: z.boolean().default(false).describe("Si es true, ignora la cache de 15 segundos."),
      },
      annotations: { readOnlyHint: true },
    },
    async ({ forzar_actualizacion }) => conManejo(() => estadoPlugins(forzar_actualizacion)),
  );
}
