/**
 * Validacion de rutas de archivo.
 *
 * Reglas:
 *  - Solo .xlsx, .xlsm y .csv para lectura; .xlsx y .csv para escritura.
 *  - Nada de URLs, rutas de dispositivo de Windows ni rutas UNC (red).
 *  - Si EXCEL_DIRS esta definido, el archivo debe estar dentro de una de esas carpetas.
 *  - Se resuelven enlaces simbolicos antes de comprobar la carpeta permitida.
 */
import { open, realpath, stat } from "node:fs/promises";
import path from "node:path";
import { ErrorExcel } from "./errores.js";

export const EXTENSIONES_LECTURA = [".xlsx", ".xlsm", ".csv"] as const;
export const EXTENSIONES_ESCRITURA = [".xlsx", ".csv"] as const;

export type ExtensionLectura = (typeof EXTENSIONES_LECTURA)[number];
export type ExtensionEscritura = (typeof EXTENSIONES_ESCRITURA)[number];

export interface ArchivoEntrada {
  /** Ruta tal como se mostrara al usuario (resuelta, no necesariamente real). */
  ruta: string;
  /** Ruta canonica (enlaces resueltos). */
  rutaReal: string;
  nombre: string;
  extension: ExtensionLectura;
  tamano: number;
  tamanoMB: number;
}

export interface ArchivoSalida {
  ruta: string;
  /** Ruta canonica si el archivo ya existe (para detectar enlaces a la entrada). */
  rutaReal: string | null;
  nombre: string;
  extension: ExtensionEscritura;
  existe: boolean;
}

export interface ArchivoSalidaHtml {
  ruta: string;
  rutaReal: string | null;
  nombre: string;
  extension: ".html";
  existe: boolean;
}

function limiteMB(): number {
  const n = Number(process.env.EXCEL_MAX_MB);
  if (!Number.isFinite(n) || n <= 0) return 100;
  return Math.min(2048, Math.max(1, Math.round(n)));
}

export function carpetasPermitidas(): string[] {
  const crudo = process.env.EXCEL_DIRS;
  if (!crudo) return [];
  return crudo
    .split(path.delimiter)
    .map((s) => s.trim())
    .filter(Boolean)
    .map((s) => path.resolve(s));
}

function dentroDe(ruta: string, raiz: string): boolean {
  const normalizar = (s: string) => (process.platform === "win32" ? s.toLowerCase() : s);
  const r = normalizar(ruta);
  const base = normalizar(raiz.endsWith(path.sep) ? raiz.slice(0, -1) : raiz);
  return r === base || r.startsWith(base + path.sep);
}

function comprobarPermitida(ruta: string): void {
  const raices = carpetasPermitidas();
  if (raices.length === 0) return;
  if (!raices.some((raiz) => dentroDe(ruta, raiz))) {
    throw new ErrorExcel(
      `La ruta queda fuera de las carpetas permitidas por EXCEL_DIRS: ${raices.join(", ")}`,
      "Elige un archivo dentro de esas carpetas o pide a la persona que ajuste la variable EXCEL_DIRS.",
    );
  }
}

function validarTextoRuta(entrada: string, que: string): string {
  if (typeof entrada !== "string") throw new ErrorExcel(`La ruta de ${que} debe ser texto.`);
  const t = entrada.trim();
  if (t.length < 1 || t.length > 4096) {
    throw new ErrorExcel(`La ruta de ${que} debe tener entre 1 y 4096 caracteres.`);
  }
  if (/[\u0000-\u001f\u007f]/.test(t)) {
    throw new ErrorExcel(`La ruta de ${que} contiene caracteres de control no permitidos.`);
  }
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(t)) {
    throw new ErrorExcel(`No se aceptan URLs en la ruta de ${que}. Usa una ruta local de Windows.`);
  }
  if (process.platform === "win32") {
    if (t.startsWith("\\\\?\\") || t.startsWith("\\\\.\\")) {
      throw new ErrorExcel("No se aceptan rutas de dispositivo de Windows (\\\\.\\ o \\\\?\\).");
    }
    if (/^\\\\[^\\]/.test(t)) {
      throw new ErrorExcel(
        "No se aceptan rutas de red (UNC). Copia el archivo a una carpeta local o a una unidad asignada.",
      );
    }
  }
  return t;
}

function extensionDe(ruta: string): string {
  return path.extname(ruta).toLowerCase();
}

/** Lee los primeros bytes para distinguir OOXML (ZIP) de un .xls antiguo o un archivo cifrado. */
async function comprobarFormatoExcel(ruta: string): Promise<void> {
  let fh;
  try {
    fh = await open(ruta, "r");
    const buf = Buffer.alloc(8);
    const { bytesRead } = await fh.read(buf, 0, 8, 0);
    if (bytesRead >= 8 && buf[0] === 0x50 && buf[1] === 0x4b) return; // ZIP / OOXML
    if (
      bytesRead >= 8 &&
      buf[0] === 0xd0 && buf[1] === 0xcf && buf[2] === 0x11 && buf[3] === 0xe0 &&
      buf[4] === 0xa1 && buf[5] === 0xb1 && buf[6] === 0x1a && buf[7] === 0xe1
    ) {
      throw new ErrorExcel(
        "El archivo esta en formato binario antiguo (.xls) o protegido con contraseña. Este MCP solo lee .xlsx/.xlsm sin cifrar.",
        "Abre el archivo en Excel y usa Archivo > Guardar como > Libro de Excel (.xlsx). Si tiene contraseña, quitasela primero.",
      );
    }
    throw new ErrorExcel(
      "El archivo no parece un .xlsx/.xlsm valido.",
      "Comprueba que la extension coincida con el contenido o vuelve a guardarlo desde Excel.",
    );
  } finally {
    await fh?.close().catch(() => undefined);
  }
}

export async function validarArchivoEntrada(entrada: string): Promise<ArchivoEntrada> {
  const ruta = path.resolve(validarTextoRuta(entrada, "entrada"));
  const extension = extensionDe(ruta);
  if (!(EXTENSIONES_LECTURA as readonly string[]).includes(extension)) {
    throw new ErrorExcel(
      `La extension "${extension || "(sin extension)"}" no esta soportada para lectura.`,
      "Usa .xlsx, .xlsm o .csv. Los .xls antiguos deben guardarse como .xlsx.",
    );
  }

  let info;
  try {
    info = await stat(ruta);
  } catch {
    throw new ErrorExcel(
      `No encuentro el archivo: ${ruta}`,
      "Revisa la ruta y el nombre. Si esta en OneDrive, espera a que termine de sincronizar.",
    );
  }
  if (!info.isFile()) throw new ErrorExcel(`La ruta no es un archivo: ${ruta}`);

  const tamanoMB = info.size / (1024 * 1024);
  if (info.size === 0) throw new ErrorExcel("El archivo esta vacio (0 bytes).");
  if (tamanoMB > limiteMB()) {
    throw new ErrorExcel(
      `El archivo pesa ${tamanoMB.toFixed(1)} MB y el limite es ${limiteMB()} MB.`,
      "Sube el limite con la variable de entorno EXCEL_MAX_MB o trabaja con una copia mas pequena.",
    );
  }

  const rutaReal = await realpath(ruta);
  comprobarPermitida(rutaReal);
  if (extension !== ".csv") await comprobarFormatoExcel(rutaReal);

  return {
    ruta,
    rutaReal,
    nombre: path.basename(ruta),
    extension: extension as ExtensionLectura,
    tamano: info.size,
    tamanoMB,
  };
}

export async function validarArchivoSalida(entrada: string): Promise<ArchivoSalida> {
  const ruta = path.resolve(validarTextoRuta(entrada, "salida"));
  const extension = extensionDe(ruta);
  if (!(EXTENSIONES_ESCRITURA as readonly string[]).includes(extension)) {
    throw new ErrorExcel(
      `La extension "${extension || "(sin extension)"}" no esta soportada para escritura.`,
      "Usa .xlsx (conserva tipos y formato basico) o .csv (texto plano).",
    );
  }

  const carpeta = path.dirname(ruta);
  let infoCarpeta;
  try {
    infoCarpeta = await stat(carpeta);
  } catch {
    throw new ErrorExcel(
      `No existe la carpeta de destino: ${carpeta}`,
      "Crea la carpeta primero o elige una ruta existente. Por seguridad no se crean carpetas nuevas.",
    );
  }
  if (!infoCarpeta.isDirectory()) throw new ErrorExcel(`La carpeta de destino no es valida: ${carpeta}`);

  const carpetaReal = await realpath(carpeta);
  comprobarPermitida(carpetaReal);

  let existe = false;
  let rutaReal: string | null = null;
  try {
    const info = await stat(ruta);
    if (info.isDirectory()) throw new ErrorExcel(`La ruta de salida es una carpeta: ${ruta}`);
    existe = true;
    rutaReal = await realpath(ruta);
    comprobarPermitida(rutaReal);
  } catch (e) {
    if (e instanceof ErrorExcel) throw e;
    existe = false;
  }

  return { ruta, rutaReal, nombre: path.basename(ruta), extension: extension as ExtensionEscritura, existe };
}

/** Compara dos rutas ya resueltas (sin tocar el disco). */
export function mismaRuta(a: string, b: string): boolean {
  const norm = (s: string) => (process.platform === "win32" ? s.toLowerCase() : s);
  return norm(path.resolve(a)) === norm(path.resolve(b));
}

/**
 * Variante para reportes HTML: misma validacion de carpeta y permisos, pero admite .html.
 * No se agrega a EXTENSIONES_ESCRITURA para no cambiar el comportamiento de escribirTabla.
 */
export async function validarArchivoSalidaHtml(entrada: string): Promise<ArchivoSalidaHtml> {
  const ruta = path.resolve(validarTextoRuta(entrada, "salida"));
  const extension = extensionDe(ruta);
  if (extension !== ".html") {
    throw new ErrorExcel(
      `La extension "${extension || "(sin extension)"}" no sirve para un reporte.`,
      "Usa un nombre terminado en .html, por ejemplo reporte_ventas.html.",
    );
  }

  const carpeta = path.dirname(ruta);
  let infoCarpeta;
  try {
    infoCarpeta = await stat(carpeta);
  } catch {
    throw new ErrorExcel(
      `No existe la carpeta de destino: ${carpeta}`,
      "Crea la carpeta primero o elige una ruta existente. Por seguridad no se crean carpetas nuevas.",
    );
  }
  if (!infoCarpeta.isDirectory()) throw new ErrorExcel(`La carpeta de destino no es valida: ${carpeta}`);

  const carpetaReal = await realpath(carpeta);
  comprobarPermitida(carpetaReal);

  let existe = false;
  let rutaReal: string | null = null;
  try {
    const info = await stat(ruta);
    if (info.isDirectory()) throw new ErrorExcel(`La ruta de salida es una carpeta: ${ruta}`);
    existe = true;
    rutaReal = await realpath(ruta);
    comprobarPermitida(rutaReal);
  } catch (e) {
    if (e instanceof ErrorExcel) throw e;
    existe = false;
  }

  return { ruta, rutaReal, nombre: path.basename(ruta), extension: ".html", existe };
}
