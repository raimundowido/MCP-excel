/**
 * Inspeccion estructural del contenedor OOXML (.xlsx/.xlsm) con JSZip.
 *
 * Lee el ZIP y describe lo que ExcelJS no expone: nombres definidos, conexiones,
 * Power Query, cache de tablas dinamicas, complementos, proteccion, propiedades y
 * objetos incrustados. Es SOLO LECTURA: no ejecuta macros, no sigue enlaces externos
 * y no devuelve cadenas de conexion ni credenciales.
 *
 * El XML se recorre con expresiones regulares acotadas; no se expanden entidades
 * externas ni se interpreta el contenido como instrucciones.
 */
import { readFile } from "node:fs/promises";
import path from "node:path";
import JSZip from "jszip";
import { ErrorExcel } from "./errores.js";
import type { ArchivoEntrada } from "./rutas.js";

export interface OpcionesInspeccion {
  /** Lista imagenes, graficos y otros objetos incrustados. */
  incluirObjetos: boolean;
  /** Tope de elementos por lista (hojas, tablas, conexiones...). */
  maxElementos: number;
}

export interface HojaEstructura {
  nombre: string;
  indice: number;
  estado: string;
  parte: string | null;
  rango: string | null;
  filas: number | null;
  celdas: number | null;
  autoFiltro: string | null;
  combinadas: number;
  validaciones: number;
  formatoCondicional: number;
  hipervinculos: number;
  tablas: number;
  dibujos: number;
  protegida: boolean;
}

export interface TablaEstructura {
  nombre: string;
  hoja: string | null;
  rango: string;
  filaEncabezado: boolean;
  filaTotales: boolean;
  columnas: string[];
  columnasTotales: number;
}

export interface NombreDefinido {
  nombre: string;
  formula: string;
  hoja: string | null;
  oculto: boolean;
  ambito: "libro" | "hoja";
}

export interface ConexionEstructura {
  nombre: string;
  tipo: string;
  descripcion: string | null;
  soloLectura: boolean;
  actualizadaEn: string | null;
}

export interface ConsultaPowerQuery {
  nombre: string;
  hoja: string | null;
  rango: string | null;
  refrescarAlAbrir: boolean;
}

export interface TablaDinamica {
  nombre: string;
  cache: string | null;
  ubicacion: string | null;
  filas: number | null;
  columnas: number | null;
}

export interface ResultadoInspeccion {
  archivo: string;
  nombre: string;
  extension: string;
  tamanoMB: number;
  contenedor: {
    partes: number;
    partesPrincipales: string[];
    comentarios: boolean;
    firmaDigital: boolean;
  };
  resumen: {
    hojas: number;
    hojasVisibles: number;
    hojasOcultas: number;
    tablas: number;
    nombresDefinidos: number;
    conexiones: number;
    consultasPowerQuery: number;
    tablasDinamicas: number;
    cacheDinamicas: number;
    enlacesExternos: number;
    macros: boolean;
    protegido: boolean;
    imagenes: number;
    graficos: number;
    comentarios: number;
    controles: number;
  };
  hojas: HojaEstructura[];
  tablas: TablaEstructura[];
  nombresDefinidos: NombreDefinido[];
  conexiones: ConexionEstructura[];
  powerQuery: ConsultaPowerQuery[];
  tablasDinamicas: TablaDinamica[];
  enlacesExternos: string[];
  proteccion: {
    libro: boolean;
    estructuraBloqueada: boolean;
    ventanasBloqueadas: boolean;
    conContrasena: boolean;
    hojasProtegidas: string[];
  };
  macros: {
    presente: boolean;
    firma: boolean;
    extensionCoincide: boolean;
  };
  propiedades: {
    titulo: string | null;
    asunto: string | null;
    autor: string | null;
    ultimoAutor: string | null;
    creado: string | null;
    modificado: string | null;
    aplicacion: string | null;
    versionAplicacion: string | null;
    empresa: string | null;
  };
  objetos: {
    imagenes: { nombre: string; bytes: number }[];
    graficos: number;
    dibujos: number;
    comentarios: number;
    controles: number;
    estilos: number | null;
    partesOmitidas: string[];
  };
  calculo: {
    modo: string | null;
    recalcularAlAbrir: boolean;
    cadenaCalculo: boolean;
  };
  avisos: string[];
  truncado: boolean;
}

function decodificarXml(s: string): string {
  return s
    .replace(/&#x([0-9a-f]+);/gi, (_, h: string) => {
      const n = Number.parseInt(h, 16);
      return Number.isFinite(n) && n > 0 && n <= 0x10ffff ? String.fromCodePoint(n) : "";
    })
    .replace(/&#(\d+);/g, (_, d: string) => {
      const n = Number.parseInt(d, 10);
      return Number.isFinite(n) && n > 0 && n <= 0x10ffff ? String.fromCodePoint(n) : "";
    })
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, "&");
}

function escaparRegex(s: string): string {
  const META = ".*+?^$()[]{}|\\";
  let out = "";
  for (const ch of s) out += META.includes(ch) ? "\\" + ch : ch;
  return out;
}

function atributo(attrs: string, nombre: string): string | null {
  const re = new RegExp(`(?:^|\\s)${escaparRegex(nombre)}\\s*=\\s*"([^"]*)"`, "i");
  const m = re.exec(attrs);
  return m ? decodificarXml(m[1] ?? "") : null;
}

function numeroAttr(attrs: string, nombre: string): number | null {
  const v = atributo(attrs, nombre);
  if (v === null || v.trim() === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function booleanoAttr(attrs: string, nombre: string): boolean {
  const v = atributo(attrs, nombre);
  return v === "1" || v === "true" || v === "on";
}

function contar(xml: string, patron: RegExp): number {
  let n = 0;
  for (const _ of xml.matchAll(patron)) n++;
  return n;
}

function textoEtiqueta(xml: string, etiqueta: string): string | null {
  const m = new RegExp(`<${etiqueta}\\b[^>]*>([\\s\\S]*?)</${etiqueta}>`, "i").exec(xml);
  if (!m) return null;
  const t = decodificarXml((m[1] ?? "").replace(/<[^>]+>/g, "")).trim();
  return t === "" ? null : t;
}

interface Relacion {
  id: string;
  tipo: string;
  destino: string;
}

function relaciones(xml: string): Relacion[] {
  const out: Relacion[] = [];
  for (const m of xml.matchAll(/<Relationship\b([^>]*)\/?>/gi)) {
    const attrs = m[1] ?? "";
    const id = atributo(attrs, "Id");
    const destino = atributo(attrs, "Target");
    if (id === null || destino === null) continue;
    out.push({ id, tipo: atributo(attrs, "Type") ?? "", destino });
  }
  return out;
}

function resolverDestino(destino: string): string {
  if (destino.startsWith("/")) return destino.slice(1);
  const partes = `xl/${destino}`.split("/");
  const pila: string[] = [];
  for (const p of partes) {
    if (p === "" || p === ".") continue;
    if (p === "..") pila.pop();
    else pila.push(p);
  }
  return pila.join("/");
}

function tipoConexion(tipo: string | null): string {
  switch (tipo) {
    case "1":
      return "OLEDB";
    case "2":
      return "ODBC";
    case "3":
      return "XML";
    case "4":
      return "Texto/CSV";
    case "5":
      return "Web";
    case "6":
      return "Lista de datos";
    case "7":
      return "Modelo de datos";
    default:
      return tipo ? `tipo ${tipo}` : "desconocido";
  }
}

const PARTES_PRINCIPALES = [
  "xl/workbook.xml",
  "xl/styles.xml",
  "xl/sharedStrings.xml",
  "xl/vbaProject.bin",
  "xl/connections.xml",
  "xl/calcChain.xml",
  "docProps/core.xml",
  "docProps/app.xml",
];

async function leerTexto(zip: JSZip, ruta: string): Promise<string> {
  const f = zip.file(ruta);
  if (!f) return "";
  try {
    return await f.async("string");
  } catch {
    return "";
  }
}

export async function inspeccionarLibro(
  archivo: ArchivoEntrada,
  opciones: OpcionesInspeccion,
): Promise<ResultadoInspeccion> {
  if (archivo.extension === ".csv") {
    throw new ErrorExcel(
      "La inspeccion estructural solo aplica a libros .xlsx o .xlsm.",
      "Para un CSV usa excel_leer_tabla, excel_perfilar_columna o excel_generar_reporte.",
    );
  }

  let zip: JSZip;
  try {
    zip = await JSZip.loadAsync(await readFile(archivo.rutaReal));
  } catch (e) {
    throw new ErrorExcel(
      `No pude abrir el contenedor del libro: ${e instanceof Error ? e.message : String(e)}`,
      "Comprueba que el archivo no este danado ni cifrado y que sea un .xlsx/.xlsm real.",
    );
  }

  const max = Math.max(1, Math.min(500, opciones.maxElementos));
  const nombresPartes = Object.keys(zip.files).filter((n) => !zip.files[n]!.dir).sort();
  const existe = (n: string) => nombresPartes.includes(n);
  const partesCon = (prefijo: string) => nombresPartes.filter((n) => n.startsWith(prefijo));

  const avisos: string[] = [];
  let truncado = false;

  // ------------------------- libro -------------------------
  const workbookXml = await leerTexto(zip, "xl/workbook.xml");
  if (workbookXml === "") {
    throw new ErrorExcel(
      "El archivo no contiene xl/workbook.xml; no parece un libro de Excel valido.",
      "Vuelve a guardarlo desde Excel como .xlsx.",
    );
  }
  const workbookRels = relaciones(await leerTexto(zip, "xl/_rels/workbook.xml.rels"));
  const relPorId = new Map(workbookRels.map((r) => [r.id, r]));

  interface HojaCruda {
    nombre: string;
    indice: number;
    estado: string;
    parte: string | null;
  }
  const hojasCrudas: HojaCruda[] = [];
  for (const m of workbookXml.matchAll(/<sheet\b([^>]*)\/?>/gi)) {
    const attrs = m[1] ?? "";
    const nombre = atributo(attrs, "name") ?? `Hoja ${hojasCrudas.length + 1}`;
    const rid = atributo(attrs, "r:id");
    const rel = rid ? relPorId.get(rid) : undefined;
    hojasCrudas.push({
      nombre,
      indice: numeroAttr(attrs, "sheetId") ?? hojasCrudas.length + 1,
      estado: atributo(attrs, "state") ?? "visible",
      parte: rel ? resolverDestino(rel.destino) : null,
    });
  }
  if (hojasCrudas.length > max) {
    truncado = true;
    avisos.push(`El libro tiene ${hojasCrudas.length} hojas; se detallan las primeras ${max}.`);
  }

  const hojas: HojaEstructura[] = [];
  for (const h of hojasCrudas.slice(0, max)) {
    const xml = h.parte ? await leerTexto(zip, h.parte) : "";
    const dim = /<dimension\b([^>]*)\/?>/i.exec(xml);
    const autoFiltro = /<autoFilter\b([^>]*)\/?>/i.exec(xml);
    hojas.push({
      nombre: h.nombre,
      indice: h.indice,
      estado: h.estado,
      parte: h.parte,
      rango: dim ? atributo(dim[1] ?? "", "ref") : null,
      filas: xml === "" ? null : contar(xml, /<row\b/gi),
      celdas: xml === "" ? null : contar(xml, /<c\b/gi),
      autoFiltro: autoFiltro ? atributo(autoFiltro[1] ?? "", "ref") : null,
      combinadas: contar(xml, /<mergeCell\b/gi),
      validaciones: contar(xml, /<dataValidation\b/gi),
      formatoCondicional: contar(xml, /<conditionalFormatting\b/gi),
      hipervinculos: contar(xml, /<hyperlink\b/gi),
      tablas: contar(xml, /<tablePart\b/gi),
      dibujos: contar(xml, /<drawing\b/gi),
      protegida: /<sheetProtection\b/i.test(xml),
    });
  }

  // ------------------------- tablas -------------------------
  // Asocia cada tabla con la hoja que la referencia (por nombre de parte).
  const hojaPorParteTabla = new Map<string, string>();
  for (const h of hojasCrudas) {
    if (!h.parte) continue;
    const relsParte = `xl/worksheets/_rels/${path.basename(h.parte)}.rels`;
    for (const rel of relaciones(await leerTexto(zip, relsParte))) {
      if (!rel.tipo.includes("/table")) continue;
      hojaPorParteTabla.set(path.basename(resolverDestino(rel.destino)), h.nombre);
    }
  }

  const tablas: TablaEstructura[] = [];
  const partesTabla = partesCon("xl/tables/").filter((n) => n.endsWith(".xml"));
  for (const parte of partesTabla.slice(0, max)) {
    const xml = await leerTexto(zip, parte);
    const m = /<table\b([^>]*)>/i.exec(xml);
    if (!m) continue;
    const attrs = m[1] ?? "";
    const columnas: string[] = [];
    for (const cm of xml.matchAll(/<tableColumn\b([^>]*)\/?>/gi)) {
      const n = atributo(cm[1] ?? "", "name");
      if (n !== null && columnas.length < 200) columnas.push(n);
    }
    const columnasTotales = numeroAttr(attrs, "count") ?? contar(xml, /<tableColumn\b/gi);
    if (columnasTotales > columnas.length) truncado = true;
    tablas.push({
      nombre: atributo(attrs, "displayName") ?? atributo(attrs, "name") ?? path.basename(parte, ".xml"),
      hoja: hojaPorParteTabla.get(path.basename(parte)) ?? null,
      rango: atributo(attrs, "ref") ?? "",
      filaEncabezado: (numeroAttr(attrs, "headerRowCount") ?? 1) > 0,
      filaTotales: (numeroAttr(attrs, "totalsRowCount") ?? 0) > 0,
      columnas,
      columnasTotales,
    });
  }
  if (partesTabla.length > max) {
    truncado = true;
    avisos.push(`Hay ${partesTabla.length} tablas; se detallan las primeras ${max}.`);
  }

  // ------------------------- nombres definidos -------------------------
  const nombresDefinidos: NombreDefinido[] = [];
  for (const m of workbookXml.matchAll(/<definedName\b([^>]*)>([\s\S]*?)<\/definedName>/gi)) {
    const attrs = m[1] ?? "";
    const local = numeroAttr(attrs, "localSheetId");
    nombresDefinidos.push({
      nombre: atributo(attrs, "name") ?? "",
      formula: decodificarXml((m[2] ?? "").trim()),
      hoja: local !== null ? (hojasCrudas[local]?.nombre ?? null) : null,
      oculto: booleanoAttr(attrs, "hidden"),
      ambito: local === null ? "libro" : "hoja",
    });
    if (nombresDefinidos.length >= max) {
      truncado = true;
      avisos.push(`Hay mas de ${max} nombres definidos; se listan los primeros.`);
      break;
    }
  }

  // ------------------------- conexiones -------------------------
  const conexiones: ConexionEstructura[] = [];
  const conexionesXml = await leerTexto(zip, "xl/connections.xml");
  for (const m of conexionesXml.matchAll(/<connection\b([^>]*)>/gi)) {
    const attrs = m[1] ?? "";
    conexiones.push({
      nombre: atributo(attrs, "name") ?? "(sin nombre)",
      tipo: tipoConexion(atributo(attrs, "type")),
      // La descripcion puede ser util; la cadena de conexion se omite a proposito.
      descripcion: atributo(attrs, "description"),
      soloLectura: booleanoAttr(attrs, "onlyUseConnectionFile"),
      actualizadaEn: atributo(attrs, "refreshedVersion"),
    });
    if (conexiones.length >= max) {
      truncado = true;
      break;
    }
  }
  if (conexiones.length > 0) {
    avisos.push(
      "Se detectaron conexiones externas. No se devuelve la cadena de conexion ni credenciales; revisa el origen en Excel si necesitas actualizarlas.",
    );
  }

  // ------------------------- Power Query -------------------------
  const powerQuery: ConsultaPowerQuery[] = [];
  const partesConsulta = partesCon("xl/queryTables/").filter((n) => n.endsWith(".xml"));
  for (const parte of partesConsulta.slice(0, max)) {
    const xml = await leerTexto(zip, parte);
    const m = /<queryTable\b([^>]*)>/i.exec(xml);
    if (!m) continue;
    const attrs = m[1] ?? "";
    const ws = /<worksheetSource\b([^>]*)\/?>/i.exec(xml);
    powerQuery.push({
      nombre: atributo(attrs, "name") ?? path.basename(parte, ".xml"),
      hoja: ws ? atributo(ws[1] ?? "", "sheet") : null,
      rango: ws ? atributo(ws[1] ?? "", "ref") : null,
      refrescarAlAbrir: booleanoAttr(attrs, "refreshOnLoad"),
    });
  }
  let dataMashup = false;
  for (const parte of partesCon("customXml/")) {
    if (!parte.endsWith(".xml")) continue;
    const xml = await leerTexto(zip, parte);
    if (/DataMashup|PowerQuery/i.test(xml)) {
      dataMashup = true;
      break;
    }
  }
  const consultasEstimadas = Math.max(powerQuery.length, dataMashup ? 1 : 0);
  if (dataMashup) {
    avisos.push(
      "El libro contiene un DataMashup de Power Query. No se extrae el codigo M porque puede incluir rutas, nombres de servidor o credenciales.",
    );
  }

  // ------------------------- tablas dinamicas -------------------------
  const tablasDinamicas: TablaDinamica[] = [];
  const partesPivot = partesCon("xl/pivotTables/").filter((n) => n.endsWith(".xml"));
  for (const parte of partesPivot.slice(0, max)) {
    const xml = await leerTexto(zip, parte);
    const m = /<pivotTableDefinition\b([^>]*)>/i.exec(xml);
    if (!m) continue;
    const attrs = m[1] ?? "";
    const loc = /<location\b([^>]*)\/?>/i.exec(xml);
    tablasDinamicas.push({
      nombre: atributo(attrs, "name") ?? path.basename(parte, ".xml"),
      cache: atributo(attrs, "cacheId"),
      ubicacion: loc ? atributo(loc[1] ?? "", "ref") : null,
      filas: loc ? numeroAttr(loc[1] ?? "", "rowPageCount") : null,
      columnas: loc ? numeroAttr(loc[1] ?? "", "colPageCount") : null,
    });
  }
  const cacheDinamicas = partesCon("xl/pivotCache/").filter((n) => /pivotCacheDefinition.*\.xml$/i.test(n)).length;

  // ------------------------- enlaces externos -------------------------
  const enlacesExternos: string[] = [];
  for (const parte of partesCon("xl/externalLinks/").filter((n) => n.endsWith(".xml")).slice(0, max)) {
    const xml = await leerTexto(zip, parte);
    const rels = relaciones(await leerTexto(zip, `xl/externalLinks/_rels/${path.basename(parte)}.rels`));
    const destinos = rels.map((r) => r.destino).filter(Boolean);
    if (destinos.length === 0) enlacesExternos.push(path.basename(parte));
    for (const d of destinos.slice(0, 10)) enlacesExternos.push(d);
    void xml;
  }
  if (enlacesExternos.length > 0) {
    avisos.push("Hay enlaces a otros libros; no se abren ni se actualizan desde este MCP.");
  }

  // ------------------------- proteccion -------------------------
  const prot = /<workbookProtection\b([^>]*)\/?>/i.exec(workbookXml);
  const proteccion = {
    libro: prot !== null,
    estructuraBloqueada: prot ? booleanoAttr(prot[1] ?? "", "lockStructure") : false,
    ventanasBloqueadas: prot ? booleanoAttr(prot[1] ?? "", "lockWindows") : false,
    conContrasena: prot ? /(?:workbook|revisions)Password\s*=/i.test(prot[1] ?? "") : false,
    hojasProtegidas: hojas.filter((h) => h.protegida).map((h) => h.nombre),
  };
  if (proteccion.libro || proteccion.hojasProtegidas.length > 0) {
    avisos.push("El libro o alguna hoja esta protegido. Este MCP no intenta quitar la proteccion.");
  }

  // ------------------------- macros -------------------------
  const macros = {
    presente: existe("xl/vbaProject.bin"),
    firma: existe("xl/vbaProjectSignature.bin"),
    extensionCoincide:
      (archivo.extension === ".xlsm" && existe("xl/vbaProject.bin")) ||
      (archivo.extension === ".xlsx" && !existe("xl/vbaProject.bin")),
  };
  if (archivo.extension === ".xlsm" && !macros.presente) {
    avisos.push("La extension es .xlsm pero no se encontro xl/vbaProject.bin.");
  }
  if (archivo.extension === ".xlsx" && macros.presente) {
    avisos.push("El archivo .xlsx contiene un proyecto VBA; algunos lectores pueden rechazarlo.");
  }
  if (macros.presente) {
    avisos.push("El libro contiene macros. No se ejecutan ni se inspecciona su codigo.");
  }

  // ------------------------- propiedades -------------------------
  const coreXml = await leerTexto(zip, "docProps/core.xml");
  const appXml = await leerTexto(zip, "docProps/app.xml");
  const propiedades = {
    titulo: textoEtiqueta(coreXml, "dc:title"),
    asunto: textoEtiqueta(coreXml, "dc:subject"),
    autor: textoEtiqueta(coreXml, "dc:creator"),
    ultimoAutor: textoEtiqueta(coreXml, "cp:lastModifiedBy"),
    creado: textoEtiqueta(coreXml, "dcterms:created"),
    modificado: textoEtiqueta(coreXml, "dcterms:modified"),
    aplicacion: textoEtiqueta(appXml, "Application"),
    versionAplicacion: textoEtiqueta(appXml, "AppVersion"),
    empresa: textoEtiqueta(appXml, "Company"),
  };

  // ------------------------- objetos -------------------------
  const imagenes = opciones.incluirObjetos
    ? partesCon("xl/media/")
        .slice(0, max)
        .map((n) => ({
          nombre: path.basename(n),
          bytes:
            (zip.files[n] as unknown as { _data?: { uncompressedSize?: number } } | undefined)?._data
              ?.uncompressedSize ?? 0,
        }))
    : [];
  if (opciones.incluirObjetos && partesCon("xl/media/").length > max) {
    truncado = true;
    avisos.push(`Hay mas de ${max} imagenes; se listan las primeras.`);
  }
  const estilosXml = await leerTexto(zip, "xl/styles.xml");
  const cellXfs = /<cellXfs\b([^>]*)>/i.exec(estilosXml);
  const partesOmitidas = nombresPartes.filter((n) =>
    /(?:^|\/)(?:embeddings|activeX|ctrlProps|slicers|slicerCaches|timelines)\//i.test(n),
  );
  if (partesOmitidas.length > 0 && opciones.incluirObjetos) {
    avisos.push(
      `Hay ${partesOmitidas.length} parte(s) incrustadas (controles, segmentaciones o incrustaciones) que no se procesan por seguridad.`,
    );
  }

  const calculo = (() => {
    const m = /<calcPr\b([^>]*)\/?>/i.exec(workbookXml);
    if (!m) return { modo: null, recalcularAlAbrir: false, cadenaCalculo: existe("xl/calcChain.xml") };
    const attrs = m[1] ?? "";
    return {
      modo: atributo(attrs, "calcMode"),
      recalcularAlAbrir: booleanoAttr(attrs, "fullCalcOnLoad") || booleanoAttr(attrs, "forceFullCalc"),
      cadenaCalculo: existe("xl/calcChain.xml"),
    };
  })();

  const hojasVisibles = hojasCrudas.filter((h) => h.estado === "visible").length;

  return {
    archivo: archivo.ruta,
    nombre: archivo.nombre,
    extension: archivo.extension,
    tamanoMB: Number(archivo.tamanoMB.toFixed(3)),
    contenedor: {
      partes: nombresPartes.length,
      partesPrincipales: PARTES_PRINCIPALES.filter((p) => existe(p)),
      comentarios: partesCon("xl/comments").length > 0,
      firmaDigital: partesCon("_xmlsignatures/").length > 0,
    },
    resumen: {
      hojas: hojasCrudas.length,
      hojasVisibles,
      hojasOcultas: hojasCrudas.length - hojasVisibles,
      tablas: tablas.length,
      nombresDefinidos: nombresDefinidos.length,
      conexiones: conexiones.length,
      consultasPowerQuery: consultasEstimadas,
      tablasDinamicas: tablasDinamicas.length,
      cacheDinamicas,
      enlacesExternos: enlacesExternos.length,
      macros: macros.presente,
      protegido: proteccion.libro || proteccion.hojasProtegidas.length > 0,
      imagenes: partesCon("xl/media/").length,
      graficos: partesCon("xl/charts/").filter((n) => n.endsWith(".xml")).length,
      comentarios: partesCon("xl/comments").length,
      controles:
        partesCon("xl/activeX/").length +
        partesCon("xl/ctrlProps/").length +
        partesCon("xl/slicers/").length +
        partesCon("xl/timelines/").length,
    },
    hojas,
    tablas,
    nombresDefinidos,
    conexiones,
    powerQuery,
    tablasDinamicas,
    enlacesExternos,
    proteccion,
    macros,
    propiedades,
    objetos: {
      imagenes,
      graficos: partesCon("xl/charts/").filter((n) => n.endsWith(".xml")).length,
      dibujos: partesCon("xl/drawings/").filter((n) => n.endsWith(".xml") && !n.includes("_rels")).length,
      comentarios: partesCon("xl/comments").length,
      controles:
        partesCon("xl/activeX/").length +
        partesCon("xl/ctrlProps/").length +
        partesCon("xl/slicers/").length +
        partesCon("xl/timelines/").length,
      estilos: cellXfs ? numeroAttr(cellXfs[1] ?? "", "count") : null,
      partesOmitidas: opciones.incluirObjetos ? partesOmitidas.slice(0, max) : [],
    },
    calculo,
    avisos,
    truncado,
  };
}
