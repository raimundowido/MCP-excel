/**
 * Transformaciones de tablas sobre archivos: ordenar filas, agrupar y agregar, buscar y reemplazar.
 *
 * Todas leen el archivo de entrada, trabajan sobre copias en memoria y, si se pide,
 * escriben el resultado en un archivo NUEVO (.xlsx o .csv). Por defecto simulan.
 */
import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import path from "node:path";
import { z } from "zod";
import { error, json } from "../lib/respuestas.js";
import { ErrorExcel, mensajeError } from "../lib/excel/errores.js";
import { leerHoja, resolverColumna, type HojaLeida } from "../lib/excel/libro.js";
import { filaComoObjeto, matrizSalida } from "../lib/excel/filtros.js";
import {
  agruparTabla,
  buscarReemplazar,
  ordenarFilas,
  type DireccionOrden,
  type EspecificacionAgregacion,
  type FuncionAgregacion,
} from "../lib/excel/transformaciones.js";
import { mismaRuta, validarArchivoEntrada, validarArchivoSalida } from "../lib/excel/rutas.js";
import { escribirTabla } from "../lib/excel/salida.js";

const ARCHIVO = z
  .string()
  .min(1)
  .max(4096)
  .describe("Ruta local del archivo .xlsx, .xlsm o .csv. Ejemplo: C:\\datos\\ventas.xlsx");

const HOJA = z
  .string()
  .max(200)
  .optional()
  .describe("Nombre de la hoja o su numero (1 = primera). Si se omite, se usa la primera hoja visible.");

const RANGO = z
  .string()
  .min(1)
  .max(40)
  .optional()
  .describe("Rango A1 opcional, por ejemplo A1:F200. Si se omite y hay una tabla, se usa la tabla.");

const FILA_ENCABEZADO = z
  .number()
  .int()
  .min(1)
  .max(1_048_576)
  .optional()
  .describe("Fila que contiene los nombres de columna. Si se omite, se detecta automaticamente.");

async function conManejo(fn: () => Promise<unknown>) {
  try {
    return json(await fn());
  } catch (e) {
    return error(mensajeError(e));
  }
}

function prefijoComun(hoja: HojaLeida) {
  return {
    archivo: hoja.archivo,
    hoja: hoja.hoja,
    filaEncabezado: hoja.filaEncabezado,
    rango: hoja.rango,
    tablas: hoja.tablas,
    avisos: hoja.avisos,
  };
}

export function register(server: McpServer): void {
  // ---------------------------------------------------------------------
  // excel_ordenar_filas
  // ---------------------------------------------------------------------
  server.registerTool(
    "excel_ordenar_filas",
    {
      title: "Ordenar filas de una tabla",
      description:
        "Ordena las filas de una hoja por una o varias columnas (ascendente o descendente) y escribe el resultado en un .xlsx o .csv NUEVO. Por defecto solo simula (simular=true) y muestra una vista previa. No modifica el archivo original ni conserva formulas/estilos: exporta valores.",
      inputSchema: {
        archivo: ARCHIVO,
        salida: z.string().max(4096).optional().describe("Ruta de salida .xlsx o .csv. Si se omite: <nombre>_ordenado.<formato> junto al original."),
        orden: z
          .array(
            z.object({
              columna: z.string().min(1).max(200).describe("Columna por nombre, letra (C) o numero (3)."),
              direccion: z.enum(["asc", "desc"]).default("asc").describe("'asc' ascendente, 'desc' descendente."),
            }),
          )
          .min(1)
          .max(5)
          .describe("Una a cinco claves de orden, en prioridad."),
        hoja: HOJA,
        rango: RANGO,
        fila_encabezado: FILA_ENCABEZADO,
        formato: z.enum(["xlsx", "csv"]).optional().describe("Formato de salida. Si se omite, se deduce de la extension de 'salida' (o xlsx)."),
        delimitador_csv: z.enum([",", ";"]).default(",").describe("Delimitador para CSV."),
        bom: z.boolean().default(true).describe("Agrega BOM UTF-8 al CSV."),
        simular: z.boolean().default(true).describe("true = no escribe nada, solo muestra el resultado. false = escribe el archivo."),
        sobrescribir: z.boolean().default(false).describe("Permite reemplazar un archivo de salida existente (requiere confirmar=true)."),
        confirmar: z.literal(true).optional().describe("Obligatorio true cuando simular=false."),
        max_filas_preview: z.number().int().min(0).max(200).default(20).describe("Filas de vista previa a devolver."),
      },
      annotations: { readOnlyHint: false, destructiveHint: true, openWorldHint: false },
    },
    async (args) =>
      conManejo(async () => {
        const a = await validarArchivoEntrada(args.archivo);
        const h = await leerHoja(a, {
          hoja: args.hoja,
          rango: args.rango,
          filaEncabezado: args.fila_encabezado,
          maxFilas: 200_000,
          maxColumnas: 100,
        });
        const claves = args.orden.map((o) => ({
          columna: resolverColumna(h, o.columna),
          direccion: o.direccion as DireccionOrden,
        }));
        const ordenadas = ordenarFilas(h, claves);

        let formato = args.formato;
        if (args.salida) {
          const ext = path.extname(args.salida).toLowerCase();
          if (formato && ((formato === "xlsx" && ext !== ".xlsx") || (formato === "csv" && ext !== ".csv"))) {
            throw new ErrorExcel(`El formato "${formato}" no coincide con la extension de la salida "${ext}".`);
          }
          formato = formato ?? (ext === ".csv" ? "csv" : "xlsx");
        }
        formato = formato ?? "xlsx";

        const salidaTexto = args.salida
          ? args.salida
          : path.join(path.dirname(a.ruta), `${path.basename(a.ruta, path.extname(a.ruta))}_ordenado.${formato}`);
        const destino = await validarArchivoSalida(salidaTexto);

        if (destino.extension.slice(1) !== formato) {
          throw new ErrorExcel(`La salida "${destino.ruta}" no coincide con el formato ${formato}.`);
        }
        if (mismaRuta(a.ruta, destino.ruta) || (destino.rutaReal !== null && mismaRuta(a.rutaReal, destino.rutaReal))) {
          throw new ErrorExcel("La salida no puede ser el mismo archivo de entrada.");
        }
        if (!args.simular) {
          if (args.confirmar !== true) {
            throw new ErrorExcel("Para escribir el archivo debes enviar simular=false y confirmar=true.");
          }
          if (destino.existe && !args.sobrescribir) {
            throw new ErrorExcel(`Ya existe el archivo de salida: ${destino.ruta}`, "Elige otro nombre o envia sobrescribir=true junto con confirmar=true.");
          }
          if (ordenadas.length === 0) {
            throw new ErrorExcel("El orden no dejo ninguna fila; no se escribio el archivo.");
          }
        }

        const vistaPrevia = ordenadas.slice(0, args.max_filas_preview).map((f) => filaComoObjeto(h, f));
        const base = {
          ...prefijoComun(h),
          nombre: a.nombre,
          orden: claves.map((c) => ({ columna: c.columna.nombre, direccion: c.direccion })),
          filasEntrada: h.filas.length,
          filasSalida: ordenadas.length,
          vistaPrevia,
          salidaPrevista: destino.ruta,
          salidaExiste: destino.existe,
        };

        if (args.simular) {
          return { ...base, simulado: true, escrito: false, nota: "No se escribio ningun archivo. Para escribir, repite con simular=false y confirmar=true." };
        }

        const escritura = await escribirTabla({
          destino,
          encabezados: h.columnas.map((c) => c.nombre),
          filas: matrizSalida(h, ordenadas),
          nombreHoja: h.hoja,
          delimitador: args.delimitador_csv,
          bom: args.bom,
          protegerFormulas: true,
        });

        return {
          ...base,
          simulado: false,
          escrito: true,
          salida: escritura.ruta,
          formato: escritura.formato,
          bytes: escritura.bytes,
          avisos: [...h.avisos, ...escritura.avisos],
          nota: "Se exportaron valores (no formulas ni estilos) a un archivo nuevo.",
        };
      }),
  );

  // ---------------------------------------------------------------------
  // excel_agrupar_tabla
  // ---------------------------------------------------------------------
  server.registerTool(
    "excel_agrupar_tabla",
    {
      title: "Agrupar y agregar una tabla",
      description:
        "Agrupa las filas por una o varias columnas y calcula agregaciones (conteo, suma, promedio, minimo, maximo, conteo de valores distintos) sobre columnas numericas, escribiendo el resultado en un .xlsx o .csv NUEVO. Util para resumenes y tablas dinamicas simples. Por defecto solo simula. No ejecuta Excel ni crea tablas dinamicas nativas.",
      inputSchema: {
        archivo: ARCHIVO,
        salida: z.string().max(4096).optional().describe("Ruta de salida .xlsx o .csv. Si se omite: <nombre>_agrupado.<formato> junto al original."),
        agrupar_por: z.array(z.string().min(1).max(200)).min(1).max(5).describe("Columnas por las que agrupar. Ejemplo: ['Ciudad', 'Anio']."),
        agregaciones: z
          .array(
            z.object({
              columna: z.string().min(1).max(200).describe("Columna numerica a agregar."),
              funcion: z.enum(["conteo", "suma", "promedio", "minimo", "maximo", "conteo_distintos"]).default("suma").describe("Funcion de agregacion."),
            }),
          )
          .max(20)
          .default([])
          .describe("Agregaciones a calcular. Si se omite, solo se cuenta el numero de filas por grupo."),
        hoja: HOJA,
        rango: RANGO,
        fila_encabezado: FILA_ENCABEZADO,
        formato: z.enum(["xlsx", "csv"]).optional().describe("Formato de salida."),
        delimitador_csv: z.enum([",", ";"]).default(",").describe("Delimitador para CSV."),
        bom: z.boolean().default(true).describe("Agrega BOM UTF-8 al CSV."),
        simular: z.boolean().default(true).describe("true = no escribe nada, solo muestra el resultado. false = escribe el archivo."),
        sobrescribir: z.boolean().default(false).describe("Permite reemplazar un archivo de salida existente (requiere confirmar=true)."),
        confirmar: z.literal(true).optional().describe("Obligatorio true cuando simular=false."),
        max_filas_preview: z.number().int().min(0).max(200).default(20).describe("Filas de vista previa a devolver."),
      },
      annotations: { readOnlyHint: false, destructiveHint: true, openWorldHint: false },
    },
    async (args) =>
      conManejo(async () => {
        const a = await validarArchivoEntrada(args.archivo);
        const h = await leerHoja(a, {
          hoja: args.hoja,
          rango: args.rango,
          filaEncabezado: args.fila_encabezado,
          maxFilas: 200_000,
          maxColumnas: 100,
        });
        const columnasGrupo = args.agrupar_por.map((n) => resolverColumna(h, n));
        const agregaciones: EspecificacionAgregacion[] = (args.agregaciones ?? []).map((x) => ({
          columna: resolverColumna(h, x.columna),
          funcion: x.funcion as FuncionAgregacion,
        }));
        const resultado = agruparTabla(h, columnasGrupo, agregaciones);

        let formato = args.formato;
        if (args.salida) {
          const ext = path.extname(args.salida).toLowerCase();
          if (formato && ((formato === "xlsx" && ext !== ".xlsx") || (formato === "csv" && ext !== ".csv"))) {
            throw new ErrorExcel(`El formato "${formato}" no coincide con la extension de la salida "${ext}".`);
          }
          formato = formato ?? (ext === ".csv" ? "csv" : "xlsx");
        }
        formato = formato ?? "xlsx";

        const salidaTexto = args.salida
          ? args.salida
          : path.join(path.dirname(a.ruta), `${path.basename(a.ruta, path.extname(a.ruta))}_agrupado.${formato}`);
        const destino = await validarArchivoSalida(salidaTexto);

        if (destino.extension.slice(1) !== formato) {
          throw new ErrorExcel(`La salida "${destino.ruta}" no coincide con el formato ${formato}.`);
        }
        if (mismaRuta(a.ruta, destino.ruta) || (destino.rutaReal !== null && mismaRuta(a.rutaReal, destino.rutaReal))) {
          throw new ErrorExcel("La salida no puede ser el mismo archivo de entrada.");
        }
        if (!args.simular) {
          if (args.confirmar !== true) {
            throw new ErrorExcel("Para escribir el archivo debes enviar simular=false y confirmar=true.");
          }
          if (destino.existe && !args.sobrescribir) {
            throw new ErrorExcel(`Ya existe el archivo de salida: ${destino.ruta}`, "Elige otro nombre o envia sobrescribir=true junto con confirmar=true.");
          }
          if (resultado.filas.length === 0) {
            throw new ErrorExcel("La agrupacion no dejo grupos; no se escribio el archivo.");
          }
        }

        const vistaPrevia = resultado.filas.slice(0, args.max_filas_preview).map((f) => {
          const o: Record<string, string | number | boolean | null> = {};
          resultado.encabezados.forEach((h2, i) => {
            o[h2] = f[i] as string | number | boolean | null;
          });
          return o;
        });

        const base = {
          ...prefijoComun(h),
          nombre: a.nombre,
          agruparPor: columnasGrupo.map((c) => c.nombre),
          agregaciones: agregaciones.map((x) => ({ columna: x.columna.nombre, funcion: x.funcion })),
          encabezados: resultado.encabezados,
          grupos: resultado.grupos,
          filasEntrada: h.filas.length,
          vistaPrevia,
          salidaPrevista: destino.ruta,
          salidaExiste: destino.existe,
        };

        if (args.simular) {
          return { ...base, simulado: true, escrito: false, nota: "No se escribio ningun archivo. Para escribir, repite con simular=false y confirmar=true." };
        }

        const escritura = await escribirTabla({
          destino,
          encabezados: resultado.encabezados,
          filas: resultado.filas,
          nombreHoja: `${h.hoja}_resumen`,
          delimitador: args.delimitador_csv,
          bom: args.bom,
          protegerFormulas: true,
        });

        return {
          ...base,
          simulado: false,
          escrito: true,
          salida: escritura.ruta,
          formato: escritura.formato,
          bytes: escritura.bytes,
          avisos: [...h.avisos, ...escritura.avisos],
          nota: "Se exportaron valores (no formulas ni estilos) a un archivo nuevo.",
        };
      }),
  );

  // ---------------------------------------------------------------------
  // excel_buscar_reemplazar
  // ---------------------------------------------------------------------
  server.registerTool(
    "excel_buscar_reemplazar",
    {
      title: "Buscar y reemplazar texto en una tabla",
      description:
        "Busca un texto en las celdas de texto de una hoja y lo reemplaza por otro, escribiendo el resultado en un .xlsx o .csv NUEVO. Por defecto simula (simular=true) y muestra cuantos reemplazos haria. No modifica el archivo original. El reemplazo es literal (no usa expresiones regulares) para evitar cambios inesperados.",
      inputSchema: {
        archivo: ARCHIVO,
        buscar: z.string().min(1).max(500).describe("Texto a buscar."),
        reemplazar: z.string().max(500).describe("Texto por el que reemplazar (puede ser vacio para borrar)."),
        salida: z.string().max(4096).optional().describe("Ruta de salida .xlsx o .csv. Si se omite: <nombre>_reemplazado.<formato> junto al original."),
        columnas: z.array(z.string().min(1).max(200)).max(20).optional().describe("Columnas donde buscar. Si se omite, se busca en todas las columnas de texto."),
        coincidencia_exacta: z.boolean().default(false).describe("Si es true, solo reemplaza celdas cuyo texto completo coincide con 'buscar'."),
        ignorar_mayusculas: z.boolean().default(true).describe("Busca sin distinguir mayusculas/minusculas."),
        ignorar_acentos: z.boolean().default(true).describe("Busca sin tildes."),
        hoja: HOJA,
        rango: RANGO,
        fila_encabezado: FILA_ENCABEZADO,
        formato: z.enum(["xlsx", "csv"]).optional().describe("Formato de salida."),
        delimitador_csv: z.enum([",", ";"]).default(",").describe("Delimitador para CSV."),
        bom: z.boolean().default(true).describe("Agrega BOM UTF-8 al CSV."),
        simular: z.boolean().default(true).describe("true = no escribe nada, solo muestra el resultado. false = escribe el archivo."),
        sobrescribir: z.boolean().default(false).describe("Permite reemplazar un archivo de salida existente (requiere confirmar=true)."),
        confirmar: z.literal(true).optional().describe("Obligatorio true cuando simular=false."),
        max_filas_preview: z.number().int().min(0).max(200).default(20).describe("Filas de vista previa a devolver."),
      },
      annotations: { readOnlyHint: false, destructiveHint: true, openWorldHint: false },
    },
    async (args) =>
      conManejo(async () => {
        const a = await validarArchivoEntrada(args.archivo);
        const h = await leerHoja(a, {
          hoja: args.hoja,
          rango: args.rango,
          filaEncabezado: args.fila_encabezado,
          maxFilas: 200_000,
          maxColumnas: 100,
        });
        const cols = args.columnas ? args.columnas.map((n) => resolverColumna(h, n)) : undefined;
        const resultado = buscarReemplazar(h, {
          buscar: args.buscar,
          reemplazar: args.reemplazar,
          columnas: cols,
          coincidenciaExacta: args.coincidencia_exacta,
          ignorarMayusculas: args.ignorar_mayusculas,
          ignorarAcentos: args.ignorar_acentos,
        });

        let formato = args.formato;
        if (args.salida) {
          const ext = path.extname(args.salida).toLowerCase();
          if (formato && ((formato === "xlsx" && ext !== ".xlsx") || (formato === "csv" && ext !== ".csv"))) {
            throw new ErrorExcel(`El formato "${formato}" no coincide con la extension de la salida "${ext}".`);
          }
          formato = formato ?? (ext === ".csv" ? "csv" : "xlsx");
        }
        formato = formato ?? "xlsx";

        const salidaTexto = args.salida
          ? args.salida
          : path.join(path.dirname(a.ruta), `${path.basename(a.ruta, path.extname(a.ruta))}_reemplazado.${formato}`);
        const destino = await validarArchivoSalida(salidaTexto);

        if (destino.extension.slice(1) !== formato) {
          throw new ErrorExcel(`La salida "${destino.ruta}" no coincide con el formato ${formato}.`);
        }
        if (mismaRuta(a.ruta, destino.ruta) || (destino.rutaReal !== null && mismaRuta(a.rutaReal, destino.rutaReal))) {
          throw new ErrorExcel("La salida no puede ser el mismo archivo de entrada.");
        }
        if (!args.simular) {
          if (args.confirmar !== true) {
            throw new ErrorExcel("Para escribir el archivo debes enviar simular=false y confirmar=true.");
          }
          if (destino.existe && !args.sobrescribir) {
            throw new ErrorExcel(`Ya existe el archivo de salida: ${destino.ruta}`, "Elige otro nombre o envia sobrescribir=true junto con confirmar=true.");
          }
          if (resultado.reemplazos === 0) {
            throw new ErrorExcel("No se encontro ninguna ocurrencia; no se escribio el archivo.");
          }
        }

        const vistaPrevia = resultado.filas.slice(0, args.max_filas_preview).map((f) => filaComoObjeto(h, f));
        const base = {
          ...prefijoComun(h),
          nombre: a.nombre,
          buscar: args.buscar,
          reemplazar: args.reemplazar,
          reemplazos: resultado.reemplazos,
          celdasAfectadas: resultado.celdasAfectadas,
          filasEntrada: h.filas.length,
          vistaPrevia,
          salidaPrevista: destino.ruta,
          salidaExiste: destino.existe,
          avisos: [...h.avisos, ...resultado.avisos],
        };

        if (args.simular) {
          return { ...base, simulado: true, escrito: false, nota: "No se escribio ningun archivo. Para escribir, repite con simular=false y confirmar=true." };
        }

        const escritura = await escribirTabla({
          destino,
          encabezados: h.columnas.map((c) => c.nombre),
          filas: matrizSalida(h, resultado.filas),
          nombreHoja: h.hoja,
          delimitador: args.delimitador_csv,
          bom: args.bom,
          protegerFormulas: true,
        });

        return {
          ...base,
          simulado: false,
          escrito: true,
          salida: escritura.ruta,
          formato: escritura.formato,
          bytes: escritura.bytes,
          avisos: [...base.avisos, ...escritura.avisos],
          nota: "Se exportaron valores (no formulas ni estilos) a un archivo nuevo.",
        };
      }),
  );
}
